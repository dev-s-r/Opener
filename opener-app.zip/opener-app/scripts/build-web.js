// Copies the PWA from /web into /www and injects the native bridge.
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const src = path.join(root, 'web');
const out = path.join(root, 'www');

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });

// The service worker is only for the browser/PWA version, the app doesn't need it.
for (const f of fs.readdirSync(src)) {
  if (f === 'sw.js') continue;
  fs.copyFileSync(path.join(src, f), path.join(out, f));
}
fs.copyFileSync(path.join(root, 'scripts', 'native-bridge.js'), path.join(out, 'native-bridge.js'));

const file = path.join(out, 'index.html');
let html = fs.readFileSync(file, 'utf8');
if (!html.includes('native-bridge.js')) {
  if (!/<head[^>]*>/i.test(html)) throw new Error('No <head> found in index.html');
  html = html.replace(/<head[^>]*>/i, m => m + '\n<script src="native-bridge.js"></script>');
  fs.writeFileSync(file, html);
}
console.log('www/ ready');
