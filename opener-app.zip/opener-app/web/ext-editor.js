/* Opener - code editor helpers: auto-close, smart Enter/indent, suggestions, comment toggle, line tools, key bar. */
(function () {
  'use strict';
  var O = window.__opener;
  if (!O) return;
  var ed = O.ed, wrap = O.$('#editorWrap');
  if (!ed || !wrap) return;

  var UNIT = '  ';
  var PAIRS = { '(': ')', '[': ']', '{': '}', '"': '"', "'": "'", '`': '`' };
  var CLOSERS = { ')': 1, ']': 1, '}': 1, '"': 1, "'": 1, '`': 1 };
  var busy = false;
  var enabled = O.store.get('assist', true);

  /* ---------- styles ---------- */
  var css = document.createElement('style');
  css.textContent = [
    '#kbar{position:absolute;left:0;right:0;bottom:0;z-index:4;background:var(--surface-low);border-top:1px solid var(--outline-v);display:flex;flex-direction:column}',
    '#kbar[hidden]{display:none}',
    '#kbSug{display:flex;gap:6px;overflow-x:auto;padding:6px 8px 0;scrollbar-width:none}',
    '#kbSug:empty{display:none}',
    '#kbSug::-webkit-scrollbar,#kbKeys::-webkit-scrollbar{display:none}',
    '#kbKeys{display:flex;gap:4px;overflow-x:auto;padding:6px 8px;scrollbar-width:none}',
    '#kbar button{flex:none;min-width:38px;height:36px;padding:0 10px;border-radius:8px;background:var(--surface-high);color:var(--on-surface);font:500 15px/1 var(--mono);user-select:none;-webkit-user-select:none}',
    '#kbar button:active{background:var(--primary-c)}',
    '#kbSug button{background:var(--secondary-c);color:var(--on-secondary-c);font-size:13.5px;height:32px;border-radius:16px;padding:0 12px}',
    '#kbSug button small{opacity:.65;margin-left:6px;font-size:11px}',
    '#kbKeys .sep{flex:none;width:1px;background:var(--outline-v);margin:4px 2px}',
    '#editorWrap.kb #edBox pre,#editorWrap.kb #edBox textarea,#editorWrap.kb #gutter{padding-bottom:112px}'
  ].join('\n');
  document.head.append(css);

  /* ---------- language data ---------- */
  var JS_KW = 'async await break case catch class const continue debugger default delete do else export extends false finally for function if import in instanceof let new null of return static super switch this throw true try typeof undefined var void while with yield'.split(' ');
  var JS_GLOBALS = ['console.log', 'console.error', 'console.warn', 'console.table', 'document.querySelector', 'document.querySelectorAll', 'document.getElementById', 'document.createElement', 'document.body', 'document.addEventListener', 'window.addEventListener', 'window.location', 'addEventListener', 'removeEventListener', 'setTimeout', 'setInterval', 'clearTimeout', 'clearInterval', 'requestAnimationFrame', 'fetch', 'Promise', 'Promise.all', 'JSON.stringify', 'JSON.parse', 'Math.floor', 'Math.ceil', 'Math.round', 'Math.random', 'Math.max', 'Math.min', 'Math.abs', 'Object.keys', 'Object.values', 'Object.entries', 'Object.assign', 'Array.isArray', 'Array.from', 'localStorage.getItem', 'localStorage.setItem', 'parseInt', 'parseFloat', 'isNaN', 'toString', 'forEach', 'map', 'filter', 'reduce', 'push', 'pop', 'shift', 'unshift', 'splice', 'slice', 'indexOf', 'includes', 'join', 'split', 'replace', 'trim', 'startsWith', 'endsWith', 'querySelector', 'querySelectorAll', 'getElementById', 'classList.add', 'classList.remove', 'classList.toggle', 'setAttribute', 'getAttribute', 'appendChild', 'innerHTML', 'textContent', 'preventDefault', 'stopPropagation', 'length', 'constructor', 'prototype', 'then', 'catch', 'finally', 'addEventListener'];
  var JS_SNIP = [
    ['log', 'console.log($0);'], ['fn', 'function $0() {\n  \n}'], ['af', 'const $0 = () => {\n  \n};'],
    ['for', 'for (let i = 0; i < $0; i++) {\n  \n}'], ['forof', 'for (const item of $0) {\n  \n}'], ['foreach', '$0.forEach(item => {\n  \n});'],
    ['if', 'if ($0) {\n  \n}'], ['ife', 'if ($0) {\n  \n} else {\n  \n}'], ['try', 'try {\n  $0\n} catch (err) {\n  console.error(err);\n}'],
    ['class', 'class $0 {\n  constructor() {\n    \n  }\n}'], ['async', 'async function $0() {\n  \n}'], ['fetch', 'const res = await fetch($0);\nconst data = await res.json();'],
    ['listener', 'document.addEventListener("$0", e => {\n  \n});'], ['timeout', 'setTimeout(() => {\n  $0\n}, 1000);'], ['switch', 'switch ($0) {\n  case x:\n    break;\n  default:\n    break;\n}']
  ];
  var CSS_PROPS = 'align-items align-content align-self animation background background-color background-image background-position background-repeat background-size border border-bottom border-color border-left border-radius border-right border-top border-width bottom box-shadow box-sizing color column-gap content cursor display filter flex flex-basis flex-direction flex-grow flex-shrink flex-wrap font font-family font-size font-style font-weight gap grid grid-area grid-column grid-gap grid-row grid-template-areas grid-template-columns grid-template-rows height inset justify-content justify-items left letter-spacing line-height list-style margin margin-bottom margin-left margin-right margin-top max-height max-width min-height min-width object-fit opacity order outline overflow overflow-x overflow-y padding padding-bottom padding-left padding-right padding-top place-items pointer-events position right row-gap text-align text-decoration text-overflow text-shadow text-transform top transform transition user-select vertical-align visibility white-space width word-break z-index'.split(' ');
  var CSS_VALS = 'absolute auto block bold border-box center column fixed flex grid hidden inherit inline inline-block inline-flex initial italic left none normal nowrap pointer relative right row solid space-between space-around space-evenly sticky transparent underline visible wrap uppercase lowercase ellipsis cover contain no-repeat 100% 100vh 100vw'.split(' ');
  var CSS_SNIP = [['media', '@media (max-width: 600px) {\n  $0\n}'], ['flex', 'display: flex;\nalign-items: center;\njustify-content: center;'], ['grid', 'display: grid;\ngrid-template-columns: repeat(auto-fit, minmax(200px, 1fr));\ngap: 16px;'], ['var', 'var(--$0)'], ['root', ':root {\n  --$0: ;\n}']];
  var VOID = { area: 1, base: 1, br: 1, col: 1, embed: 1, hr: 1, img: 1, input: 1, link: 1, meta: 1, param: 1, source: 1, track: 1, wbr: 1 };
  var TAGS = 'a abbr article aside audio b body br button canvas code div em footer form h1 h2 h3 h4 h5 h6 head header hr html i iframe img input label li link main meta nav ol option p pre script section select small span strong style svg table tbody td textarea th thead title tr ul video'.split(' ');
  var ATTRS = 'alt aria-label autofocus charset checked class content controls data- defer disabled for height hidden href id lang name onclick oninput placeholder readonly rel required role src srcset style tabindex target title type value width'.split(' ');
  var BOOL_ATTRS = { autofocus: 1, checked: 1, controls: 1, defer: 1, disabled: 1, hidden: 1, readonly: 1, required: 1 };
  var HTML_BOILER = '<!doctype html>\n<html lang="en">\n<head>\n  <meta charset="utf-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1">\n  <title>$0</title>\n</head>\n<body>\n  \n</body>\n</html>\n';
  var MD_SNIP = [['table', '| $0 | Column |\n| --- | --- |\n|  |  |'], ['link', '[$0](https://)'], ['img', '![$0](url)'], ['code', '```\n$0\n```'], ['task', '- [ ] $0']];

  /* ---------- helpers ---------- */
  function kind() { var e = O.cur(); return e ? e.kind : ''; }
  function isText() { var k = kind(); return O.TEXTUAL.indexOf(k) >= 0; }
  function on() { return enabled && isText(); }
  function isWord(c) { return !!c && /[\w$]/.test(c); }

  function regionAt(v, s) {
    var k = kind();
    if (k !== 'html') return k;
    var ls = v.lastIndexOf('<script', s - 1), le = v.lastIndexOf('</script', s - 1);
    if (ls > le && v.indexOf('>', ls) >= 0 && v.indexOf('>', ls) < s) return 'js';
    var ss = v.lastIndexOf('<style', s - 1), se = v.lastIndexOf('</style', s - 1);
    if (ss > se && v.indexOf('>', ss) >= 0 && v.indexOf('>', ss) < s) return 'css';
    var lt = v.lastIndexOf('<', s - 1), gt = v.lastIndexOf('>', s - 1);
    if (lt > gt) return 'tag';
    return 'html';
  }

  // undoable replacement of [start,end) with text; caret placed at sel (defaults to end of inserted text)
  function replace(start, end, text, selA, selB) {
    var before = ed.value, expected = before.slice(0, start) + text + before.slice(end);
    busy = true;
    try {
      ed.setSelectionRange(start, end);
      var done = false;
      try { done = text === '' ? document.execCommand('delete') : document.execCommand('insertText', false, text); } catch (err) { done = false; }
      if (!done || ed.value !== expected) {
        ed.value = expected;
        ed.dispatchEvent(new Event('input', { bubbles: true }));
      }
    } finally { busy = false; }
    var a = selA == null ? start + text.length : selA;
    ed.setSelectionRange(a, selB == null ? a : selB);
    scheduleSuggest();
  }

  function lineBounds(v, s, e) {
    var a = v.lastIndexOf('\n', s - 1) + 1;
    var b = v.indexOf('\n', e > s ? e - 1 : e); if (b < 0) b = v.length;
    return [a, b];
  }

  /* ---------- typing: auto-close / overtype / wrap ---------- */
  function typed(ch) {
    var v = ed.value, s = ed.selectionStart, e = ed.selectionEnd, k = kind(), reg = regionAt(v, s);
    var prev = v[s - 1], next = v[e];
    var quotes = k !== 'md' && k !== 'text';

    if (s !== e && PAIRS[ch] && (quotes || '([{'.indexOf(ch) >= 0)) {          // wrap selection
      replace(s, e, ch + v.slice(s, e) + PAIRS[ch], s + 1, e + 1); return true;
    }
    if (s === e && CLOSERS[ch] && next === ch) {                                // type over closer
      ed.setSelectionRange(s + 1, s + 1); scheduleSuggest(); return true;
    }
    if (s === e && PAIRS[ch]) {
      var isQuote = ch === '"' || ch === "'" || ch === '`';
      if (isQuote && !quotes) return false;
      if (isQuote && isWord(prev)) return false;                                 // don't -> apostrophe
      if (isQuote && k === 'html' && reg === 'html') return false;              // plain text in html
      if (next && !/[\s)\]}>;,.:]/.test(next)) return false;
      replace(s, s, ch + PAIRS[ch], s + 1); return true;
    }
    if (ch === '=' && s === e && k === 'html' && reg === 'tag' && /[\w-]/.test(prev || '') && next !== '"' && next !== "'") {
      replace(s, s, '=""', s + 2); return true;
    }
    if (ch === '>' && s === e && k === 'html' && reg === 'tag') {
      var lt = v.lastIndexOf('<', s - 1), tagText = v.slice(lt, s);
      var m = /^<([A-Za-z][\w:-]*)(\s[^<>]*)?$/.exec(tagText);
      if (m && !/\/$/.test(tagText) && !VOID[m[1].toLowerCase()]) {
        replace(s, s, '></' + m[1] + '>', s + 1); return true;
      }
    }
    if (ch === '/' && s === e && k === 'html' && prev === '<' && reg === 'tag') {  // "</" -> close nearest open tag
      var open = nearestOpenTag(v.slice(0, s - 1));
      if (open) { replace(s, s, '/' + open + '>', s + open.length + 2); return true; }
    }
    return false;
  }

  function nearestOpenTag(text) {
    var re = /<(\/?)([A-Za-z][\w:-]*)([^<>]*?)(\/?)>/g, m, stack = [];
    text = text.replace(/<!--[\s\S]*?-->/g, '').replace(/<(script|style)[\s\S]*?<\/\1>/gi, function (x, nm) { return '<' + nm + '></' + nm + '>'; });
    while ((m = re.exec(text))) {
      var name = m[2].toLowerCase();
      if (m[1]) { var i = stack.lastIndexOf(name); if (i >= 0) stack.length = i; }
      else if (!m[4] && !VOID[name]) stack.push(name);
    }
    return stack.length ? stack[stack.length - 1] : null;
  }

  function backspacePair() {
    var v = ed.value, s = ed.selectionStart;
    if (s !== ed.selectionEnd || s < 1) return false;
    var a = v[s - 1], b = v[s];
    if (PAIRS[a] && PAIRS[a] === b) { replace(s - 1, s + 1, ''); return true; }
    return false;
  }

  function enter() {
    var v = ed.value, s = ed.selectionStart, e = ed.selectionEnd, k = kind();
    var ls = v.lastIndexOf('\n', s - 1) + 1, line = v.slice(ls, s);
    var indent = /^[ \t]*/.exec(line)[0], before = v[s - 1], after = v[e];

    if (k === 'md') {
      var mm = /^(\s*)([-*+]|\d+\.)(\s+(?:\[[ xX]\]\s+)?)/.exec(line);
      if (mm) {
        if (line.trim() === mm[2] || /^\s*([-*+]|\d+\.)\s+(\[[ xX]\]\s*)?$/.test(line)) { replace(ls, e, '\n'.slice(1) + '', ls); return true; }
        var marker = /^\d+\.$/.test(mm[2]) ? (parseInt(mm[2], 10) + 1) + '.' : mm[2];
        var task = /\[[ xX]\]/.test(mm[3]) ? '[ ] ' : '';
        replace(s, e, '\n' + mm[1] + marker + mm[3].replace(/\[[ xX]\]\s*/, '') + task); return true;
      }
    }
    if (PAIRS[before] && PAIRS[before] === after && '{[('.indexOf(before) >= 0) {
      replace(s, e, '\n' + indent + UNIT + '\n' + indent, s + 1 + indent.length + UNIT.length); return true;
    }
    if (k === 'html' && before === '>' && v.slice(e, e + 2) === '</') {
      replace(s, e, '\n' + indent + UNIT + '\n' + indent, s + 1 + indent.length + UNIT.length); return true;
    }
    var extra = false;
    if (k === 'js' || k === 'css' || k === 'json') extra = /[{\[(]\s*$/.test(line);
    else if (k === 'html') {
      var t = /<([A-Za-z][\w:-]*)(\s[^<>]*)?>\s*$/.exec(line);
      extra = !!t && !VOID[t[1].toLowerCase()] && !/\/>\s*$/.test(line) && !/<\/[A-Za-z]/.test(line.slice(t.index));
    }
    if (!extra && !indent) return false;
    replace(s, e, '\n' + indent + (extra ? UNIT : '')); return true;
  }

  /* ---------- indent / comments / line tools ---------- */
  function indentSel(dir) {
    var v = ed.value, s = ed.selectionStart, e = ed.selectionEnd;
    if (dir > 0 && s === e) { replace(s, e, UNIT); return; }
    var b = lineBounds(v, s, e), block = v.slice(b[0], b[1]), lines = block.split('\n');
    var out = lines.map(function (l) { return dir > 0 ? (l ? UNIT + l : l) : l.replace(/^(\t| {1,2})/, ''); }).join('\n');
    var shiftS = dir > 0 ? UNIT.length : -Math.min(UNIT.length, (/^(\t| {1,2})/.exec(lines[0]) || [''])[0].length);
    replace(b[0], b[1], out, Math.max(b[0], s + shiftS), e + (out.length - block.length));
  }

  function commentMarkers(reg) {
    if (reg === 'js') return ['// ', ''];
    if (reg === 'css') return ['/* ', ' */'];
    if (reg === 'html' || reg === 'tag' || reg === 'md') return ['<!-- ', ' -->'];
    if (reg === 'text') return ['# ', ''];
    return null;
  }
  function toggleComment() {
    var v = ed.value, s = ed.selectionStart, e = ed.selectionEnd, mk = commentMarkers(regionAt(v, s));
    if (!mk) { O.toast('Comments are not available for this file type'); return; }
    var b = lineBounds(v, s, e), lines = v.slice(b[0], b[1]).split('\n');
    var open = mk[0].trim(), close = mk[1].trim();
    var all = lines.every(function (l) { var t = l.trim(); return !t || (t.indexOf(open) === 0 && (!close || t.slice(-close.length) === close)); });
    var out = lines.map(function (l) {
      if (!l.trim()) return l;
      if (all) {
        var r = l.replace(open + ' ', '').replace(open, '');
        if (close) { r = r.replace(' ' + close, '').replace(new RegExp(close.replace(/[*/]/g, '\\$&') + '\\s*$'), ''); }
        return r;
      }
      var ind = /^\s*/.exec(l)[0];
      return ind + mk[0] + l.slice(ind.length) + mk[1];
    }).join('\n');
    replace(b[0], b[1], out, b[0], b[0] + out.length);
  }
  function duplicateLine() {
    var v = ed.value, s = ed.selectionStart, e = ed.selectionEnd, b = lineBounds(v, s, e), block = v.slice(b[0], b[1]);
    replace(b[1], b[1], '\n' + block, s + block.length + 1, e + block.length + 1);
  }
  function deleteLine() {
    var v = ed.value, b = lineBounds(v, ed.selectionStart, ed.selectionEnd);
    var from = b[0], to = b[1] < v.length ? b[1] + 1 : b[1];
    if (to === v.length && from > 0) from -= 1;
    replace(from, to, '', Math.min(from + 0, v.length - (to - from)));
  }
  function moveLine(dir) {
    var v = ed.value, s = ed.selectionStart, e = ed.selectionEnd, b = lineBounds(v, s, e);
    if (dir < 0) {
      if (b[0] === 0) return;
      var pa = v.lastIndexOf('\n', b[0] - 2) + 1, prev = v.slice(pa, b[0] - 1), cur = v.slice(b[0], b[1]);
      replace(pa, b[1], cur + '\n' + prev, s - (prev.length + 1), e - (prev.length + 1));
    } else {
      if (b[1] >= v.length) return;
      var nb = v.indexOf('\n', b[1] + 1); if (nb < 0) nb = v.length;
      var next = v.slice(b[1] + 1, nb), cur2 = v.slice(b[0], b[1]);
      replace(b[0], nb, next + '\n' + cur2, s + next.length + 1, e + next.length + 1);
    }
  }
  function undo() { ed.focus(); document.execCommand('undo'); scheduleSuggest(); }
  function redo() { ed.focus(); document.execCommand('redo'); scheduleSuggest(); }
  function moveCaret(d) { var p = Math.max(0, Math.min(ed.value.length, ed.selectionStart + d)); ed.setSelectionRange(p, p); scheduleSuggest(); }

  /* ---------- suggestions ---------- */
  var sugTimer = null, current = [];
  function scheduleSuggest() { clearTimeout(sugTimer); sugTimer = setTimeout(refreshSuggest, 70); }

  function docWords(v, s, prefixSeg) {
    var from = Math.max(0, s - 60000), to = Math.min(v.length, s + 60000), text = v.slice(from, to), re = /[A-Za-z_$][\w$-]{2,}/g, m, map = Object.create(null);
    while ((m = re.exec(text))) { var w = m[0]; map[w] = (map[w] || 0) + 1; }
    if (map[prefixSeg] === 1) delete map[prefixSeg];
    return map;
  }

  function computeSuggestions() {
    if (!on()) return [];
    var v = ed.value, s = ed.selectionStart;
    if (s !== ed.selectionEnd) return [];
    var reg = regionAt(v, s), k = kind();
    var pm = /[\w$.-]*$/.exec(v.slice(Math.max(0, s - 80), s)), prefix = pm ? pm[0] : '', start = s - prefix.length;
    var out = [];

    if (reg === 'html' && v[s - 1] === '!' && /^\s*$/.test(v.slice(v.lastIndexOf('\n', s - 2) + 1, s - 1))) {
      return [{ label: '! html5', ins: HTML_BOILER, from: s - 1 }];
    }
    if (reg === 'html') { if (v[start - 1] !== '<') { return []; } }

    var seg = prefix, segFrom = start;
    if (reg === 'js') { var dot = prefix.lastIndexOf('.'); if (dot >= 0) { seg = prefix.slice(dot + 1); segFrom = start + dot + 1; } }
    if (reg === 'css' || reg === 'tag' || reg === 'html') seg = prefix;
    if (seg.length < (reg === 'html' ? 1 : 2) && !(reg === 'tag' && seg.length >= 1)) {
      if (!(reg === 'js' && prefix.length >= 2)) return [];
    }
    var low = seg.toLowerCase();
    var seen = Object.create(null);
    function add(label, ins, from, kindLabel, prio) {
      if (seen[label] || label === seg) return;
      if (label.toLowerCase().indexOf(low) !== 0 && !(reg === 'js' && from === start && label.toLowerCase().indexOf(prefix.toLowerCase()) === 0)) return;
      seen[label] = 1; out.push({ label: label, ins: ins == null ? label : ins, from: from, tag: kindLabel, prio: prio });
    }

    if (reg === 'js') {
      JS_SNIP.forEach(function (x) { if (seg === prefix) add(x[0], x[1], start, 'snippet', 0); });
      JS_GLOBALS.forEach(function (g) {
        if (prefix.indexOf('.') >= 0) { if (g.toLowerCase().indexOf(prefix.toLowerCase()) === 0) add(g, g, start, '', 1); else { var lastSeg = g.slice(g.lastIndexOf('.') + 1); if (g.indexOf('.') < 0) add(lastSeg, lastSeg, segFrom, '', 2); } }
        else add(g, g, start, '', 1);
      });
      if (seg === prefix) JS_KW.forEach(function (w) { add(w, w, start, 'keyword', 2); });
    } else if (reg === 'css') {
      var blockStart = Math.max(v.lastIndexOf('{', s - 1), v.lastIndexOf(';', s - 1), v.lastIndexOf('}', s - 1));
      var inValue = v.slice(blockStart + 1, start).indexOf(':') >= 0;
      if (inValue) CSS_VALS.forEach(function (w) { add(w, w, start, 'value', 1); });
      else {
        CSS_SNIP.forEach(function (x) { add(x[0], x[1], start, 'snippet', 0); });
        CSS_PROPS.forEach(function (w) { add(w, w + ': $0;', start, 'property', 1); });
      }
    } else if (reg === 'html') {
      TAGS.forEach(function (t) { add(t, VOID[t] ? t + '>' : t + '>$0</' + t + '>', start, 'tag', 1); });
      return finish(out);
    } else if (reg === 'tag') {
      if (v[start - 1] === '<') {
        TAGS.forEach(function (t) { add(t, VOID[t] ? t + '>' : t + '>$0</' + t + '>', start, 'tag', 1); });
      } else {
        ATTRS.forEach(function (a) { add(a, BOOL_ATTRS[a] ? a : (a === 'data-' ? 'data-$0=""' : a + '="$0"'), start, 'attribute', 1); });
      }
      return finish(out);
    } else if (reg === 'md') {
      MD_SNIP.forEach(function (x) { add(x[0], x[1], start, 'snippet', 0); });
    } else if (reg === 'json') {
      ['true', 'false', 'null'].forEach(function (w) { add(w, w, start, 'value', 2); });
    }

    var words = docWords(v, s, seg);
    Object.keys(words).sort(function (a, b) { return words[b] - words[a]; }).forEach(function (w) { add(w, w, segFrom, 'in file', 3); });
    return finish(out);
  }
  function finish(out) {
    out.sort(function (a, b) { return a.prio - b.prio || a.label.length - b.label.length; });
    return out.slice(0, 12);
  }

  function applySuggestion(item) {
    var s = ed.selectionStart, text = item.ins, caret = text.indexOf('$0');
    if (caret >= 0) text = text.replace('$0', ''); else caret = text.length;
    replace(item.from, s, text, item.from + caret);
  }

  /* ---------- key bar ---------- */
  var bar = document.createElement('div'); bar.id = 'kbar'; bar.hidden = true;
  var sugEl = document.createElement('div'); sugEl.id = 'kbSug';
  var keysEl = document.createElement('div'); keysEl.id = 'kbKeys';
  bar.append(sugEl, keysEl); wrap.append(bar);

  function keyBtn(label, fn, aria) {
    var b = document.createElement('button'); b.type = 'button'; b.textContent = label; if (aria) b.setAttribute('aria-label', aria);
    // keep focus (and the on-screen keyboard) in the editor
    b.addEventListener('mousedown', function (ev) { ev.preventDefault(); });
    b.addEventListener('pointerdown', function (ev) { ev.preventDefault(); });
    b.addEventListener('click', function (ev) { ev.preventDefault(); if (document.activeElement !== ed) ed.focus(); fn(); });
    return b;
  }
  function symbol(ch) { return function () { if (!typed(ch)) replace(ed.selectionStart, ed.selectionEnd, ch); }; }
  function buildKeys() {
    keysEl.innerHTML = '';
    var add = function (b) { keysEl.append(b); };
    add(keyBtn('⇥', function () { indentSel(1); }, 'Indent'));
    add(keyBtn('⇤', function () { indentSel(-1); }, 'Outdent'));
    add(keyBtn('←', function () { moveCaret(-1); }, 'Cursor left'));
    add(keyBtn('→', function () { moveCaret(1); }, 'Cursor right'));
    add(keyBtn('↶', undo, 'Undo'));
    add(keyBtn('↷', redo, 'Redo'));
    var sep = document.createElement('i'); sep.className = 'sep'; add(sep);
    '{ } ( ) [ ] < > / " \' ` ; : = . , $ # ! & | _ - + * \\ ? @ % ~'.split(' ').forEach(function (c) { add(keyBtn(c, symbol(c))); });
    var sep2 = document.createElement('i'); sep2.className = 'sep'; add(sep2);
    add(keyBtn('//', toggleComment, 'Toggle comment'));
    add(keyBtn('⧉', duplicateLine, 'Duplicate line'));
    add(keyBtn('▲', function () { moveLine(-1); }, 'Move line up'));
    add(keyBtn('▼', function () { moveLine(1); }, 'Move line down'));
    add(keyBtn('⌫', deleteLine, 'Delete line'));
  }
  buildKeys();

  function showSuggestions(list) {
    current = list; sugEl.innerHTML = '';
    list.forEach(function (item) {
      var b = keyBtn(item.label, function () { applySuggestion(item); });
      if (item.tag) { var sm = document.createElement('small'); sm.textContent = item.tag; b.append(sm); }
      sugEl.append(b);
    });
    sugEl.scrollLeft = 0;
  }
  function refreshSuggest() {
    if (!on() || wrap.hidden) { showSuggestions([]); return; }
    try { showSuggestions(computeSuggestions()); } catch (err) { showSuggestions([]); }
  }
  function syncBar() {
    var show = on() && !wrap.hidden;
    bar.hidden = !show; wrap.classList.toggle('kb', show);
    if (!show) showSuggestions([]);
  }

  /* ---------- events ---------- */
  ed.addEventListener('beforeinput', function (ev) {
    if (!on() || busy) return;
    var t = ev.inputType;
    if (t === 'insertText' && ev.data && ev.data.length === 1 && !ev.isComposing) {
      if (typed(ev.data)) ev.preventDefault();
    } else if ((t === 'insertLineBreak' || t === 'insertParagraph')) {
      if (enter()) ev.preventDefault();
    } else if (t === 'deleteContentBackward') {
      if (backspacePair()) ev.preventDefault();
    }
  });
  ed.addEventListener('input', function () { if (!busy) scheduleSuggest(); });
  ed.addEventListener('keyup', function (ev) { if (/Arrow|Home|End/.test(ev.key)) scheduleSuggest(); });
  ed.addEventListener('click', scheduleSuggest);
  ed.addEventListener('focus', function () { syncBar(); scheduleSuggest(); });

  // capture phase so these run before the app's own Tab handler
  ed.addEventListener('keydown', function (ev) {
    if (!on()) return;
    var mod = ev.ctrlKey || ev.metaKey, k = ev.key;
    function stop() { ev.preventDefault(); ev.stopImmediatePropagation(); }
    if (k === 'Tab') {
      if (!ev.shiftKey && current.length && ed.selectionStart === ed.selectionEnd) { stop(); applySuggestion(current[0]); return; }
      stop(); indentSel(ev.shiftKey ? -1 : 1);
    } else if (mod && k === '/') { stop(); toggleComment(); }
    else if (mod && ev.shiftKey && k.toLowerCase() === 'd') { stop(); duplicateLine(); }
    else if (mod && ev.shiftKey && k.toLowerCase() === 'k') { stop(); deleteLine(); }
    else if (ev.altKey && (k === 'ArrowUp' || k === 'ArrowDown')) { stop(); moveLine(k === 'ArrowUp' ? -1 : 1); }
    else if (mod && k === ' ') { stop(); refreshSuggest(); }
    else if (k === 'Escape' && current.length) { showSuggestions([]); }
  }, true);

  // follow tab / mode changes
  new MutationObserver(syncBar).observe(wrap, { attributes: true, attributeFilter: ['hidden'] });
  var title = O.$('#title'); if (title) new MutationObserver(function () { syncBar(); scheduleSuggest(); }).observe(title, { childList: true, characterData: true, subtree: true });
  syncBar();

  /* ---------- settings switch ---------- */
  var anchor = O.$('#setFull'), row = anchor && anchor.closest('.row');
  if (row) {
    var r = document.createElement('div'); r.className = 'row';
    r.innerHTML = '<div>Editor helpers<small>Auto-close brackets, suggestions and key bar</small></div><input type="checkbox" class="switch" id="setAssist">';
    row.parentNode.insertBefore(r, row);
    var sw = r.querySelector('input'); sw.checked = enabled;
    sw.onchange = function () { enabled = sw.checked; O.store.set('assist', enabled); syncBar(); showSuggestions([]); };
  }
})();
