/* Opener – Material 3 home screen: tools, filters, recent files, gestures, bottom sheet */
(function () {
  'use strict';
  var O = window.__opener;
  if (!O) return;
  var $ = O.$, store = O.store, doc = document;
  var narrow = window.matchMedia('(max-width:839px)');

  function el(tag, cls, html) { var e = doc.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function lsDel(k) { try { localStorage.removeItem(k); } catch (e) { /* ignore */ } }
  function stamp() { var d = new Date(), p = function (n) { return (n < 10 ? '0' : '') + n; }; return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + '_' + p(d.getHours()) + p(d.getMinutes()); }
  function sv(paths) { return '<svg viewBox="0 0 24 24" aria-hidden="true">' + paths + '</svg>'; }

  var dragEnd = 0, swipedAt = 0, heldAt = 0;
  doc.addEventListener('click', function (e) { if (Date.now() - dragEnd < 350) { e.stopPropagation(); e.preventDefault(); } }, true);
  doc.addEventListener('touchmove', function (e) { if (window.__live) e.preventDefault(); }, { passive: false });

  /* ---------- ripple ---------- */
  doc.addEventListener('pointerdown', function (ev) {
    var t = ev.target.closest && ev.target.closest('.h-r'); if (!t) return;
    var r = t.getBoundingClientRect(), d = Math.max(r.width, r.height) * 2, i = el('span', 'h-rip');
    i.style.cssText = 'width:' + d + 'px;height:' + d + 'px;left:' + (ev.clientX - r.left - d / 2) + 'px;top:' + (ev.clientY - r.top - d / 2) + 'px';
    t.append(i); setTimeout(function () { i.remove(); }, 520);
  });

  /* ---------- generic drag-to-reorder (long-press, or instant) ---------- */
  function sortable(box, sel, o) {
    o = o || {};
    box.addEventListener('pointerdown', function (e) {
      if (e.button > 0 || e._srt) return;
      var it = e.target.closest(sel); if (!it || !box.contains(it)) return;
      if (o.enabled && !o.enabled()) return;
      if (o.handle && !e.target.closest(o.handle)) return;
      e._srt = true;
      var sx = e.clientX, sy = e.clientY, delay = (o.instant && o.instant()) ? 0 : 380;
      var live = false, tx = 0, ty = 0, grab = null, timer = null, lx = sx, ly = sy, lock = 0, auto = null;
      function upd() {
        var r = it.getBoundingClientRect(), nl = r.left - tx, nt = r.top - ty;
        tx = lx - grab.x - nl; ty = ly - grab.y - nt; it.style.transform = 'translate(' + tx + 'px,' + ty + 'px)';
        if (Date.now() < lock) return;
        var kids = [].slice.call(box.children).filter(function (c) { return c.matches(sel); });
        var sibs = kids.filter(function (c) { return c !== it; });
        var rc = it.getBoundingClientRect(), cx = rc.left + rc.width / 2, cy = rc.top + rc.height / 2;
        var hit = null;
        for (var i = 0; i < sibs.length; i++) { var q = sibs[i].getBoundingClientRect(); if (cx > q.left && cx < q.right && cy > q.top && cy < q.bottom) { hit = sibs[i]; break; } }
        if (!hit) return;
        var first = sibs.map(function (c) { return c.getBoundingClientRect(); });
        if (kids.indexOf(it) < kids.indexOf(hit)) hit.after(it); else hit.before(it);
        var r2 = it.getBoundingClientRect(); tx = lx - grab.x - (r2.left - tx); ty = ly - grab.y - (r2.top - ty);
        it.style.transform = 'translate(' + tx + 'px,' + ty + 'px)';
        sibs.forEach(function (c, i) {
          var a = first[i], b = c.getBoundingClientRect(), dx = a.left - b.left, dy = a.top - b.top;
          if (dx || dy) {
            c.style.transition = 'none'; c.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
            requestAnimationFrame(function () { requestAnimationFrame(function () { c.style.transition = 'transform .22s cubic-bezier(.2,0,0,1)'; c.style.transform = ''; setTimeout(function () { c.style.transition = ''; }, 260); }); });
          }
        });
        lock = Date.now() + 270;
      }
      function begin() {
        live = true; window.__live = true; var r = it.getBoundingClientRect(); grab = { x: sx - r.left, y: sy - r.top };
        it.classList.add('h-lift'); it.style.transition = 'none';
        try { if (navigator.vibrate) navigator.vibrate(12); } catch (_) { /* ignore */ }
        auto = setInterval(function () {
          if (o.scroller) { var q = o.scroller.getBoundingClientRect(); if (ly < q.top + 70) o.scroller.scrollTop -= 10; else if (ly > q.bottom - 70) o.scroller.scrollTop += 10; }
          upd();
        }, 50);
        upd();
      }
      function mv(ev) {
        lx = ev.clientX; ly = ev.clientY;
        if (!live) { if (Math.hypot(lx - sx, ly - sy) > 8) stop(false); return; }
        ev.preventDefault(); upd();
      }
      function stop(fin) {
        clearTimeout(timer); clearInterval(auto);
        removeEventListener('pointermove', mv); removeEventListener('pointerup', up); removeEventListener('pointercancel', up);
        if (live && fin !== false) {
          live = false; window.__live = false; dragEnd = Date.now();
          it.style.transition = 'transform .22s cubic-bezier(.2,0,0,1)'; it.style.transform = 'translate(0,0)';
          setTimeout(function () { it.style.transition = ''; it.style.transform = ''; it.classList.remove('h-lift'); }, 230);
          if (o.onChange) o.onChange([].slice.call(box.children).filter(function (c) { return c.matches(sel); }));
        } else if (live) { live = false; window.__live = false; it.style.transition = ''; it.style.transform = ''; it.classList.remove('h-lift'); }
      }
      function up() { stop(true); }
      addEventListener('pointermove', mv, { passive: false }); addEventListener('pointerup', up); addEventListener('pointercancel', up);
      if (delay === 0) begin(); else timer = setTimeout(begin, delay);
    });
    box.addEventListener('contextmenu', function (e) { if (e.target.closest(sel)) e.preventDefault(); });
  }
  O.sortable = sortable;

  /* ---------- bottom sheet ---------- */
  var hsScrim = el('div'); hsScrim.id = 'hsScrim';
  var hsSheet = el('div'); hsSheet.id = 'hsSheet'; hsSheet.setAttribute('role', 'dialog');
  hsSheet.innerHTML = '<div class="hd"><div class="grab"></div><h3></h3></div><div class="hb"></div>';
  doc.body.append(hsScrim, hsSheet);
  function closeSheet() { hsSheet.classList.remove('on'); hsScrim.classList.remove('on'); }
  O.closeSheet = closeSheet;
  O.sheet = function (title, items) {
    hsSheet.querySelector('h3').textContent = title;
    var b = hsSheet.querySelector('.hb'); b.innerHTML = '';
    items.filter(function (i) { return i && !i.hidden && !i.divider; }).forEach(function (it) {
      var btn = el('button', 'hs-it h-r'), ic = el('span', 'hs-ic');
      ic.innerHTML = it.svg ? '<svg class="hs-st" viewBox="0 0 24 24">' + it.svg + '</svg>' : O.ic(it.icon || 'file');
      btn.append(ic, doc.createTextNode(it.label));
      btn.onclick = function () { closeSheet(); setTimeout(function () { if (it.run) it.run(); }, 120); };
      b.append(btn);
    });
    hsSheet.scrollTop = 0; hsSheet.classList.add('on'); hsScrim.classList.add('on');
  };
  hsScrim.onclick = closeSheet;
  hsSheet.querySelector('.hd').addEventListener('pointerdown', function (e) {
    var sy = e.clientY, dy = 0;
    function mv(ev) { dy = Math.max(0, ev.clientY - sy); hsSheet.style.transition = 'none'; hsSheet.style.transform = 'translate(-50%,' + dy + 'px)'; }
    function up() { removeEventListener('pointermove', mv); removeEventListener('pointerup', up); removeEventListener('pointercancel', up); hsSheet.style.transition = ''; hsSheet.style.transform = ''; if (dy > 90) closeSheet(); }
    addEventListener('pointermove', mv); addEventListener('pointerup', up); addEventListener('pointercancel', up);
  });

  /* ---------- tools ---------- */
  var TI = {
    scan: '<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3M7 12h10"/>',
    photos: '<rect x="3.5" y="5" width="17" height="14" rx="2.5"/><circle cx="9" cy="10" r="1.5"/><path d="M4 17l5-4.5 3.5 3 3-2.5 4.5 4"/>',
    merge: '<path d="M5 4v3a5 5 0 0 0 5 5h4a5 5 0 0 0 5-5V4M12 12v8M9 17l3 3 3-3"/>',
    link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3A4 4 0 0 0 10 18.7l1-1"/>',
    code: '<path d="M9 8l-4 4 4 4M15 8l4 4-4 4"/>',
    more: '<circle cx="6" cy="12" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="18" cy="12" r="1.2"/>',
    zip: '<path d="M4 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2zM12 9v7M9 13l3 3 3-3"/>',
    file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
    folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    add: '<path d="M12 5v14M5 12h14"/>'
  };
  function menuItem(label) {
    var all = (O.menuItems || []).reduce(function (a, f) { try { return a.concat(f(null) || []); } catch (e) { return a; } }, []);
    for (var i = 0; i < all.length; i++) if (all[i].label === label) return all[i];
    return null;
  }
  function runMenu(label) { var m = menuItem(label); if (m && m.run) m.run(); else O.toast('Not available here'); }
  function scan() { if (O.openScan) O.openScan(); else runMenu('Scan to PDF'); }
  function photos() { runMenu('Create PDF from photos'); }

  var libP = null;
  function loadLib() {
    if (window.PDFLib) return Promise.resolve(window.PDFLib);
    if (libP) return libP;
    libP = new Promise(function (res, rej) {
      function add(src, bad) { var s = doc.createElement('script'); s.src = src; s.onload = function () { res(window.PDFLib); }; s.onerror = bad; doc.head.append(s); }
      add('vendor/pdf-lib.min.js', function () { add('https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js', function () { libP = null; rej(new Error('Could not load the PDF tool')); }); });
    });
    return libP;
  }
  function mergePdfs() {
    var inp = doc.createElement('input'); inp.type = 'file'; inp.accept = 'application/pdf,.pdf'; inp.multiple = true;
    inp.onchange = async function () {
      var list = [].slice.call(inp.files || []); if (!list.length) return;
      if (list.length < 2) { O.toast('Pick at least two PDFs'); return; }
      O.toast('Merging…');
      try {
        var PL = await loadLib(), out = await PL.PDFDocument.create();
        for (var i = 0; i < list.length; i++) {
          var src = await PL.PDFDocument.load(await list[i].arrayBuffer(), { ignoreEncryption: true });
          var pages = await out.copyPages(src, src.getPageIndices());
          pages.forEach(function (p) { out.addPage(p); });
        }
        var bytes = await out.save();
        await O.openNewFile(new Blob([bytes], { type: 'application/pdf' }), 'Merged-' + stamp() + '.pdf');
      } catch (e) { O.toast('Merge failed: ' + (e && e.message ? e.message : e)); }
    };
    inp.click();
  }

  var TOOLS = [
    { id: 'Scan', color: '--ft-blue', svg: TI.scan, run: scan },
    { id: 'Photos to PDF', color: '--ft-purple', svg: TI.photos, run: photos },
    { id: 'Merge PDFs', color: '--ft-red', svg: TI.merge, run: mergePdfs },
    { id: 'More', color: '--ft-grey', svg: TI.more, run: moreTools }
  ];
  function moreTools() {
    O.sheet('Tools', [
      { svg: TI.scan, label: 'Scan to PDF', run: scan },
      { svg: TI.photos, label: 'Photos to PDF', run: photos },
      { svg: TI.merge, label: 'Merge PDFs', run: mergePdfs },
      { svg: TI.link, label: 'Open from link', run: O.linkDialog },
      { svg: TI.code, label: 'Paste code', run: O.pasteDialog },
      { svg: TI.zip, label: 'Download all as zip', hidden: !O.files.size, run: O.zipAll }
    ]);
  }
  function openSheet() {
    O.sheet('Open', [
      { svg: TI.file, label: 'Open file', run: O.openFile },
      { svg: TI.folder, label: 'Open folder', run: O.pickDir },
      { svg: TI.link, label: 'Open from link', run: O.linkDialog },
      { svg: TI.code, label: 'Paste code', run: O.pasteDialog },
      { svg: TI.add, label: 'New file', run: O.newFileDialog }
    ]);
  }

  /* ---------- build the home screen inside #empty ---------- */
  var empty = $('#empty'), content = $('#content');
  if (!empty || !content) return;
  var hero = el('div'); hero.id = 'hHero';
  while (empty.firstChild) hero.append(empty.firstChild);

  var arr = el('div'); arr.id = 'hArr';
  arr.innerHTML = '<span>Drag to rearrange</span><button class="btn text sl" id="hArrReset">Reset</button><button class="btn tonal sl" id="hArrDone">Done</button>';

  var sb = el('div', 'h-sb');
  sb.innerHTML = '<button class="h-ib h-r" id="hMenu" aria-label="Files">' + O.ic('menu') + '</button>' +
    '<input id="hQ" placeholder="Search files" autocomplete="off">' +
    '<button class="h-ib h-r" id="hMore" data-menu aria-label="More">' + O.ic('more') + '</button>';

  var GRIP = '<svg viewBox="0 0 24 24" style="width:24px;height:24px;fill:currentColor"><path d="M11 18c0 1.1-.9 2-2 2s-2-.9-2-2 .9-2 2-2 2 .9 2 2zm-2-8c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0-6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm6 4c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>';
  var blocks = el('div'); blocks.id = 'hBlocks';
  var bTools = el('div', 'h-blk'); bTools.dataset.id = 'tools';
  bTools.innerHTML = '<div class="h-hnd" aria-label="Drag to move">' + GRIP + '</div><div class="h-tools" id="hTools"></div>';
  var bFiles = el('div', 'h-blk'); bFiles.dataset.id = 'files';
  bFiles.innerHTML = '<div class="h-hnd" aria-label="Drag to move">' + GRIP + '</div><div class="h-chips" id="hChips"></div><div id="hList"></div><button class="h-more h-r" id="hShowAll">Show all files</button>';
  bFiles.append(hero);
  blocks.append(bTools, bFiles);
  empty.append(arr, sb, blocks);

  var fab = el('button', 'h-r'); fab.id = 'hFab'; fab.setAttribute('aria-label', 'Open');
  fab.innerHTML = '<svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg><span class="lb">Open</span>';
  content.append(fab);
  var edge = el('div'); edge.id = 'hEdge'; doc.body.append(edge);

  var filter = 'All', query = '', showAll = false;
  var CHIPS = ['All', 'Favourites', 'PDF', 'Office'];
  var STAR = sv('<path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>');
  var STARO = sv('<path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z"/>');
  var TRASH = sv('<path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>');
  var CHECK = sv('<path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/>');

  function savedOrder(key) { var v = store.get(key, null); return Array.isArray(v) ? v : null; }
  function renderTools() {
    var host = $('#hTools'), o = savedOrder('o.tools'), list = TOOLS.slice();
    if (o) list.sort(function (a, b) { var x = o.indexOf(a.id), y = o.indexOf(b.id); return (x < 0 ? 99 : x) - (y < 0 ? 99 : y); });
    host.innerHTML = '';
    list.forEach(function (t) {
      var b = el('button', 'h-tool h-r h-srt'); b.dataset.t = t.id;
      b.innerHTML = '<span class="h-tile" style="--c:var(' + t.color + ')">' + sv(t.svg) + '</span><span></span>';
      b.lastChild.textContent = t.id;
      b.onclick = function () { t.run(); };
      host.append(b);
    });
  }
  var PLUS = sv('<path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>');
  function customs() { var v = store.get('filters', []); return Array.isArray(v) ? v : []; }
  function findCustom(k) { return customs().filter(function (f) { return 'c:' + f.id === k; })[0]; }
  function extList(str) { return String(str || '').toLowerCase().split(/[\s,;.]+/).filter(Boolean); }
  var PRESETS = [['Code', 'java py js ts kt c cpp cs go rs php rb sh sql'], ['Java', 'java'], ['Python', 'py'], ['Text', 'txt md log'], ['Images', 'png jpg jpeg gif webp'], ['Encrypted', 'enc']];
  function filterDialog(f) {
    O.showForm({
      title: f ? 'Edit filter' : 'New filter', confirm: f ? 'Save' : 'Add',
      note: 'Show only files with these endings, like java py enc.',
      fields: [{ id: 'name', label: 'Name', value: f ? f.name : '', placeholder: 'My code' }, { id: 'exts', label: 'File endings', value: f ? f.exts.join(' ') : '', placeholder: 'java py enc' }],
      chips: PRESETS, onChip: function (x, form) { form.set('exts', x); if (!form.get('name').trim()) form.set('name', PRESETS.filter(function (p) { return p[1] === x; })[0][0]); },
      onSubmit: function (form) {
        var ex = extList(form.get('exts')), nm = form.get('name').trim() || ex.join(' ');
        if (!ex.length) { O.toast('Add at least one file ending'); return false; }
        var all = customs();
        if (f) { f.name = nm; f.exts = ex; } else { f = { id: Date.now().toString(36), name: nm, exts: ex }; all.push(f); }
        store.set('filters', all); filter = 'c:' + f.id; renderChips(); renderList();
      }
    });
  }
  function filterSheet(f) {
    O.sheet(f.name, [
      { label: 'Edit filter', icon: 'edit', run: function () { filterDialog(f); } },
      { label: 'Delete filter', icon: 'trash', run: function () { store.set('filters', customs().filter(function (x) { return x.id !== f.id; })); filter = 'All'; renderChips(); renderList(); } }
    ]);
  }
  function renderChips() {
    var host = $('#hChips'), o = savedOrder('o.chips'), cs = customs();
    var list = CHIPS.concat(cs.map(function (f) { return 'c:' + f.id; }));
    if (o) list.sort(function (a, b) { var x = o.indexOf(a), y = o.indexOf(b); return (x < 0 ? 99 : x) - (y < 0 ? 99 : y); });
    host.innerHTML = '';
    list.forEach(function (k) {
      var cf = k.charAt(0) === 'c' && k.charAt(1) === ':' ? findCustom(k) : null;
      if (k.charAt(1) === ':' && !cf) return;
      var b = el('button', 'h-chip h-r h-srt' + (k === filter ? ' on' : '')); b.dataset.k = k;
      b.innerHTML = CHECK; b.append(doc.createTextNode(cf ? cf.name : k));
      b.onclick = function () {
        if (cf && k === filter) { filterSheet(cf); return; }
        filter = k; renderChips(); renderList();
      };
      host.append(b);
    });
    var add = el('button', 'h-addchip h-r'); add.innerHTML = PLUS; add.setAttribute('aria-label', 'Add filter');
    add.append(doc.createTextNode('Filter'));
    add.onclick = function () { filterDialog(null); };
    host.append(add);
  }
  function extOf(n) { var i = n.lastIndexOf('.'); return i < 0 ? '' : n.slice(i + 1).toLowerCase(); }
  function visible() {
    var q = query.toLowerCase();
    return Array.from(O.files.values()).filter(function (e) {
      if (q && e.name.toLowerCase().indexOf(q) < 0) return false;
      if (filter === 'Favourites') return O.isFav(e.path);
      if (filter === 'PDF') return e.kind === 'pdf';
      if (filter === 'Office') return e.kind === 'office';
      if (filter.charAt(0) === 'c' && filter.charAt(1) === ':') { var cf = findCustom(filter); if (cf) return cf.exts.indexOf(extOf(e.name)) >= 0; }
      return true;
    });
  }
  function sameDay(t) { if (!t) return false; var a = new Date(t), b = new Date(); return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate(); }

  function attachRow(li, wrap, e) {
    li.addEventListener('pointerdown', function (ev) {
      if (ev.button > 0) return;
      var sx = ev.clientX, sy = ev.clientY, dx = 0, mode = null;
      var t = setTimeout(function () { if (mode) return; heldAt = Date.now(); O.sheet(e.name, O.fileActions(e)); }, 450);
      function cleanup() { clearTimeout(t); removeEventListener('pointermove', mv); removeEventListener('pointerup', up); removeEventListener('pointercancel', up); }
      function mv(m) {
        dx = m.clientX - sx; var dy = m.clientY - sy;
        if (!mode) {
          if (Math.abs(dx) > 10 && Math.abs(dx) > Math.abs(dy) * 1.4) { mode = 'x'; clearTimeout(t); li.style.transition = 'none'; wrap.classList.add('swiping'); }
          else if (Math.abs(dy) > 10) { mode = 'y'; cleanup(); return; }
          else return;
        }
        li.style.transform = 'translateX(' + dx + 'px)'; wrap.dataset.dir = dx > 0 ? 'r' : 'l';
      }
      function up() {
        cleanup(); if (mode !== 'x') return; swipedAt = Date.now();
        li.style.transition = 'transform .22s cubic-bezier(.2,0,0,1)'; li.style.transform = '';
        if (dx > 110) O.toggleFav(e.path);
        else if (dx < -110) setTimeout(function () { wrap.classList.remove('swiping'); O.removeEntry(e); }, 230);
        else setTimeout(function () { wrap.classList.remove('swiping'); li.style.transition = ''; }, 230);
      }
      addEventListener('pointermove', mv); addEventListener('pointerup', up); addEventListener('pointercancel', up);
    });
    li.addEventListener('click', function () { if (Date.now() - swipedAt < 350 || Date.now() - heldAt < 700) return; O.openEntry(e.id); });
    li.addEventListener('contextmenu', function (ev) { ev.preventDefault(); });
  }

  function renderList() {
    var host = $('#hList'), m = O.recentMap(), all = visible();
    all.sort(function (a, b) { return (m[b.path] || 0) - (m[a.path] || 0) || a.path.localeCompare(b.path); });
    var canFold = !query && filter === 'All' && all.length > 6;
    var limited = canFold && !showAll;
    var list = limited ? all.slice(0, 6) : all;
    $('#hShowAll').hidden = !canFold;
    $('#hShowAll').textContent = showAll ? 'Show less' : 'Show all files';
    host.innerHTML = '';
    if (!list.length) { host.append(el('div', 'h-empty', 'No files match.')); return; }
    var grp = null, last = null;
    list.forEach(function (e) {
      var g = sameDay(m[e.path]) ? 'Today' : 'Earlier';
      if (g !== last) { last = g; host.append(el('div', 'h-gl', g)); grp = el('div', 'h-grp'); host.append(grp); }
      var fav = O.isFav(e.path);
      var wrap = el('div', 'h-swrap');
      wrap.append(el('div', 'h-rv', '<span class="rl">' + (fav ? STARO : STAR) + (fav ? 'Unfavourite' : 'Favourite') + '</span><span class="rr">Remove' + TRASH + '</span>'));
      var li = el('div', 'h-li h-r', O.ftIcon(e) + '<div class="tx"><span class="n"></span><span class="m"></span></div>' + (fav ? '<span class="st">' + STAR + '</span>' : ''));
      li.querySelector('.n').textContent = e.name;
      var where = e.path.indexOf('/') >= 0 ? e.path.slice(0, e.path.lastIndexOf('/')) + ' · ' : '';
      li.querySelector('.m').textContent = where + (m[e.path] ? O.ago(m[e.path]) + ' · ' : '') + O.fmtSize(e.file.size);
      wrap.append(li); attachRow(li, wrap, e); grp.append(wrap);
    });
  }

  O.renderHome = function () {
    var has = O.files.size > 0;
    hero.hidden = has;
    $('#hChips').hidden = $('#hList').hidden = !has;
    renderTools();
    if (!has) { $('#hShowAll').hidden = true; return; }
    renderChips(); renderList();
  };

  /* ---------- wiring ---------- */
  var narrowMq = window.matchMedia('(max-width:839px)');
  $('#hMenu').onclick = function () { doc.body.classList.toggle(narrowMq.matches ? 'drawer-open' : 'drawer-closed'); };
  var bm = $('#btnMenu'); bm.setAttribute('aria-label', 'Back');
  bm.innerHTML = sv('<path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/>');
  bm.onclick = function () { if (!O.goHome()) doc.body.classList.toggle(narrowMq.matches ? 'drawer-open' : 'drawer-closed'); };
  var edEl = $('#editor'), edT;
  edEl.addEventListener('focusin', function () { clearTimeout(edT); doc.body.classList.add('ed-focus'); });
  edEl.addEventListener('focusout', function () { clearTimeout(edT); edT = setTimeout(function () { var a = doc.activeElement; if (!(a && a.closest && a.closest('#kbar'))) doc.body.classList.remove('ed-focus'); }, 250); });
  $('#hMore').onclick = function (ev) { $('#btnMore').onclick({ currentTarget: ev.currentTarget, stopPropagation: function () {} }); };
  $('#hQ').oninput = function (ev) { query = ev.target.value.trim(); showAll = false; if (O.files.size) renderList(); };
  $('#hShowAll').onclick = function () { showAll = !showAll; renderList(); if (!showAll) { var c = $('#content'); if (c) c.scrollTop = 0; } };
  fab.onclick = openSheet;
  (function () {
    var last = 0;
    empty.addEventListener('scroll', function () {
      var y = empty.scrollTop; if (Math.abs(y - last) < 6) return;
      fab.classList.toggle('small', y > last && y > 60); last = y;
    }, { passive: true });
  })();

  /* ---------- arrange mode + saved order ---------- */
  function arrange(on) { doc.body.classList.toggle('arrange', on); if (on) O.toast('Drag tools, filters and sections'); }
  var inArr = function () { return doc.body.classList.contains('arrange'); };
  function applyOrder() {
    var o = savedOrder('o.blocks') || ['tools', 'files'];
    o.forEach(function (id) { var b = blocks.querySelector('.h-blk[data-id="' + id + '"]'); if (b) blocks.append(b); });
  }
  sortable($('#hTools'), '.h-tool', { instant: inArr, onChange: function (els) { store.set('o.tools', els.map(function (e) { return e.dataset.t; })); } });
  sortable($('#hChips'), '.h-chip', { instant: inArr, onChange: function (els) { store.set('o.chips', els.map(function (e) { return e.dataset.k; })); } });
  sortable(blocks, '.h-blk', { handle: '.h-hnd', instant: function () { return true; }, enabled: inArr, onChange: function (els) { store.set('o.blocks', els.map(function (e) { return e.dataset.id; })); } });
  $('#hArrDone').onclick = function () { arrange(false); };
  $('#hArrReset').onclick = function () { ['o.tools', 'o.chips', 'o.blocks', 'o.sec'].forEach(lsDel); applyOrder(); O.renderHome(); if (O.resetSettingsOrder) O.resetSettingsOrder(); O.toast('Layout reset'); };
  new MutationObserver(function () { if (!doc.body.classList.contains('home') && inArr()) doc.body.classList.remove('arrange'); }).observe(doc.body, { attributes: true, attributeFilter: ['class'] });

  O.menuItems = O.menuItems || [];
  O.menuItems.push(function (e) { return e ? [] : [{ icon: 'tune', label: 'Rearrange home', run: function () { arrange(true); } }]; });

  /* ---------- edge swipe opens the drawer, swiping the drawer closes it ---------- */
  var drw = $('#drawer');
  edge.addEventListener('pointerdown', function (e) {
    if (e.button > 0 || !narrow.matches) return;
    var sx = e.clientX, dx = 0;
    function mv(ev) { dx = Math.max(0, ev.clientX - sx); var W = drw.offsetWidth; drw.style.transition = 'none'; drw.style.transform = 'translateX(' + (-W + Math.min(dx, W)) + 'px)'; }
    function up() {
      removeEventListener('pointermove', mv); removeEventListener('pointerup', up); removeEventListener('pointercancel', up);
      var W = drw.offsetWidth; drw.style.transition = ''; drw.style.transform = '';
      if (dx > W * 0.3) doc.body.classList.add('drawer-open');
    }
    addEventListener('pointermove', mv); addEventListener('pointerup', up); addEventListener('pointercancel', up);
  });
  if (drw) drw.addEventListener('pointerdown', function (e) {
    if (!narrow.matches || !doc.body.classList.contains('drawer-open')) return;
    var sx = e.clientX, dx = 0;
    function mv(ev) { dx = Math.min(0, ev.clientX - sx); if (dx < -8) { drw.style.transition = 'none'; drw.style.transform = 'translateX(' + dx + 'px)'; } }
    function up() {
      removeEventListener('pointermove', mv); removeEventListener('pointerup', up); removeEventListener('pointercancel', up);
      drw.style.transition = ''; drw.style.transform = '';
      if (dx < -70) doc.body.classList.remove('drawer-open');
    }
    addEventListener('pointermove', mv); addEventListener('pointerup', up); addEventListener('pointercancel', up);
  });

  /* ---------- back gesture support ---------- */
  var prev = O.backHandler;
  O.backHandler = function () {
    if (hsSheet.classList.contains('on')) { closeSheet(); return true; }
    if (inArr()) { arrange(false); return true; }
    return prev ? prev() : false;
  };

  applyOrder();
  if (doc.body.classList.contains('home')) O.renderHome();
})();
