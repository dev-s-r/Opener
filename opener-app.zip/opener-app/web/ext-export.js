/* Opener - convert and export: print / save as PDF, photos to PDF. */
(function () {
  'use strict';
  var O = window.__opener;
  if (!O) return;
  var NB = window.AndroidBridge || null;
  var esc = function (s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); };
  var pad = function (n) { return ('0' + n).slice(-2); };
  var stamp = function () { var d = new Date(); return d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '-' + pad(d.getHours()) + pad(d.getMinutes()); };

  function loadPdfLib() {
    if (window.PDFLib) return Promise.resolve(window.PDFLib);
    return new Promise(function (res, rej) {
      var list = ['vendor/pdf-lib.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js'];
      (function next() {
        var s = document.createElement('script'); s.src = list.shift();
        s.onload = function () { res(window.PDFLib); };
        s.onerror = function () { s.remove(); if (list.length) next(); else rej(new Error('PDF library failed to load')); };
        document.head.append(s);
      })();
    });
  }

  /* ---------- images -> PDF ---------- */
  function toJpeg(blob, maxDim) {
    return new Promise(function (res, rej) {
      var url = URL.createObjectURL(blob), img = new Image();
      img.onload = function () {
        var k = Math.min(1, maxDim / Math.max(img.naturalWidth, img.naturalHeight)), w = Math.round(img.naturalWidth * k), h = Math.round(img.naturalHeight * k);
        var c = document.createElement('canvas'); c.width = w; c.height = h;
        var ctx = c.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h); ctx.drawImage(img, 0, 0, w, h);
        URL.revokeObjectURL(url);
        c.toBlob(function (b) { b ? b.arrayBuffer().then(function (ab) { res({ bytes: new Uint8Array(ab), w: w, h: h }); }) : rej(new Error('Could not read an image')); }, 'image/jpeg', 0.9);
      };
      img.onerror = function () { URL.revokeObjectURL(url); rej(new Error('One of the files is not a picture Opener can read')); };
      img.src = url;
    });
  }
  // blobs: array of image Blobs/Files. Pages fit A4 (keeping each picture's shape).
  O.imagesToPdf = async function (blobs) {
    var PL = await loadPdfLib(), doc = await PL.PDFDocument.create();
    for (var i = 0; i < blobs.length; i++) {
      var j = await toJpeg(blobs[i], 2600), img = await doc.embedJpg(j.bytes);
      var land = j.w > j.h, pw = land ? 842 : 595, ph = land ? 595 : 842, k = Math.min(pw / j.w, ph / j.h);
      var w = j.w * k, h = j.h * k, page = doc.addPage([pw, ph]);
      page.drawImage(img, { x: (pw - w) / 2, y: (ph - h) / 2, width: w, height: h });
    }
    return new Blob([await doc.save()], { type: 'application/pdf' });
  };
  O.openNewFile = async function (blob, name) {
    var f = new File([blob], name, { type: blob.type });
    var e = O.addFile(f, name, null);
    await O.finish([e]);
    return e;
  };
  function pickImages() {
    return new Promise(function (res) {
      var inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*'; inp.multiple = true; inp.style.display = 'none';
      inp.onchange = function () { res(Array.prototype.slice.call(inp.files || [])); inp.remove(); };
      document.body.append(inp); inp.click();
    });
  }
  async function photosToPdf() {
    var files = await pickImages();
    if (!files.length) return;
    try {
      O.toast('Making the PDF…');
      files.sort(function (a, b) { return a.name < b.name ? -1 : 1; });
      var pdf = await O.imagesToPdf(files);
      await O.openNewFile(pdf, 'Photos-' + stamp() + '.pdf');
      O.toast('PDF ready. Tap Save in the PDF screen to download it.');
    } catch (e) { O.toast('Could not make the PDF: ' + (e && e.message ? e.message : e)); }
  }

  /* ---------- print / save as PDF ---------- */
  var PRINT_CSS = '<style>@media print{.slide,tr,img{break-inside:avoid}body{padding:0!important}}</style>';
  O.printHtml = function (html, name) {
    html = String(html).replace(/<script[\s\S]*?<\/script>/gi, '') + PRINT_CSS;
    if (NB && NB.printHtml) { NB.printHtml(html, name || 'Opener'); return; }
    var f = document.createElement('iframe'); f.style.cssText = 'position:fixed;left:-9999px;width:800px;height:600px;border:0';
    f.srcdoc = html; document.body.append(f);
    f.onload = function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (e) { O.toast('Printing is not available here'); } setTimeout(function () { f.remove(); }, 60000); };
  };
  function blobDataUrl(blob) { return new Promise(function (res, rej) { var r = new FileReader(); r.onload = function () { res(r.result); }; r.onerror = rej; r.readAsDataURL(blob); }); }
  async function htmlFor(e) {
    if (e.kind === 'office') {
      var f = document.querySelector('.ov-frame');
      if (!f || !f.srcdoc) throw new Error('Wait for the file to finish opening');
      return f.srcdoc;
    }
    if (e.kind === 'html' || e.kind === 'md') {
      var pf = document.querySelector('#frame');
      if (pf && pf.srcdoc) return pf.srcdoc;
      return '<pre style="white-space:pre-wrap">' + esc(e.text != null ? e.text : await e.file.text()) + '</pre>';
    }
    if (e.kind === 'img') return '<body style="margin:0"><img style="max-width:100%" src="' + await blobDataUrl(e.file) + '">';
    if (e.kind === 'zip' || e.kind === 'media' || e.kind === 'bin') throw new Error('There is nothing to print for this kind of file');
    return '<body><pre style="white-space:pre-wrap;word-break:break-word;font:12px/1.5 ui-monospace,Menlo,monospace">' + esc(e.text != null ? e.text : await e.file.text()) + '</pre></body>';
  }
  async function printPdfFile(e, name) {
    if (!(NB && NB.printPdfBegin)) { window.open(URL.createObjectURL(e.file), '_blank'); return; }
    var buf = new Uint8Array(await e.file.arrayBuffer()), CH = 3 * 1024 * 1024;
    NB.printPdfBegin();
    for (var i = 0; i < buf.length; i += CH) {
      var s = '', part = buf.subarray(i, i + CH);
      for (var j = 0; j < part.length; j += 0x8000) s += String.fromCharCode.apply(null, part.subarray(j, j + 0x8000));
      NB.printPdfChunk(btoa(s));
    }
    NB.printPdfEnd(name);
  }
  O.printCurrent = async function (e) {
    try {
      var name = e.name.replace(/\.[^.]+$/, '');
      if (e.kind === 'pdf') await printPdfFile(e, name); else O.printHtml(await htmlFor(e), name);
    } catch (err) { O.toast(err && err.message ? err.message : String(err)); }
  };

  /* ---------- menu entries ---------- */
  O.menuItems = O.menuItems || [];
  O.menuItems.push(function (e) {
    return [
      { icon: 'file', label: 'Print / Save as PDF', hidden: !e || e.kind === 'zip' || e.kind === 'media' || e.kind === 'bin', run: function () { O.printCurrent(e); } },
      { icon: 'image', label: 'Create PDF from photos', run: photosToPdf }
    ];
  });
})();
