// Copies the PWA from /web into /www and injects the native bridge.
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const src = path.join(root, 'web');
const out = path.join(root, 'www');

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });

// The service worker is only for the browser/PWA version, the app doesn't need it.
for (const f of fs.readdirSync(src)) {
  if (f === 'sw.js') continue;
  fs.cpSync(path.join(src, f), path.join(out, f), { recursive: true });
}
fs.copyFileSync(path.join(root, 'scripts', 'native-bridge.js'), path.join(out, 'native-bridge.js'));

// Bundle pdf.js so PDFs open offline (installed by npm from package.json).
const pj = path.join(root, 'node_modules', 'pdfjs-dist', 'build');
if (fs.existsSync(path.join(pj, 'pdf.min.js'))) {
  fs.mkdirSync(path.join(out, 'vendor', 'pdfjs'), { recursive: true });
  for (const f of ['pdf.min.js', 'pdf.worker.min.js']) fs.copyFileSync(path.join(pj, f), path.join(out, 'vendor', 'pdfjs', f));
  console.log('pdf.js bundled');
} else {
  console.warn('pdfjs-dist not installed - PDFs will need internet');
}

const file = path.join(out, 'index.html');
let html = fs.readFileSync(file, 'utf8');
if (!html.includes('native-bridge.js')) {
  if (!/<head[^>]*>/i.test(html)) throw new Error('No <head> found in index.html');
  html = html.replace(/<head[^>]*>/i, m => m + '\n<script src="native-bridge.js"></script>');
  fs.writeFileSync(file, html);
}
console.log('www/ ready');
