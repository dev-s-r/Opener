/* Opener - basic editing of Word (.docx) text and spreadsheet (.xlsx, .csv, .tsv) cells. */
(function () {
  'use strict';
  var O = window.__opener;
  if (!O) return;

  var css = document.createElement('style');
  css.textContent = '.ed-on{background:var(--primary)!important;color:var(--on-primary)!important}.ed-note{padding:8px 14px;font-size:13px;background:var(--primary-c);color:var(--on-primary-c)}';
  document.head.append(css);

  var FRAME_CSS = '[data-p]:not([data-ro]){outline:1px dashed #8aa4d6;outline-offset:2px;border-radius:2px}[data-p][data-ro]{opacity:.85}td[data-r]{cursor:pointer}td[data-r]:hover,td[data-r]:active{background:#e7f0ff}';

  /* ---------- xml helpers ---------- */
  function kids(el) { return el ? Array.prototype.slice.call(el.children) : []; }
  function kid(el, n) { var c = kids(el); for (var i = 0; i < c.length; i++) if (c[i].localName === n) return c[i]; return null; }
  function ser(doc) { return new TextEncoder().encode(new XMLSerializer().serializeToString(doc)); }
  function parse(u8) { return new DOMParser().parseFromString(new TextDecoder('utf-8').decode(u8), 'application/xml'); }
  var NS_W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
  function colIdx(ref) { var m = /^([A-Z]+)/.exec(ref), n = 0; for (var i = 0; i < m[1].length; i++) n = n * 26 + (m[1].charCodeAt(i) - 64); return n - 1; }
  function colName(n) { var s = ''; n++; while (n > 0) { var m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; }

  async function repack(Z, replaced, removed) {
    var list = [], names = Object.keys(Z);
    for (var i = 0; i < names.length; i++) {
      var n = names[i];
      if (removed && removed[n]) continue;
      list.push({ path: n, data: replaced[n] || await Z[n].bytes() });
    }
    // [Content_Types].xml first, as Office expects
    list.sort(function (a, b) { return (a.path === '[Content_Types].xml' ? -1 : 0) - (b.path === '[Content_Types].xml' ? -1 : 0); });
    return O.makeZip(list);
  }

  /* ---------- text helpers for the editable frame ---------- */
  function textOf(el) {
    var out = '';
    (function walk(n, first) {
      Array.prototype.forEach.call(n.childNodes, function (c, i) {
        if (c.nodeType === 3) out += c.nodeValue.replace(/\u00a0/g, ' ');
        else if (c.nodeType === 1) {
          if (c.hasAttribute && c.hasAttribute('data-pre')) return;
          if (c.nodeName === 'BR') out += '\n';
          else if (c.nodeName === 'DIV' || c.nodeName === 'P') { if (out && !/\n$/.test(out)) out += '\n'; walk(c); }
          else walk(c);
        }
      });
    })(el);
    return out.replace(/\n$/, '');
  }

  /* ---------- DOCX ---------- */
  function collectParas(body) {
    var list = [];
    (function walk(parent) {
      kids(parent).forEach(function (c) {
        if (c.localName === 'p') list.push(c);
        else if (c.localName === 'tbl') kids(c).forEach(function (tr) { if (tr.localName === 'tr') kids(tr).forEach(function (tc) { if (tc.localName === 'tc') walk(tc); }); });
        else if (c.localName === 'sdt') { var sc = kid(c, 'sdtContent'); if (sc) walk(sc); }
      });
    })(body);
    return list;
  }
  function rewriteParagraph(doc, p, text) {
    var rpr = null;
    var seen = false;
    (function find(n) { kids(n).forEach(function (c) { if (seen) return; if (c.localName === 'r') { seen = true; var r = kid(c, 'rPr'); if (r) rpr = r.cloneNode(true); } else if (c.localName === 'hyperlink' || c.localName === 'smartTag') find(c); }); })(p);
    kids(p).forEach(function (c) { if (c.localName !== 'pPr') p.removeChild(c); });
    var run = doc.createElementNS(NS_W, 'w:r');
    if (rpr) run.appendChild(rpr);
    text.split('\n').forEach(function (line, li) {
      if (li) run.appendChild(doc.createElementNS(NS_W, 'w:br'));
      line.split('\t').forEach(function (seg, si) {
        if (si) run.appendChild(doc.createElementNS(NS_W, 'w:tab'));
        if (seg !== '') { var t = doc.createElementNS(NS_W, 'w:t'); t.setAttributeNS('http://www.w3.org/XML/1998/namespace', 'xml:space', 'preserve'); t.textContent = seg; run.appendChild(t); }
      });
    });
    p.appendChild(run);
  }
  async function saveDocx(S, frame) {
    var info = S.data.docx, Z = info.Z, d = frame.contentDocument;
    var doc = parse(await Z[info.main].bytes()), body = kid(doc.documentElement, 'body'), paras = collectParas(body), changed = 0;
    Array.prototype.forEach.call(d.querySelectorAll('[data-p]:not([data-ro])'), function (el) {
      var i = +el.getAttribute('data-p'), now = textOf(el);
      if (S.orig[i] !== undefined && now !== S.orig[i] && paras[i]) { rewriteParagraph(doc, paras[i], now); changed++; }
    });
    if (!changed) return null;
    return repack(Z, (function () { var o = {}; o[info.main] = ser(doc); return o; })());
  }

  /* ---------- XLSX ---------- */
  function serialFromText(t) {
    var m = /^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{2}))?$/.exec(t.trim());
    if (!m) return null;
    return Date.UTC(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0)) / 86400000 + 25569;
  }
  function cellValue(cell, text) {
    // returns { num: Number|null, str: String }
    var t = String(text);
    if (t.trim() === '') return { empty: true };
    if (cell && cell.d) { var s = serialFromText(t); if (s !== null) return { num: s }; }
    if (cell && cell.p && /^-?\d+(\.\d+)?\s*%$/.test(t.trim())) return { num: parseFloat(t) / 100 };
    if (/^-?\d+(\.\d+)?([eE][+-]?\d+)?$/.test(t.trim())) return { num: parseFloat(t) };
    return { str: t };
  }
  async function saveXlsx(S) {
    var Z = S.data.Z, replaced = {}, removed = {}, any = false;
    for (var si = 0; si < S.data.sheets.length; si++) {
      var sh = S.data.sheets[si];
      if (!sh.edits || !Object.keys(sh.edits).length || !sh.path) continue;
      any = true;
      var doc = parse(await Z[sh.path].bytes()), root = doc.documentElement, ns = root.namespaceURI, sd = kid(root, 'sheetData');
      var rowEls = {};
      kids(sd).forEach(function (r) { rowEls[+r.getAttribute('r')] = r; });
      Object.keys(sh.edits).forEach(function (key) {
        var parts = key.split(','), r = +parts[0], c = +parts[1], ed = sh.edits[key], ref = colName(c) + (r + 1);
        var row = rowEls[r + 1];
        if (!row) {
          row = doc.createElementNS(ns, 'row'); row.setAttribute('r', String(r + 1));
          var after = null; Object.keys(rowEls).forEach(function (k) { if (+k > r + 1 && (!after || +k < after)) after = +k; });
          if (after) sd.insertBefore(row, rowEls[after]); else sd.appendChild(row);
          rowEls[r + 1] = row;
        }
        var cellEl = null;
        kids(row).forEach(function (ce) { if (ce.getAttribute('r') === ref) cellEl = ce; });
        if (!cellEl) {
          cellEl = doc.createElementNS(ns, 'c'); cellEl.setAttribute('r', ref);
          var next = null; kids(row).forEach(function (ce) { if (!next && colIdx(ce.getAttribute('r')) > c) next = ce; });
          if (next) row.insertBefore(cellEl, next); else row.appendChild(cellEl);
        }
        kids(cellEl).forEach(function (ch) { cellEl.removeChild(ch); });
        cellEl.removeAttribute('t');
        var val = ed.val;
        if (val.empty) return;
        if (val.num !== undefined) { var v = doc.createElementNS(ns, 'v'); v.textContent = String(val.num); cellEl.appendChild(v); }
        else {
          cellEl.setAttribute('t', 'inlineStr');
          var is = doc.createElementNS(ns, 'is'), t = doc.createElementNS(ns, 't');
          t.setAttributeNS('http://www.w3.org/XML/1998/namespace', 'xml:space', 'preserve'); t.textContent = val.str;
          is.appendChild(t); cellEl.appendChild(is);
        }
      });
      replaced[sh.path] = ser(doc);
    }
    if (!any) return null;
    // formulas were replaced by values, so drop the calculation chain and recalculate on open
    if (Z['xl/calcChain.xml']) {
      removed['xl/calcChain.xml'] = true;
      var ct = parse(await Z['[Content_Types].xml'].bytes());
      Array.prototype.slice.call(ct.getElementsByTagNameNS('*', 'Override')).forEach(function (o) { if (/calcChain/.test(o.getAttribute('PartName') || '')) o.parentNode.removeChild(o); });
      replaced['[Content_Types].xml'] = ser(ct);
      var wr = parse(await Z['xl/_rels/workbook.xml.rels'].bytes());
      Array.prototype.slice.call(wr.getElementsByTagNameNS('*', 'Relationship')).forEach(function (o) { if (/calcChain/.test(o.getAttribute('Type') || '')) o.parentNode.removeChild(o); });
      replaced['xl/_rels/workbook.xml.rels'] = ser(wr);
    }
    var wb = parse(await Z['xl/workbook.xml'].bytes()), cp = wb.getElementsByTagNameNS('*', 'calcPr')[0];
    if (cp) cp.setAttribute('fullCalcOnLoad', '1');
    else { var c2 = wb.createElementNS(wb.documentElement.namespaceURI, 'calcPr'); c2.setAttribute('fullCalcOnLoad', '1'); wb.documentElement.appendChild(c2); }
    replaced['xl/workbook.xml'] = ser(wb);
    return repack(Z, replaced, removed);
  }

  /* ---------- CSV ---------- */
  function saveCsvText(S, ext) {
    var sh = S.data.sheets[0], delim = ext === 'tsv' ? '\t' : (S.csvDelim || ','), rows = [];
    for (var r = 0; r < sh.nrows; r++) {
      var row = sh.rows[r] || {}, cells = [];
      for (var c = 0; c < sh.cols; c++) {
        var v = row[c] ? String(row[c].v) : '';
        cells.push(v.indexOf(delim) >= 0 || /["\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v);
      }
      rows.push(cells.join(delim));
    }
    return new Blob([rows.join('\r\n') + '\r\n'], { type: 'text/csv' });
  }

  /* ---------- dialogs ---------- */
  function cellDialog(ref, current, note, cb) {
    var scrim = document.createElement('div'); scrim.className = 'dscrim'; scrim.id = 'zvScrim';
    scrim.innerHTML = '<div class="dialog" role="dialog"><h3></h3><p style="margin:0 0 10px;font-size:13px"></p><textarea rows="4" style="width:100%;box-sizing:border-box;border-radius:12px;border:1px solid var(--outline-v);background:var(--surface);color:var(--on-surface);padding:10px 12px;font:inherit;font-size:16px"></textarea><div class="actions"><button class="btn text sl" data-a="no">Cancel</button><button class="btn text sl" data-a="clear">Clear</button><button class="btn text sl" data-a="ok">OK</button></div></div>';
    scrim.querySelector('h3').textContent = 'Edit cell ' + ref;
    scrim.querySelector('p').textContent = note || '';
    var ta = scrim.querySelector('textarea'); ta.value = current;
    document.body.append(scrim); setTimeout(function () { ta.focus(); ta.select(); }, 80);
    scrim.addEventListener('click', function (ev) {
      var a = ev.target.getAttribute && ev.target.getAttribute('data-a');
      if (!a && ev.target !== scrim) return;
      scrim.remove();
      if (a === 'ok') cb(ta.value); else if (a === 'clear') cb('');
    });
  }

  /* ---------- wiring ---------- */
  O.officeHook = function (ctx) {
    var e = ctx.e, ext = ctx.ext, root = ctx.root;
    var kind = /^(docx|docm)$/.test(ext) ? 'docx' : /^(xlsx|xlsm)$/.test(ext) ? 'xlsx' : /^(csv|tsv)$/.test(ext) ? 'csv' : '';
    if (!kind) return;
    var editing = false, note = null;
    function b(label, fn) { var x = document.createElement('button'); x.className = 'ov-btn'; x.type = 'button'; x.textContent = label; x.onclick = fn; ctx.tools.append(x); return x; }
    var editBtn = b('Edit', function () { setEditing(!editing); });
    var saveBtn = b('Save', save); saveBtn.hidden = true;
    var rowBtn = b('+ Row', function () { var S = ctx.getS(), sh = S.data.sheets[S.sheet || 0]; sh.nrows++; ctx.redraw(); }); rowBtn.hidden = true;
    var colBtn = b('+ Column', function () { var S = ctx.getS(), sh = S.data.sheets[S.sheet || 0]; sh.cols++; ctx.redraw(); }); colBtn.hidden = true;

    function setEditing(on) {
      editing = on; editBtn.textContent = on ? 'Done' : 'Edit'; editBtn.classList.toggle('ed-on', on);
      saveBtn.hidden = !on; rowBtn.hidden = colBtn.hidden = !on || kind === 'docx';
      if (note) { note.remove(); note = null; }
      if (on) {
        note = document.createElement('div'); note.className = 'ed-note';
        note.textContent = kind === 'docx' ? 'Tap text to change it, then tap Save. Words in a changed paragraph lose their mixed formatting. Pictures and tables stay.' : 'Tap a cell to change it, then tap Save.';
        ctx.tools.after(note);
      }
      apply();
    }
    function apply() {
      var fr = ctx.frame(), S = ctx.getS(); if (!fr || !S) return;
      var d; try { d = fr.contentDocument; } catch (x) { return; }
      if (!d || !d.body) return;
      if (!d.getElementById('edcss')) { var st = d.createElement('style'); st.id = 'edcss'; st.textContent = editing ? FRAME_CSS : ''; d.head.append(st); }
      else d.getElementById('edcss').textContent = editing ? FRAME_CSS : '';
      if (kind === 'docx') {
        if (!S.orig) { S.orig = {}; Array.prototype.forEach.call(d.querySelectorAll('[data-p]'), function (el) { S.orig[+el.getAttribute('data-p')] = textOf(el); }); }
        Array.prototype.forEach.call(d.querySelectorAll('[data-p]:not([data-ro])'), function (el) { if (editing) el.setAttribute('contenteditable', 'true'); else el.removeAttribute('contenteditable'); });
        if (!d.__edBound) {
          d.__edBound = true;
          d.addEventListener('input', function () { clearTimeout(d.__t); d.__t = setTimeout(function () { var clone = d.body.cloneNode(true); Array.prototype.forEach.call(clone.querySelectorAll('[contenteditable]'), function (n) { n.removeAttribute('contenteditable'); }); S.data.html = clone.innerHTML; S.dirty = true; }, 400); });
        }
      } else {
        if (!d.__edBound) {
          d.__edBound = true;
          d.addEventListener('click', function (ev) {
            if (!editing) return;
            var td = ev.target.closest && ev.target.closest('td[data-r]'); if (!td) return;
            ev.preventDefault();
            var S2 = ctx.getS(), sh = S2.data.sheets[S2.sheet || 0], r = +td.getAttribute('data-r'), c = +td.getAttribute('data-c');
            var cell = (sh.rows[r] || {})[c], ref = colName(c) + (r + 1);
            var warn = cell && cell.f ? 'This cell has a formula. Saving replaces it with what you type.' : '';
            cellDialog(ref, cell ? String(cell.v) : '', warn, function (txt) {
              var val = kind === 'xlsx' ? cellValue(cell, txt) : { str: txt };
              (sh.rows[r] = sh.rows[r] || {})[c] = txt === '' ? undefined : { v: txt, n: kind === 'xlsx' ? val.num !== undefined && !(cell && (cell.d || cell.p)) : /^-?\d+([.,]\d+)?$/.test(txt.trim()), d: cell && cell.d, p: cell && cell.p };
              if (txt === '') delete sh.rows[r][c];
              if (r >= sh.nrows) sh.nrows = r + 1; if (c >= sh.cols) sh.cols = c + 1;
              sh.edits = sh.edits || {}; sh.edits[r + ',' + c] = { val: txt === '' ? { empty: true } : val };
              S2.dirty = true; ctx.redraw();
            });
          });
        }
      }
    }
    root.__onFrame = function () { apply(); };

    async function save() {
      var S = ctx.getS(); if (!S) return;
      try {
        O.toast('Saving…');
        var blob = null, newName = e.name;
        if (kind === 'docx') blob = await saveDocx(S, ctx.frame());
        else if (kind === 'xlsx') blob = await saveXlsx(S);
        else { var any = S.data.sheets[0].edits && Object.keys(S.data.sheets[0].edits).length; blob = any ? saveCsvText(S, ext) : null; }
        if (!blob) { O.toast('No changes to save'); return; }
        var type = kind === 'docx' ? 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' : kind === 'xlsx' ? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' : 'text/csv';
        var file = new File([blob], e.name, { type: type });
        e.file = file; e.text = null; if (e.url) { URL.revokeObjectURL(e.url); e.url = null; }
        O.persistMany([e]);
        O.downloadBlob(blob, e.name.replace(/(\.[^.]+)$/, '-edited$1'));
        editing = false;
        await ctx.reload();
        O.toast('Saved. A copy was also downloaded.');
      } catch (err) { console.warn(err); O.toast('Could not save: ' + (err && err.message ? err.message : err)); }
    }
  };
})();
