/* Opener - scan documents with the camera (or from photos) and save them as a PDF. */
(function () {
  'use strict';
  var O = window.__opener;
  if (!O) return;
  var pad = function (n) { return ('0' + n).slice(-2); };
  var stamp = function () { var d = new Date(); return d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '-' + pad(d.getHours()) + pad(d.getMinutes()); };
  var MAXW = 2400;

  var css = document.createElement('style');
  css.textContent = [
    '#scanOv{position:fixed;inset:0;z-index:90;background:var(--surface);color:var(--on-surface);display:flex;flex-direction:column;padding-top:env(safe-area-inset-top,0px)}',
    '.sc-top{display:flex;align-items:center;gap:8px;padding:8px 10px;border-bottom:1px solid var(--outline-v);background:var(--surface-low)}',
    '.sc-ctl .sc-b{flex:none}.sc-top h2{flex:1;margin:0;font-size:18px;font-weight:500}',
    '.sc-b{height:40px;min-width:40px;padding:0 14px;border-radius:20px;background:var(--surface-high);color:var(--on-surface);font-size:14px;font-weight:500;white-space:nowrap;display:inline-flex;align-items:center;justify-content:center}',
    '.sc-b.prim{background:var(--primary);color:var(--on-primary)}.sc-b.on{background:var(--primary-c);color:var(--on-primary-c)}.sc-b:disabled{opacity:.4}',
    '.sc-stage{flex:1;min-height:0;display:flex;align-items:center;justify-content:center;background:var(--surface-mid);position:relative;overflow:hidden;touch-action:none}',
    '.sc-wrap{position:relative;line-height:0}',
    '.sc-wrap canvas{max-width:100%;max-height:100%;box-shadow:0 1px 8px rgba(0,0,0,.35);background:#fff}',
    '.sc-crop{position:absolute;border:2px solid #1a73e8;box-shadow:0 0 0 9999px rgba(0,0,0,.45);touch-action:none}',
    '.sc-h{position:absolute;width:34px;height:34px;margin:-17px 0 0 -17px;border-radius:50%;background:#1a73e8;border:3px solid #fff;touch-action:none}',
    '.sc-empty{padding:24px;text-align:center;color:var(--on-surface-v);max-width:320px;line-height:1.5}',
    '.sc-ctl{display:flex;gap:6px;padding:8px 10px;overflow-x:auto;border-top:1px solid var(--outline-v);background:var(--surface-low)}',
    '.sc-strip{display:flex;gap:8px;padding:8px 10px;overflow-x:auto;background:var(--surface-low);border-top:1px solid var(--outline-v);align-items:center;min-height:74px}',
    '.sc-th{flex:none;width:52px;height:64px;border-radius:6px;border:2px solid var(--outline-v);object-fit:cover;background:#fff}',
    '.sc-th.on{border-color:var(--primary);box-shadow:0 0 0 2px var(--primary)}',
    '.sc-add{display:flex;gap:8px;padding:8px 10px calc(10px + env(safe-area-inset-bottom,0px));background:var(--surface-low)}',
    '.sc-add .sc-b{flex:1;height:48px;border-radius:24px;font-size:15px}'
  ].join('\n');
  document.head.append(css);

  var ov = null, pages = [], cur = 0, cropMode = false, prevBack = null;

  function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }

  async function loadImage(file) {
    var bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
    var k = Math.min(1, MAXW / Math.max(bmp.width, bmp.height)), c = document.createElement('canvas');
    c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
    if (bmp.close) bmp.close();
    return c;
  }

  /* ---------- picture processing ---------- */
  function rotated(src, rot) {
    if (!rot) return src;
    var c = document.createElement('canvas'), sw = rot % 180 ? src.height : src.width, sh = rot % 180 ? src.width : src.height;
    c.width = sw; c.height = sh;
    var x = c.getContext('2d'); x.translate(sw / 2, sh / 2); x.rotate(rot * Math.PI / 180); x.drawImage(src, -src.width / 2, -src.height / 2);
    return c;
  }
  // Flatten uneven lighting: divide by a blurred copy of the picture.
  function normalise(canvas, bw) {
    var w = canvas.width, h = canvas.height, sc = Math.max(1, Math.round(Math.max(w, h) / 160));
    var small = document.createElement('canvas'); small.width = Math.max(1, Math.round(w / sc)); small.height = Math.max(1, Math.round(h / sc));
    var sx = small.getContext('2d'); sx.filter = 'blur(2px)'; sx.drawImage(canvas, 0, 0, small.width, small.height);
    var big = document.createElement('canvas'); big.width = w; big.height = h;
    var bx = big.getContext('2d'); bx.imageSmoothingEnabled = true; bx.imageSmoothingQuality = 'high'; bx.drawImage(small, 0, 0, w, h);
    var cx = canvas.getContext('2d'), a = cx.getImageData(0, 0, w, h), b = bx.getImageData(0, 0, w, h), d = a.data, g = b.data;
    // use the brightest local background as white
    for (var i = 0; i < d.length; i += 4) {
      var bgl = Math.max(40, (g[i] * 0.299 + g[i + 1] * 0.587 + g[i + 2] * 0.114));
      var f = 255 / bgl;
      var r = Math.min(255, d[i] * f), gg = Math.min(255, d[i + 1] * f), bb = Math.min(255, d[i + 2] * f);
      if (bw) {
        var y = r * 0.299 + gg * 0.587 + bb * 0.114, v = y < 175 ? Math.max(0, (y - 40) * 0.5) : 255;
        d[i] = d[i + 1] = d[i + 2] = v;
      } else {
        // soft contrast curve
        d[i] = ctr(r); d[i + 1] = ctr(gg); d[i + 2] = ctr(bb);
      }
    }
    cx.putImageData(a, 0, 0);
    return canvas;
  }
  function ctr(v) { v = (v / 255 - 0.5) * 1.25 + 0.5 + 0.04; return v < 0 ? 0 : v > 1 ? 255 : v * 255; }
  // Final picture for a page (rotation, crop, filter) limited to maxDim.
  function process(p, maxDim) {
    var r = rotated(p.src, p.rot), cr = p.crop;
    var sx = Math.round(cr.x * r.width), sy = Math.round(cr.y * r.height), sw = Math.max(8, Math.round(cr.w * r.width)), sh = Math.max(8, Math.round(cr.h * r.height));
    var k = Math.min(1, maxDim / Math.max(sw, sh)), c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(sw * k)); c.height = Math.max(1, Math.round(sh * k));
    c.getContext('2d').drawImage(r, sx, sy, sw, sh, 0, 0, c.width, c.height);
    if (p.filter === 'clean') normalise(c, false); else if (p.filter === 'bw') normalise(c, true);
    return c;
  }

  /* ---------- UI ---------- */
  function addPages(canvases) {
    canvases.forEach(function (c) { pages.push({ src: c, rot: 0, crop: { x: 0, y: 0, w: 1, h: 1 }, filter: 'clean', thumb: null }); });
    cur = pages.length - 1; cropMode = false; draw();
  }
  async function pick(camera) {
    return new Promise(function (res) {
      var inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*'; inp.style.display = 'none';
      if (camera) inp.setAttribute('capture', 'environment'); else inp.multiple = true;
      inp.onchange = function () { res(Array.prototype.slice.call(inp.files || [])); inp.remove(); };
      document.body.append(inp); inp.click();
    });
  }
  async function add(camera) {
    var files = await pick(camera); if (!files.length) return;
    try {
      O.toast('Loading…');
      var list = [];
      files.sort(function (a, b) { return a.name < b.name ? -1 : 1; });
      for (var i = 0; i < files.length; i++) list.push(await loadImage(files[i]));
      addPages(list);
    } catch (e) { O.toast('Could not read that picture'); }
  }
  function close(ask) {
    if (ask && pages.length && !confirm('Discard the ' + pages.length + ' scanned page(s)?')) return;
    if (ov) { ov.remove(); ov = null; }
    pages = []; cur = 0; cropMode = false;
    if (prevBack !== null) { window.__nativeBack = prevBack; prevBack = null; }
  }
  async function done() {
    if (!pages.length) return;
    try {
      O.toast('Making the PDF…');
      var blobs = [];
      for (var i = 0; i < pages.length; i++) {
        var c = process(pages[i], MAXW);
        blobs.push(await new Promise(function (r) { c.toBlob(r, 'image/jpeg', 0.9); }));
      }
      var pdf = await O.imagesToPdf(blobs);
      close(false);
      await O.openNewFile(pdf, 'Scan-' + stamp() + '.pdf');
      O.toast('Scan ready. Tap Save in the PDF screen to download it.');
    } catch (e) { O.toast('Could not make the PDF: ' + (e && e.message ? e.message : e)); }
  }

  function draw() {
    if (!ov) return;
    var stage = ov.querySelector('.sc-stage'), strip = ov.querySelector('.sc-strip'), ctl = ov.querySelector('.sc-ctl');
    stage.innerHTML = ''; strip.innerHTML = ''; ctl.innerHTML = '';
    ov.querySelector('.sc-count').textContent = pages.length ? 'Page ' + (cur + 1) + ' of ' + pages.length : 'No pages yet';
    ov.querySelector('.sc-done').disabled = !pages.length;
    if (!pages.length) {
      stage.append(el('div', 'sc-empty', 'Tap "Take photo" to scan a page with the camera, or "From photos" to use pictures you already have. Add as many pages as you like.'));
      ctl.hidden = true; strip.hidden = true; return;
    }
    ctl.hidden = false; strip.hidden = false;
    var p = pages[cur], c = process(p, cropMode ? 1200 : 1600);
    if (cropMode) {
      var raw = rotated(p.src, p.rot), full = document.createElement('canvas'), k = Math.min(1, 1400 / Math.max(raw.width, raw.height));
      full.width = Math.round(raw.width * k); full.height = Math.round(raw.height * k);
      full.getContext('2d').drawImage(raw, 0, 0, full.width, full.height); c = full;
    }
    var wrap = el('div', 'sc-wrap'); wrap.append(c); stage.append(wrap);
    if (cropMode) cropUi(wrap, c, p);
    // filter + tools
    function b(label, fn, on) { var x = el('button', 'sc-b' + (on ? ' on' : ''), label); x.type = 'button'; x.onclick = fn; ctl.append(x); return x; }
    [['Original', 'color'], ['Clean', 'clean'], ['B&W', 'bw']].forEach(function (f) { b(f[0], function () { p.filter = f[1]; p.thumb = null; draw(); }, p.filter === f[1]); });
    b('⟲', function () { p.rot = (p.rot + 270) % 360; p.crop = { x: 0, y: 0, w: 1, h: 1 }; p.thumb = null; draw(); }).setAttribute('aria-label', 'Rotate left');
    b('⟳', function () { p.rot = (p.rot + 90) % 360; p.crop = { x: 0, y: 0, w: 1, h: 1 }; p.thumb = null; draw(); }).setAttribute('aria-label', 'Rotate right');
    b(cropMode ? 'Apply crop' : 'Crop', function () { cropMode = !cropMode; if (!cropMode) p.thumb = null; draw(); }, cropMode);
    if (cropMode) b('Reset crop', function () { p.crop = { x: 0, y: 0, w: 1, h: 1 }; draw(); });
    b('Delete', function () { pages.splice(cur, 1); cur = Math.max(0, Math.min(cur, pages.length - 1)); cropMode = false; draw(); });
    if (pages.length > 1) {
      b('◀', function () { if (cur > 0) { var t = pages[cur]; pages[cur] = pages[cur - 1]; pages[cur - 1] = t; cur--; draw(); } }).setAttribute('aria-label', 'Move earlier');
      b('▶', function () { if (cur < pages.length - 1) { var t = pages[cur]; pages[cur] = pages[cur + 1]; pages[cur + 1] = t; cur++; draw(); } }).setAttribute('aria-label', 'Move later');
    }
    pages.forEach(function (pg, i) {
      if (!pg.thumb) { var t = process(pg, 160); pg.thumb = t.toDataURL('image/jpeg', 0.6); }
      var im = el('img', 'sc-th' + (i === cur ? ' on' : '')); im.src = pg.thumb; im.alt = 'Page ' + (i + 1);
      im.onclick = function () { cur = i; cropMode = false; draw(); };
      strip.append(im);
    });
  }

  // draggable crop rectangle (fractions of the rotated picture)
  function cropUi(wrap, canvas, p) {
    var box = el('div', 'sc-crop'), hs = [];
    wrap.append(box);
    var cr = p.crop;
    function place() {
      var W = canvas.clientWidth, H = canvas.clientHeight;
      box.style.left = cr.x * W + 'px'; box.style.top = cr.y * H + 'px'; box.style.width = cr.w * W + 'px'; box.style.height = cr.h * H + 'px';
      hs.forEach(function (h) { h.el.style.left = (cr.x + (h.fx ? cr.w : 0)) * W + 'px'; h.el.style.top = (cr.y + (h.fy ? cr.h : 0)) * H + 'px'; });
    }
    [[0, 0], [1, 0], [0, 1], [1, 1]].forEach(function (c) {
      var h = el('div', 'sc-h'); wrap.append(h); hs.push({ el: h, fx: c[0], fy: c[1] });
      h.onpointerdown = function (ev) {
        ev.preventDefault(); h.setPointerCapture(ev.pointerId);
        var W = canvas.clientWidth, H = canvas.clientHeight, r = canvas.getBoundingClientRect();
        h.onpointermove = function (e2) {
          var px = Math.max(0, Math.min(1, (e2.clientX - r.left) / W)), py = Math.max(0, Math.min(1, (e2.clientY - r.top) / H));
          var x1 = cr.x, y1 = cr.y, x2 = cr.x + cr.w, y2 = cr.y + cr.h;
          if (c[0]) x2 = Math.max(x1 + 0.08, px); else x1 = Math.min(x2 - 0.08, px);
          if (c[1]) y2 = Math.max(y1 + 0.08, py); else y1 = Math.min(y2 - 0.08, py);
          cr.x = x1; cr.y = y1; cr.w = x2 - x1; cr.h = y2 - y1; place();
        };
        h.onpointerup = h.onpointercancel = function () { h.onpointermove = null; };
      };
    });
    requestAnimationFrame(place);
  }

  function open() {
    if (ov) return;
    ov = el('div'); ov.id = 'scanOv';
    var top = el('div', 'sc-top'), x = el('button', 'sc-b', '✕'); x.setAttribute('aria-label', 'Close'); x.onclick = function () { close(true); };
    var h = el('h2', null, 'Scan to PDF'), cnt = el('span', 'sc-count'); cnt.style.cssText = 'font-size:13px;color:var(--on-surface-v)';
    var dn = el('button', 'sc-b prim sc-done', 'Make PDF'); dn.onclick = done;
    top.append(x, h, cnt, dn);
    var stage = el('div', 'sc-stage'), ctl = el('div', 'sc-ctl'), strip = el('div', 'sc-strip'), addBar = el('div', 'sc-add');
    var cam = el('button', 'sc-b prim', 'Take photo'), gal = el('button', 'sc-b', 'From photos');
    cam.onclick = function () { add(true); }; gal.onclick = function () { add(false); };
    addBar.append(cam, gal);
    ov.append(top, stage, ctl, strip, addBar); document.body.append(ov);
    prevBack = window.__nativeBack || null;
    var old = prevBack;
    window.__nativeBack = function () { if (ov) { close(true); return true; } return old ? old() : false; };
    draw();
  }
  O.openScan = open;

  O.menuItems = O.menuItems || [];
  O.menuItems.push(function () { return [{ icon: 'image', label: 'Scan to PDF', run: open }]; });

  // button on the home screen
  var btns = document.querySelector('#empty .btns');
  if (btns) { var sb = el('button', 'btn tonal sl', 'Scan to PDF'); sb.type = 'button'; sb.onclick = open; btns.append(sb); }
})();
