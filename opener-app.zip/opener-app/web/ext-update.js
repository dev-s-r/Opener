/* Opener - in-app updates (quick web update or full app update) and backup / restore. */
(function () {
  'use strict';
  var O = window.__opener;
  if (!O) return;
  var REPO = 'dev-s-r/Opener';
  var NB = window.AndroidBridge || null;
  var CU = (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater) || null;
  var isApp = !!NB && !!NB.apkInfo;

  function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }
  function pad(n) { return ('0' + n).slice(-2); }

  /* ---------- versions ---------- */
  async function localInfo() {
    var apk = {}, bi = {};
    try { apk = JSON.parse(NB.apkInfo()); } catch (e) { /* not in the app */ }
    try { bi = await (await fetch('build-info.json', { cache: 'no-store' })).json(); } catch (e) { /* old build */ }
    return { apk: apk.versionCode || 0, name: apk.versionName || '', can: apk.canInstall !== false, build: bi.build || apk.versionCode || 0 };
  }
  async function latest() {
    var r = await fetch('https://api.github.com/repos/' + REPO + '/releases/latest', { headers: { Accept: 'application/vnd.github+json' } });
    if (!r.ok) throw new Error(r.status === 404 ? 'No update has been published yet.' : 'Could not reach GitHub (' + r.status + ').');
    var rel = await r.json(), meta = {};
    try { meta = JSON.parse(rel.body); } catch (e) { /* ignore */ }
    (rel.assets || []).forEach(function (a) {
      if (a.name === 'Opener.apk') meta.apkUrl = a.browser_download_url;
      if (a.name === 'web-bundle.zip') meta.webUrl = a.browser_download_url;
    });
    if (!meta.build) { var m = /(\d+)/.exec(rel.tag_name || ''); meta.build = m ? +m[1] : 0; }
    return meta;
  }

  /* ---------- update dialog ---------- */
  var dlg = null;
  function close() { if (dlg) { dlg.scrim.remove(); dlg = null; } }
  function open(title) {
    close();
    var scrim = el('div', 'dscrim'); scrim.id = 'zvScrim';
    var box = el('div', 'dialog'); box.setAttribute('role', 'dialog');
    var h = el('h3', null, title), msg = el('p'), bar = el('div'), act = el('div', 'actions');
    msg.style.margin = '0 0 12px'; bar.style.cssText = 'height:6px;border-radius:3px;background:var(--surface-high);overflow:hidden;margin:0 0 12px;display:none';
    var fill = el('div'); fill.style.cssText = 'height:100%;width:0;background:var(--primary);transition:width .2s'; bar.append(fill);
    box.append(h, msg, bar, act); scrim.append(box); document.body.append(scrim);
    scrim.addEventListener('click', function (ev) { if (ev.target === scrim) close(); });
    dlg = {
      scrim: scrim,
      title: function (t) { h.textContent = t; },
      say: function (t) { msg.textContent = t; },
      progress: function (p) { bar.style.display = p == null ? 'none' : 'block'; if (p != null) fill.style.width = Math.max(0, Math.min(100, p)) + '%'; },
      actions: function (list) {
        act.innerHTML = '';
        list.forEach(function (a) { var b = el('button', 'btn text sl', a[0]); b.onclick = a[1]; act.append(b); });
      }
    };
    return dlg;
  }

  async function webUpdate(m) {
    var d = open('Updating Opener');
    d.say('Downloading the update…'); d.progress(0); d.actions([]);
    var handle = null;
    try {
      try { handle = await CU.addListener('download', function (ev) { d.progress(ev.percent); }); } catch (e) { /* no progress */ }
      var b = await CU.download({ url: m.webUrl, version: String(m.build) });
      d.say('Applying…'); d.progress(100);
      await CU.set({ id: b.id });
    } catch (e) {
      if (handle && handle.remove) handle.remove();
      d.progress(null); d.say('The update failed: ' + (e && e.message ? e.message : e));
      var acts = [['Close', close], ['Try again', function () { webUpdate(m); }]];
      if (m.apkUrl && isApp) acts.push(['Full update', function () { localInfo().then(function (n) { apkUpdate(m, n); }); }]);
      d.actions(acts);
    }
  }

  function apkUpdate(m, info) {
    var d = open('Update Opener');
    if (!info.can) {
      d.say('Android needs your permission to let Opener install its own updates. Tap Allow, switch it on, then come back.');
      d.actions([['Not now', close], ['Allow', function () { NB.openInstallPermission(); }]]);
      var back = function () {
        if (document.hidden) return;
        document.removeEventListener('visibilitychange', back);
        localInfo().then(function (n) { if (dlg) { if (n.can) apkUpdate(m, n); else d.say('The permission is still off. Tap Allow to try again.'); } });
      };
      document.addEventListener('visibilitychange', back);
      return;
    }
    d.say('Downloading the new version…'); d.progress(0); d.actions([]);
    NB.installApk(m.apkUrl);
  }
  window.__updProgress = function (p) { if (dlg) dlg.progress(p); };
  window.__updResult = function (status, message) {
    if (!dlg) open('Update Opener');
    dlg.progress(null);
    if (status === 'confirm') { dlg.say('Confirm the update in the Android window. Your files stay.'); dlg.actions([['Close', close]]); }
    else if (status === 'success') { dlg.say('Updated. Open Opener again.'); dlg.actions([['Close', close]]); }
    else { dlg.say(message || 'The update could not be installed.'); dlg.actions([['Close', close]]); }
  };

  /* ---------- check ---------- */
  async function check(manual) {
    var info = await localInfo(), m;
    var d = manual ? open('Check for updates') : null;
    if (d) { d.say('Checking…'); d.actions([]); }
    try { m = await latest(); } catch (e) {
      if (d) { d.say(e && e.message ? e.message : 'Could not check. Are you online?'); d.actions([['Close', close]]); }
      return;
    }
    O.store.set('updLast', Date.now());
    if (!(m.build > info.build)) {
      if (d) { d.say('You have the latest version (build ' + info.build + ').'); d.actions([['Close', close]]); }
      return;
    }
    var quick = !!(CU && m.webUrl && info.apk >= (m.minApk || 0));
    var note = m.notes ? '\n\n' + m.notes : '';
    var dd = d || open('Update available');
    dd.title('Update available');
    if (quick) {
      dd.say('Build ' + m.build + ' is ready. This quick update keeps all your files and needs no installing.' + note);
      dd.actions([['Later', close], ['Update now', function () { webUpdate(m); }]]);
    } else if (m.apkUrl && isApp) {
      dd.say('Build ' + m.build + ' is ready. It changes the app itself, so Android will ask you to confirm. Your files stay.' + note);
      dd.actions([['Later', close], ['Update', function () { apkUpdate(m, info); }]]);
    } else {
      dd.say('A newer version exists, but it cannot be installed from here.');
      dd.actions([['Close', close]]);
    }
  }

  /* ---------- backup ---------- */
  function openDb() {
    return new Promise(function (res, rej) {
      var r = indexedDB.open('webviewer', 1);
      r.onupgradeneeded = function () { if (!r.result.objectStoreNames.contains('files')) r.result.createObjectStore('files', { keyPath: 'path' }); };
      r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); };
    });
  }
  function toB64(blob) {
    return new Promise(function (res, rej) {
      var fr = new FileReader();
      fr.onload = function () { var s = String(fr.result), i = s.indexOf(','); res(s.slice(i + 1)); };
      fr.onerror = function () { rej(fr.error); }; fr.readAsDataURL(blob);
    });
  }
  async function exportBackup() {
    try {
      O.toast('Preparing backup…');
      var ls = {};
      for (var i = 0; i < localStorage.length; i++) { var k = localStorage.key(i); ls[k] = localStorage.getItem(k); }
      var db = await openDb();
      var recs = await new Promise(function (res, rej) { var q = db.transaction('files', 'readonly').objectStore('files').getAll(); q.onsuccess = function () { res(q.result); }; q.onerror = function () { rej(q.error); }; });
      var parts = ['{"app":"Opener","v":1,"ls":', JSON.stringify(ls), ',"files":['];
      for (var j = 0; j < recs.length; j++) {
        var r = recs[j], data = null, type = '';
        if (r.blob) { data = await toB64(r.blob); type = r.blob.type || ''; }
        parts.push((j ? ',' : '') + JSON.stringify({ path: r.path, name: r.name, text: r.text == null ? null : r.text, dirty: !!r.dirty, mode: r.mode || null, ts: r.ts || 0, type: type, data: data }));
      }
      parts.push(']}');
      var d = new Date();
      O.downloadBlob(new Blob(parts, { type: 'application/json' }), 'Opener-backup-' + d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + '.json');
    } catch (e) { O.toast('Backup failed: ' + (e && e.message ? e.message : e)); }
  }
  async function importBackup(file) {
    try {
      var data = JSON.parse(await file.text());
      if (!data || data.app !== 'Opener' || !Array.isArray(data.files)) throw new Error('This is not an Opener backup');
      if (!confirm('Restore ' + data.files.length + ' file(s) and your settings? Files with the same name will be replaced.')) return;
      var db = await openDb(), n = 0;
      for (var i = 0; i < data.files.length; i++) {
        var f = data.files[i], blob = null;
        if (f.data != null) blob = await (await fetch('data:' + (f.type || 'application/octet-stream') + ';base64,' + f.data)).blob();
        await new Promise(function (res, rej) {
          var tx = db.transaction('files', 'readwrite');
          tx.objectStore('files').put({ path: f.path, name: f.name, text: f.text, blob: blob, dirty: !!f.dirty, mode: f.mode || undefined, ts: f.ts || Date.now() });
          tx.oncomplete = res; tx.onerror = function () { rej(tx.error); };
        });
        n++;
      }
      Object.keys(data.ls || {}).forEach(function (k) { try { localStorage.setItem(k, data.ls[k]); } catch (e) { /* ignore */ } });
      O.toast('Restored ' + n + ' file(s)');
      setTimeout(function () { location.reload(); }, 900);
    } catch (e) { O.toast('Restore failed: ' + (e && e.message ? e.message : e)); }
  }

  /* ---------- settings rows ---------- */
  var anchor = O.$('#setFull'), row = anchor && anchor.closest('.row');
  if (row) {
    var ver = null;
    function addRow(html) { var r = el('div', 'row'); r.innerHTML = html; row.parentNode.insertBefore(r, row); return r; }
    if (isApp) {
      var r1 = addRow('<div>Updates<small id="updVer">Version …</small></div><button class="btn text sl" id="updCheck">Check</button>');
      ver = r1.querySelector('#updVer');
      r1.querySelector('#updCheck').onclick = function () { O.$('#dlgScrim').hidden = true; check(true); };
      var r2 = addRow('<div>Check automatically<small>Looks for updates when the app opens</small></div><input type="checkbox" class="switch" id="updAuto">');
      var sw = r2.querySelector('input'); sw.checked = O.store.get('updAuto', true);
      sw.onchange = function () { O.store.set('updAuto', sw.checked); };
      localInfo().then(function (i) { if (ver) ver.textContent = 'Build ' + i.build + (i.name ? ' (app ' + i.name + ')' : ''); });
    }
    var r3 = addRow('<div>Backup<small>Save your files and settings, or restore them</small></div><span style="display:flex;gap:4px"><button class="btn text sl" id="bkOut">Save</button><button class="btn text sl" id="bkIn">Restore</button></span>');
    var inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.json,application/json'; inp.hidden = true; document.body.append(inp);
    r3.querySelector('#bkOut').onclick = exportBackup;
    r3.querySelector('#bkIn').onclick = function () { inp.value = ''; inp.click(); };
    inp.onchange = function () { if (inp.files && inp.files[0]) importBackup(inp.files[0]); };
  }

  /* ---------- automatic check ---------- */
  if (isApp && O.store.get('updAuto', true)) {
    setTimeout(function () {
      if (Date.now() - O.store.get('updLast', 0) < 6 * 3600 * 1000) return;
      if (document.getElementById('zvScrim')) return;
      check(false);
    }, 5000);
  }
})();
