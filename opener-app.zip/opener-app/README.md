# Opener – Android app

Your PWA (in `web/`) wrapped as a native Android app with Capacitor. GitHub Actions builds the APK for you.

## Build
1. Push this whole folder to a GitHub repo (branch `main`).
2. Open the **Actions** tab → **Build Android APK** → wait ~5 min.
3. Open the finished run → **Artifacts** → `Opener-apk` → install `Opener-debug.apk`.

Tag a version (`v1.0.0`) to also publish the APK on the repo's **Releases** page.

## What the app adds over the PWA
- Appears in "Open with" for html, css, js, json, txt, md, images and pdf
- Appears in the Share menu (files and plain text)
- Download / Save writes into the phone's Downloads folder
- Status and navigation bars follow the app's light/dark theme
- Back gesture closes dialogs, menus, find bar and the drawer first, then leaves the app
- Splash screens (all sizes) generated from the icon
- Own launcher icon (adaptive + round) made from `web/icon-512.png`

## Signed release APK (optional)
Make a keystore once:

    keytool -genkeypair -v -keystore release.jks -alias webviewer -keyalg RSA -keysize 2048 -validity 10000

Then add repo secrets (Settings → Secrets and variables → Actions):
`KEYSTORE_BASE64` (output of `base64 -w0 release.jks`), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
Keep the keystore safe — you need the same one for every future update.

## Editing the app
Change `web/index.html` etc. and push; the app rebuilds. `web/sw.js` is only used if you also host the PWA in a browser.
Change the package name / app name in `capacitor.config.json`.

## Notes
- PDF preview and "open from link" need internet (pdf.js loads from cdnjs).
- Folder picking (`webkitdirectory`) isn't supported by Android's file picker; picking multiple files works.
