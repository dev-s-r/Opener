package __PACKAGE__;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import androidx.activity.OnBackPressedCallback;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.BridgeActivity;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends BridgeActivity {

  private static class Item {
    String name;
    String type;
    Uri uri;
    byte[] bytes;
    File file;
    volatile boolean ready;
  }

  private static class SaveJob {
    OutputStream os;
    Uri uri;
  }

  private static final String ACTION_PICK = "__PACKAGE__.OPEN_PICKER";
  private final List<Item> pending = new ArrayList<>();
  private final Map<String, SaveJob> jobs = new HashMap<>();
  private File cacheRoot;
  private int counter = 0;
  private boolean pickRequested = false;

  // "Open file" app shortcut and picker results
  private final ActivityResultLauncher<String[]> picker = registerForActivityResult(
      new ActivityResultContracts.OpenMultipleDocuments(), uris -> {
        if (uris == null || uris.isEmpty()) return;
        for (Uri u : uris) {
          Item it = new Item();
          it.uri = u;
          it.name = displayName(u);
          String t = getContentResolver().getType(u);
          it.type = t == null ? "" : t;
          enqueue(it);
        }
        runOnUiThread(() -> getBridge().getWebView().evaluateJavascript(
            "window.__nativeFilesReady && window.__nativeFilesReady()", null));
      });

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    // Edge-to-edge on every Android version; we pad the content by the system bars ourselves.
    WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
    final View root = findViewById(android.R.id.content);
    ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
      Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
      Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
      v.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
      return WindowInsetsCompat.CONSUMED;
    });
    ViewCompat.requestApplyInsets(root);
    getWindow().getDecorView().setBackgroundColor(Color.parseColor("#F9F9FF"));

    cacheRoot = new File(getCacheDir(), "opener");
    if (savedInstanceState == null) deleteRec(cacheRoot);
    cacheRoot.mkdirs();

    getBridge().getWebView().addJavascriptInterface(new NativeBridge(), "AndroidBridge");

    // Back gesture: let the web app close dialogs/menus/drawer first, otherwise leave the app.
    getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
      @Override
      public void handleOnBackPressed() {
        getBridge().getWebView().evaluateJavascript(
            "window.__nativeBack ? window.__nativeBack() : false",
            value -> { if (!"true".equals(value)) finish(); });
      }
    });

    if (savedInstanceState == null) collect(getIntent());
    maybePick();
  }

  private void maybePick() {
    if (!pickRequested) return;
    pickRequested = false;
    getWindow().getDecorView().post(() -> {
      try { picker.launch(new String[]{"*/*"}); } catch (Exception ignored) { }
    });
  }

  private void deleteRec(File f) {
    if (f == null || !f.exists()) return;
    File[] kids = f.listFiles();
    if (kids != null) for (File k : kids) deleteRec(k);
    f.delete();
  }

  private String safeName(String n) {
    String c = n == null ? "" : n.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
    return c.isEmpty() ? "file" : c;
  }

  // Copies the incoming file into the app cache in the background (streams, no base64 in memory).
  private void enqueue(final Item it) {
    synchronized (pending) { pending.add(it); }
    new Thread(() -> {
      try {
        File dir = new File(cacheRoot, System.currentTimeMillis() + "_" + (counter++));
        dir.mkdirs();
        File f = new File(dir, safeName(it.name));
        try (OutputStream os = new FileOutputStream(f)) {
          if (it.bytes != null) {
            os.write(it.bytes);
          } else {
            try (InputStream in = getContentResolver().openInputStream(it.uri)) {
              byte[] buf = new byte[256 * 1024];
              int n;
              while (in != null && (n = in.read(buf)) > 0) os.write(buf, 0, n);
            }
          }
        }
        it.file = f;
      } catch (Exception ignored) {
        it.file = null;
      }
      it.ready = true;
    }).start();
  }

  @Override
  protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    setIntent(intent);
    collect(intent);
    maybePick();
    runOnUiThread(() -> getBridge().getWebView().evaluateJavascript(
        "window.__nativeFilesReady && window.__nativeFilesReady()", null));
  }

  /* ---------- incoming files (Open with / Share) ---------- */

  @SuppressWarnings({"deprecation", "unchecked"})
  private void collect(Intent intent) {
    if (intent == null || intent.getAction() == null) return;
    String action = intent.getAction();
    List<Uri> uris = new ArrayList<>();

    if (ACTION_PICK.equals(action)) {
      pickRequested = true;
    } else if (Intent.ACTION_VIEW.equals(action)) {
      if (intent.getData() != null) uris.add(intent.getData());
    } else if (Intent.ACTION_SEND.equals(action)) {
      Uri u = (Uri) intent.getParcelableExtra(Intent.EXTRA_STREAM);
      if (u != null) {
        uris.add(u);
      } else {
        String text = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (text != null) {
          Item it = new Item();
          it.name = "shared-text.txt";
          it.type = "text/plain";
          it.bytes = text.getBytes(StandardCharsets.UTF_8);
          enqueue(it);
        }
      }
    } else if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
      ArrayList<Uri> list = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
      if (list != null) uris.addAll(list);
    }

    for (Uri u : uris) {
      Item it = new Item();
      it.uri = u;
      it.name = displayName(u);
      String t = getContentResolver().getType(u);
      if (t == null || t.equals("application/octet-stream")) t = intent.getType();
      it.type = t == null ? "" : t;
      enqueue(it);
    }
    intent.setAction(null); // don't import the same file twice
  }

  private String displayName(Uri uri) {
    try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
      if (c != null && c.moveToFirst()) {
        String n = c.getString(0);
        if (n != null && !n.isEmpty()) return n;
      }
    } catch (Exception ignored) { }
    String last = uri.getLastPathSegment();
    if (last == null) return "file";
    int slash = last.lastIndexOf('/');
    return slash >= 0 ? last.substring(slash + 1) : last;
  }

  private byte[] readAll(Uri uri) throws Exception {
    try (InputStream in = getContentResolver().openInputStream(uri)) {
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      byte[] buf = new byte[64 * 1024];
      int n;
      while (in != null && (n = in.read(buf)) > 0) out.write(buf, 0, n);
      return out.toByteArray();
    }
  }

  private byte[] readFile(File f) throws Exception {
    try (InputStream in = new java.io.FileInputStream(f)) {
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      byte[] buf = new byte[64 * 1024];
      int n;
      while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
      return out.toByteArray();
    }
  }

  private void toast(final String msg) {
    runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
  }

  /* ---------- bridge exposed to JavaScript ---------- */

  /* ---------- in-app updates ---------- */
  private static final String INSTALL_ACTION = "com.opener.app.INSTALL_RESULT";
  private BroadcastReceiver installReceiver;

  private void updJs(String call) {
    runOnUiThread(() -> getBridge().getWebView().evaluateJavascript(
      "window." + call.split("\\(")[0] + " && window." + call, null));
  }

  private void updResult(String status, String msg) {
    updJs("__updResult(" + JSONObject.quote(status) + "," + JSONObject.quote(msg == null ? "" : msg) + ")");
  }

  private boolean sameKey(File apk) {
    try {
      if (Build.VERSION.SDK_INT < 28) return true;
      PackageManager pm = getPackageManager();
      PackageInfo mine = pm.getPackageInfo(getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
      PackageInfo theirs = pm.getPackageArchiveInfo(apk.getAbsolutePath(), PackageManager.GET_SIGNING_CERTIFICATES);
      if (theirs == null || theirs.signingInfo == null || mine.signingInfo == null) return true;
      Signature[] a = mine.signingInfo.getApkContentsSigners();
      Signature[] b = theirs.signingInfo.getApkContentsSigners();
      if (a == null || b == null || a.length == 0 || b.length == 0) return true;
      return a[0].equals(b[0]);
    } catch (Exception e) {
      return true;
    }
  }

  private void registerInstallReceiver() {
    if (installReceiver != null) return;
    installReceiver = new BroadcastReceiver() {
      @Override
      public void onReceive(Context c, Intent i) {
        int st = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1);
        if (st == PackageInstaller.STATUS_PENDING_USER_ACTION) {
          Intent conf = i.getParcelableExtra(Intent.EXTRA_INTENT);
          if (conf != null) {
            conf.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(conf);
          }
          updResult("confirm", "");
        } else if (st == PackageInstaller.STATUS_SUCCESS) {
          updResult("success", "");
        } else {
          String m = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
          updResult("error", m == null ? "The update could not be installed." : m);
        }
      }
    };
    IntentFilter f = new IntentFilter(INSTALL_ACTION);
    if (Build.VERSION.SDK_INT >= 33) registerReceiver(installReceiver, f, Context.RECEIVER_NOT_EXPORTED);
    else registerReceiver(installReceiver, f);
  }

  private void downloadAndInstall(String urlStr) {
    try {
      File dir = new File(getCacheDir(), "update");
      dir.mkdirs();
      File apk = new File(dir, "Opener.apk");
      java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(urlStr).openConnection();
      c.setConnectTimeout(20000);
      c.setReadTimeout(30000);
      c.setInstanceFollowRedirects(true);
      int code = c.getResponseCode();
      if (code / 100 != 2) throw new Exception("Download failed (" + code + ")");
      long total = c.getContentLengthLong();
      try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(apk)) {
        byte[] buf = new byte[65536];
        long done = 0;
        int n, last = -1;
        while ((n = in.read(buf)) > 0) {
          out.write(buf, 0, n);
          done += n;
          if (total > 0) {
            int p = (int) (done * 100 / total);
            if (p != last) { last = p; updJs("__updProgress(" + p + ")"); }
          }
        }
      }
      if (!sameKey(apk)) {
        updResult("error", "This update is signed with a different key, so Android will not install it over this app. It needs one reinstall. Save a backup first.");
        return;
      }
      PackageInstaller pi = getPackageManager().getPackageInstaller();
      PackageInstaller.SessionParams p = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
      p.setAppPackageName(getPackageName());
      if (Build.VERSION.SDK_INT >= 31) p.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
      int id = pi.createSession(p);
      registerInstallReceiver();
      try (PackageInstaller.Session s = pi.openSession(id)) {
        try (InputStream in = new java.io.FileInputStream(apk); OutputStream out = s.openWrite("Opener.apk", 0, apk.length())) {
          byte[] buf = new byte[65536];
          int n;
          while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
          s.fsync(out);
        }
        Intent cb = new Intent(INSTALL_ACTION).setPackage(getPackageName());
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
        PendingIntent pend = PendingIntent.getBroadcast(this, id, cb, flags);
        s.commit(pend.getIntentSender());
      }
    } catch (Exception e) {
      updResult("error", e.getMessage() == null ? "The update failed." : e.getMessage());
    }
  }

  private class NativeBridge {
    private File printFile;

    @JavascriptInterface
    public void printHtml(final String html, final String name) {
      runOnUiThread(() -> {
        final android.webkit.WebView wv = new android.webkit.WebView(MainActivity.this);
        wv.getSettings().setJavaScriptEnabled(false);
        wv.setWebViewClient(new android.webkit.WebViewClient() {
          @Override
          public void onPageFinished(android.webkit.WebView v, String url) {
            android.print.PrintManager pm = (android.print.PrintManager) getSystemService(Context.PRINT_SERVICE);
            pm.print(name, v.createPrintDocumentAdapter(name), null);
          }
        });
        wv.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
      });
    }

    @JavascriptInterface
    public void printPdfBegin() {
      printFile = new File(getCacheDir(), "print.pdf");
      printFile.delete();
    }

    @JavascriptInterface
    public void printPdfChunk(String b64) {
      try (FileOutputStream out = new FileOutputStream(printFile, true)) {
        out.write(Base64.decode(b64, Base64.DEFAULT));
      } catch (Exception e) { /* ignore */ }
    }

    @JavascriptInterface
    public void printPdfEnd(final String name) {
      final File f = printFile;
      runOnUiThread(() -> {
        android.print.PrintManager pm = (android.print.PrintManager) getSystemService(Context.PRINT_SERVICE);
        pm.print(name, new android.print.PrintDocumentAdapter() {
          @Override
          public void onLayout(android.print.PrintAttributes o, android.print.PrintAttributes n, android.os.CancellationSignal c,
                               LayoutResultCallback cb, android.os.Bundle extras) {
            if (c.isCanceled()) { cb.onLayoutCancelled(); return; }
            cb.onLayoutFinished(new android.print.PrintDocumentInfo.Builder(name + ".pdf")
              .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
              .setPageCount(android.print.PrintDocumentInfo.PAGE_COUNT_UNKNOWN).build(), true);
          }
          @Override
          public void onWrite(android.print.PageRange[] pages, android.os.ParcelFileDescriptor dest, android.os.CancellationSignal c, WriteResultCallback cb) {
            try (InputStream in = new java.io.FileInputStream(f); OutputStream out = new FileOutputStream(dest.getFileDescriptor())) {
              byte[] buf = new byte[65536];
              int n;
              while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
              cb.onWriteFinished(new android.print.PageRange[]{ android.print.PageRange.ALL_PAGES });
            } catch (Exception e) {
              cb.onWriteFailed(String.valueOf(e));
            }
          }
        }, null);
      });
    }

    @JavascriptInterface
    public String apkInfo() {
      try {
        PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
        long code = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
        boolean can = Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls();
        return new JSONObject().put("versionCode", code).put("versionName", pi.versionName).put("canInstall", can).toString();
      } catch (Exception e) {
        return "{}";
      }
    }

    @JavascriptInterface
    public void openInstallPermission() {
      try {
        Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
      } catch (Exception e) { /* ignore */ }
    }

    @JavascriptInterface
    public void installApk(final String url) {
      new Thread(() -> downloadAndInstall(url)).start();
    }


    @JavascriptInterface
    public int pendingCount() {
      synchronized (pending) { return pending.size(); }
    }

    @JavascriptInterface
    public String pendingInfo(int i) {
      try {
        Item it;
        synchronized (pending) { it = pending.get(i); }
        JSONObject o = new JSONObject();
        o.put("name", it.name);
        o.put("type", it.type);
        o.put("path", it.file != null ? it.file.getAbsolutePath() : "");
        o.put("size", it.file != null ? it.file.length() : 0);
        return o.toString();
      } catch (Exception e) {
        return "{}";
      }
    }

    @JavascriptInterface
    public boolean pendingReady(int i) {
      try {
        Item it;
        synchronized (pending) { it = pending.get(i); }
        return it.ready;
      } catch (Exception e) {
        return true;
      }
    }

    @JavascriptInterface
    public String pendingData(int i) {
      try {
        Item it;
        synchronized (pending) { it = pending.get(i); }
        byte[] data = it.bytes != null ? it.bytes : (it.file != null ? readFile(it.file) : readAll(it.uri));
        return Base64.encodeToString(data, Base64.NO_WRAP);
      } catch (Exception e) {
        toast("Couldn't read the file");
        return "";
      }
    }

    // Reads one slice of a received file (base64), so big files never travel as one giant string.
    @JavascriptInterface
    public String pendingChunk(int i, double offset, int len) {
      try {
        Item it;
        synchronized (pending) { it = pending.get(i); }
        if (it.bytes != null) {
          int o = (int) offset;
          int n = Math.min(len, it.bytes.length - o);
          return n <= 0 ? "" : Base64.encodeToString(it.bytes, o, n, Base64.NO_WRAP);
        }
        if (it.file == null) return "";
        try (java.io.RandomAccessFile r = new java.io.RandomAccessFile(it.file, "r")) {
          r.seek((long) offset);
          byte[] buf = new byte[len];
          int n = r.read(buf);
          return n <= 0 ? "" : Base64.encodeToString(buf, 0, n, Base64.NO_WRAP);
        }
      } catch (Exception e) {
        return "";
      }
    }

    @JavascriptInterface
    public void clearPending(int n) {
      synchronized (pending) {
        for (int i = 0; i < n && !pending.isEmpty(); i++) pending.remove(0);
      }
    }

    @JavascriptInterface
    public boolean saveFile(String name, String mime, String base64) {
      boolean ok = write(name, mime, base64);
      toast(ok ? "Saved to Downloads: " + name : "Couldn't save the file");
      return ok;
    }

    @JavascriptInterface
    public boolean saveFileQuiet(String name, String mime, String base64) {
      return write(name, mime, base64);
    }

    // name may contain folders ("archive/sub/file.txt"); they are created inside Downloads.
    private boolean write(String name, String mime, String base64) {
      SaveJob job = null;
      try {
        job = openJob(name, mime);
        job.os.write(Base64.decode(base64, Base64.DEFAULT));
        finishJob(job);
        return true;
      } catch (Exception e) {
        abortJob(job);
        return false;
      }
    }

    // Large files are written in pieces so they never sit in memory as one big string.
    @JavascriptInterface
    public String saveBegin(String name, String mime) {
      try {
        SaveJob job = openJob(name, mime);
        String id = "j" + System.nanoTime();
        synchronized (jobs) { jobs.put(id, job); }
        return id;
      } catch (Exception e) {
        return "";
      }
    }

    @JavascriptInterface
    public boolean saveChunk(String id, String base64) {
      SaveJob job;
      synchronized (jobs) { job = jobs.get(id); }
      if (job == null) return false;
      try {
        job.os.write(Base64.decode(base64, Base64.DEFAULT));
        return true;
      } catch (Exception e) {
        synchronized (jobs) { jobs.remove(id); }
        abortJob(job);
        return false;
      }
    }

    @JavascriptInterface
    public boolean saveEnd(String id, boolean announce) {
      SaveJob job;
      synchronized (jobs) { job = jobs.remove(id); }
      if (job == null) return false;
      try {
        finishJob(job);
        if (announce) toast("Saved to Downloads");
        return true;
      } catch (Exception e) {
        abortJob(job);
        return false;
      }
    }

    private SaveJob openJob(String name, String mime) throws Exception {
      StringBuilder clean = new StringBuilder();
      for (String part : name.replace('\\', '/').split("/")) {
        if (part.isEmpty() || part.equals(".") || part.equals("..")) continue;
        if (clean.length() > 0) clean.append('/');
        clean.append(part);
      }
      String path = clean.toString();
      if (path.isEmpty()) path = "file";
      int slash = path.lastIndexOf('/');
      String dir = slash < 0 ? "" : path.substring(0, slash);
      String base = slash < 0 ? path : path.substring(slash + 1);
      String type = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
      SaveJob job = new SaveJob();
      if (Build.VERSION.SDK_INT >= 29) {
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, base);
        v.put(MediaStore.Downloads.MIME_TYPE, type);
        v.put(MediaStore.Downloads.RELATIVE_PATH, dir.isEmpty() ? Environment.DIRECTORY_DOWNLOADS : Environment.DIRECTORY_DOWNLOADS + "/" + dir);
        v.put(MediaStore.Downloads.IS_PENDING, 1);
        job.uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (job.uri == null) throw new Exception("insert failed");
        job.os = getContentResolver().openOutputStream(job.uri);
      } else {
        File target = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), path);
        File parent = target.getParentFile();
        if (parent != null) parent.mkdirs();
        job.os = new FileOutputStream(target);
      }
      return job;
    }

    private void finishJob(SaveJob job) throws Exception {
      job.os.close();
      if (job.uri != null) {
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.IS_PENDING, 0);
        getContentResolver().update(job.uri, v, null, null);
      }
    }

    private void abortJob(SaveJob job) {
      if (job == null) return;
      try { if (job.os != null) job.os.close(); } catch (Exception ignored) { }
      try { if (job.uri != null) getContentResolver().delete(job.uri, null, null); } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void setChrome(final String hex, final boolean dark) {
      runOnUiThread(() -> {
        try {
          getWindow().getDecorView().setBackgroundColor(Color.parseColor(hex));
          WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
          c.setAppearanceLightStatusBars(!dark);
          c.setAppearanceLightNavigationBars(!dark);
        } catch (Exception ignored) { }
      });
    }
  }
}
