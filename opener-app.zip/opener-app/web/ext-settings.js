/* Opener – Material 3 settings screen.
   It does not own any setting: every control mirrors the original (hidden) settings dialog,
   so all the existing logic, stored values and extension rows keep working. */
(function () {
  'use strict';
  var O = window.__opener;
  if (!O) return;
  var $ = O.$, store = O.store, doc = document;
  function el(tag, cls, html) { var e = doc.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function old(id) { return doc.getElementById(id); }
  var CHK = '<svg viewBox="0 0 24 24"><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg>';
  var BACK = '<svg viewBox="0 0 24 24" style="width:24px;height:24px;fill:currentColor"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>';
  var HEART = '<svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>';

  /* ---------- accent colour (tonal palette from one hue) ---------- */
  var VARS = ['primary', 'on-primary', 'primary-c', 'on-primary-c', 'secondary-c', 'on-secondary-c', 'surface', 'surface-low', 'surface-mid', 'surface-high', 'on-surface', 'on-surface-v', 'outline', 'outline-v'];
  function H(h, s, l) { return 'hsl(' + h + ',' + s + '%,' + l + '%)'; }
  function applyAccent() {
    var r = doc.documentElement, hue = store.get('accent', null);
    if (hue === null || hue === undefined) { VARS.forEach(function (k) { r.style.removeProperty('--' + k); }); }
    else {
      var d = r.dataset.theme === 'dark', h = +hue;
      var T = d ? { primary: H(h, 92, 80), 'on-primary': H(h, 100, 18), 'primary-c': H(h, 60, 28), 'on-primary-c': H(h, 100, 91), 'secondary-c': H(h, 18, 26), 'on-secondary-c': H(h, 30, 90),
        surface: H(h, 14, 7.5), 'surface-low': H(h, 12, 10), 'surface-mid': H(h, 10, 12.5), 'surface-high': H(h, 9, 16.5), 'on-surface': H(h, 14, 90), 'on-surface-v': H(h, 10, 77), outline: H(h, 6, 58), 'outline-v': H(h, 10, 27) }
        : { primary: H(h, 70, 40), 'on-primary': '#fff', 'primary-c': H(h, 100, 91), 'on-primary-c': H(h, 100, 12), 'secondary-c': H(h, 32, 89), 'on-secondary-c': H(h, 32, 14),
          surface: H(h, 45, 98.2), 'surface-low': H(h, 32, 96), 'surface-mid': H(h, 24, 93.5), 'surface-high': H(h, 20, 91), 'on-surface': H(h, 12, 11), 'on-surface-v': H(h, 10, 28), outline: H(h, 6, 46), 'outline-v': H(h, 14, 80) };
      for (var k in T) r.style.setProperty('--' + k, T[k]);
    }
    var m = doc.querySelector('meta[name="theme-color"]');
    if (m) m.content = getComputedStyle(r).getPropertyValue('--surface').trim();
  }
  new MutationObserver(applyAccent).observe(doc.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
  applyAccent();
  var SWATCHES = [['Blue', null, '#0B57D0'], ['Green', 145, 'hsl(145,70%,38%)'], ['Purple', 270, 'hsl(270,60%,48%)'], ['Orange', 28, 'hsl(28,85%,45%)'], ['Pink', 330, 'hsl(330,70%,45%)'], ['Teal', 180, 'hsl(180,75%,34%)']];

  /* ---------- build the screen ---------- */
  function swRow(id, title, desc) {
    if (!old(id)) return '';
    return '<label class="s-row h-r"><div class="tx"><div class="t">' + title + '</div>' + (desc ? '<div class="d" data-d="' + id + '">' + desc + '</div>' : '') + '</div>' +
      '<span class="s-sw"><input type="checkbox" data-p="' + id + '"><span class="tr"></span><span class="th">' + CHK + '</span></span></label>';
  }
  var hasUpd = !!old('updCheck'), hasBk = !!old('bkOut');
  var secs = {
    Appearance: '<div class="s-grp">' +
      '<div class="s-row s-col"><div class="t">Theme</div><div class="s-seg" id="sTheme"><button class="h-r" data-v="auto">' + CHK + 'Auto</button><button class="h-r" data-v="light">' + CHK + 'Light</button><button class="h-r" data-v="dark">' + CHK + 'Dark</button></div></div>' +
      '<div class="s-row s-col"><div class="t">Colour</div><div class="s-swatches" id="sSwatches"></div></div></div>',
    Editor: '<div class="s-grp">' +
      (old('setFont') ? '<div class="s-row s-col"><div class="t">Font size</div><div class="s-srow"><span class="az" style="font-size:12px">A</span><input type="range" id="sFont"><span class="az" style="font-size:20px">A</span><span class="s-val" id="sFontV"></span></div>' +
        '<div class="s-prev" id="sPrev"><span class="c">// Preview</span>\n<span class="k">const</span> hello = <span class="s">\'Opener\'</span>;</div></div>' : '') +
      swRow('setWrap', 'Wrap long lines') + swRow('setLines', 'Line numbers', 'Show numbers next to each line') + swRow('setAssist', 'Editor helpers', 'Auto-close brackets, suggestions and key bar') + '</div>',
    'Files and privacy': '<div class="s-grp">' + swRow('setRemember', 'Remember files', 'Keep files and edits inside the app') +
      swRow('setFull', 'Full page access', 'Lets HTML pages use storage and cookies. Only for files you trust.') +
      (hasBk ? '<div class="s-row s-col"><div class="t" style="margin-bottom:2px">Backup</div><div class="d" style="margin-bottom:12px">Save your files and settings, or restore them</div><div class="s-btns"><button class="s-btn tonal h-r" id="sBkOut">Save</button><button class="s-btn tonal h-r" id="sBkIn">Restore</button></div></div>' : '') + '</div>',
    Updates: hasUpd ? '<div class="s-grp"><div class="s-row s-vcard"><div class="logo"><img src="icon-192.png" alt=""></div><div class="tx"><div class="t">Opener</div><div class="d" id="sUpdTxt">Version …</div></div><button class="s-btn tonal h-r" id="sUpd">Check</button></div>' +
      swRow('updAuto', 'Check automatically', 'Looks for updates when the app opens') + '</div>' : ''
  };
  var scr = el('div'); scr.id = 'sScreen'; scr.setAttribute('role', 'dialog'); scr.setAttribute('aria-label', 'Settings');
  var secHtml = '';
  Object.keys(secs).forEach(function (k) { if (secs[k]) secHtml += '<section class="s-sec" data-id="' + k + '"><div class="s-gh">' + k + '</div>' + secs[k] + '</section>'; });
  scr.innerHTML = '<div class="s-edge" id="sEdge"></div>' +
    '<header class="s-lt" id="sLt"><button class="h-ib h-r back" id="sBack" aria-label="Back">' + BACK + '</button><div class="tt" id="sTt">Settings</div></header>' +
    '<div id="sBody"><div id="sSecs">' + secHtml + '</div><div style="height:24px"></div>' +
    '<button class="s-btn danger h-r" id="sDel">Remove all files</button>' +
    '<div class="s-about"><div class="logo"><img src="icon-512.png" alt="Opener"></div><div class="nm">Opener</div><div class="vs" id="sVer"></div>' +
    '<div class="by">Made with ' + HEART + ' by <b>Dev Singh Rathore</b></div><div class="loc">from Jaipur</div></div></div>';
  doc.body.append(scr);

  var dlg = el('div'); dlg.id = 'sDlgScrim';
  dlg.innerHTML = '<div class="s-dlg" role="alertdialog"><svg class="di" viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg><h3>Remove all files?</h3><p>This removes every file from Opener. The originals on your phone are not deleted.</p><div class="a"><button class="btn text sl" id="sNo">Cancel</button><button class="btn text sl" id="sYes" style="color:var(--error)">Remove</button></div></div>';
  doc.body.append(dlg);

  var body = $('#sBody'), lt = $('#sLt'), tt = $('#sTt');

  /* ---------- proxies to the original controls ---------- */
  function fire(node, type) { node.dispatchEvent(new Event(type, { bubbles: true })); }
  scr.querySelectorAll('input[data-p]').forEach(function (inp) {
    inp.onchange = function () { var o = old(inp.dataset.p); if (!o) return; o.checked = inp.checked; fire(o, 'change'); syncRules(); };
  });
  var font = $('#sFont');
  if (font) {
    var of = old('setFont'); font.min = of.min || 11; font.max = of.max || 22; font.step = of.step || 1;
    font.oninput = function () { of.value = font.value; fire(of, 'input'); paintFont(); };
  }
  function paintFont() {
    if (!font) return;
    var p = (font.value - font.min) / (font.max - font.min) * 100;
    font.style.setProperty('--v', p + '%'); $('#sFontV').textContent = font.value + ' px'; $('#sPrev').style.fontSize = font.value + 'px';
  }
  function syncRules() {
    var w = old('setWrap'), l = scr.querySelector('input[data-p="setLines"]');
    if (!w || !l) return;
    l.disabled = w.checked;
    var d = scr.querySelector('[data-d="setLines"]'); if (d) d.textContent = w.checked ? 'Hidden while lines wrap' : 'Show numbers next to each line';
  }
  function themeNow() { return store.get('theme', 'auto'); }
  function renderTheme() { scr.querySelectorAll('#sTheme button').forEach(function (b) { b.classList.toggle('on', b.dataset.v === themeNow()); }); }
  scr.querySelectorAll('#sTheme button').forEach(function (b) { b.onclick = function () { O.applyTheme(b.dataset.v); renderTheme(); }; });
  function renderSwatches() {
    var cur = store.get('accent', null), host = $('#sSwatches'); host.innerHTML = '';
    SWATCHES.forEach(function (s) {
      var b = el('button', 's-swatch h-r' + ((cur === null || cur === undefined ? s[1] === null : +cur === s[1]) ? ' on' : ''), CHK);
      b.style.background = s[2]; b.setAttribute('aria-label', s[0]);
      b.onclick = function () { store.set('accent', s[1]); applyAccent(); renderSwatches(); };
      host.append(b);
    });
  }
  function updText() {
    var u = old('updVer'), t = $('#sUpdTxt'); if (!u || !t) return;
    t.textContent = (u.textContent || '').replace(/\s*\(app[^)]*\)/, '');
  }
  var uv = old('updVer'); if (uv) new MutationObserver(updText).observe(uv, { childList: true, characterData: true, subtree: true });
  if ($('#sUpd')) $('#sUpd').onclick = function () { close(); old('updCheck').click(); };
  if ($('#sBkOut')) { $('#sBkOut').onclick = function () { old('bkOut').click(); }; $('#sBkIn').onclick = function () { old('bkIn').click(); }; }

  $('#sDel').onclick = function () { dlg.classList.add('on'); };
  $('#sNo').onclick = function () { dlg.classList.remove('on'); };
  dlg.onclick = function (e) { if (e.target === dlg) dlg.classList.remove('on'); };
  $('#sYes').onclick = function () {
    dlg.classList.remove('on');
    var c = window.confirm; window.confirm = function () { return true; };
    try { old('setClear').click(); } finally { window.confirm = c; }
    close();
  };

  /* ---------- open / close ---------- */
  function sync() {
    scr.querySelectorAll('input[data-p]').forEach(function (inp) { var o = old(inp.dataset.p); if (o) inp.checked = !!o.checked; });
    if (font) { font.value = old('setFont').value; paintFont(); }
    syncRules(); renderTheme(); renderSwatches(); updText();
  }
  var isOpen = false;
  function open() {
    sync(); isOpen = true; scr.classList.add('on'); body.scrollTop = 0; collapse();
    if (O.closeSheet) O.closeSheet();
    if (!store.get('tipSet', false)) { store.set('tipSet', true); setTimeout(function () { O.toast('Press and hold a heading to move that section'); }, 700); }
  }
  function close() { isOpen = false; scr.classList.remove('on'); }
  O.openSettings = open; O.closeSettings = close;
  $('#sBack').onclick = close;
  doc.addEventListener('keydown', function (e) { if (e.key === 'Escape' && isOpen) close(); });
  var prevBack = O.backHandler;
  O.backHandler = function () {
    if (dlg.classList.contains('on')) { dlg.classList.remove('on'); return true; }
    if (isOpen) { close(); return true; }
    return prevBack ? prevBack() : false;
  };

  /* large top bar collapses while scrolling */
  function collapse() {
    var y = Math.min(1, Math.max(0, body.scrollTop / 88));
    lt.style.height = (152 - 88 * y) + 'px';
    tt.style.transform = 'translateX(' + (44 * y) + 'px) scale(' + (1 - 0.31 * y) + ')';
    lt.classList.toggle('sc2', body.scrollTop > 4);
  }
  body.addEventListener('scroll', collapse, { passive: true });

  /* swipe from the left edge to go back */
  $('#sEdge').addEventListener('pointerdown', function (e) {
    if (e.button > 0) return;
    var sx = e.clientX, dx = 0;
    function mv(ev) { dx = Math.max(0, ev.clientX - sx); scr.style.transition = 'none'; scr.style.transform = 'translateX(' + dx + 'px)'; }
    function up() {
      removeEventListener('pointermove', mv); removeEventListener('pointerup', up); removeEventListener('pointercancel', up);
      scr.style.transition = ''; scr.style.transform = ''; if (dx > 110) close();
    }
    addEventListener('pointermove', mv); addEventListener('pointerup', up); addEventListener('pointercancel', up);
  });

  /* movable sections (press and hold a heading) */
  function saved() { var v = store.get('o.sec', null); return Array.isArray(v) ? v : null; }
  function applyOrder() {
    var host = $('#sSecs'), o = saved(), all = [].slice.call(host.children);
    if (!o) o = ['Appearance', 'Editor', 'Files and privacy', 'Updates'];
    o.forEach(function (id) { var x = all.filter(function (q) { return q.dataset.id === id; })[0]; if (x) host.append(x); });
  }
  O.resetSettingsOrder = function () { applyOrder(); };
  if (O.sortable) O.sortable($('#sSecs'), '.s-sec', { handle: '.s-gh', scroller: body, onChange: function (els) { store.set('o.sec', els.map(function (e) { return e.dataset.id; })); } });
  applyOrder();

  /* version line */
  try {
    fetch('build-info.json', { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : null; }).then(function (j) {
      if (j && j.build) $('#sVer').textContent = 'Version 1.0.' + j.build;
    }).catch(function () { /* ignore */ });
  } catch (e) { /* ignore */ }
})();
