const CACHE = 'opener-v4';
const SHELL = ['./', './index.html', './manifest.json', './icon-192.png', './icon-512.png', './ext-editor.js', './ext-pdf.js', './ext-zip.js', './ext-office.js', './ext-update.js', './vendor/pdf-lib.min.js'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE && k !== 'shared-files').map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  const url = new URL(req.url);

  // Files shared to the app (Android Share menu)
  if (req.method === 'POST' && url.pathname.endsWith('/share-target')) {
    e.respondWith((async () => {
      const data = await req.formData();
      const list = data.getAll('files').filter(f => f && f.name);
      const cache = await caches.open('shared-files');
      for (const k of await cache.keys()) await cache.delete(k);
      let i = 0;
      for (const f of list) {
        await cache.put('shared/' + (i++) + '/' + encodeURIComponent(f.name),
          new Response(f, { headers: { 'Content-Type': f.type || 'application/octet-stream' } }));
      }
      return Response.redirect(new URL('./index.html?shared=' + list.length, self.registration.scope).href, 303);
    })());
    return;
  }

  if (req.method !== 'GET' || url.origin !== location.origin) return;

  // Network first so updates show up right away; fall back to the cache when offline.
  e.respondWith(
    fetch(req).then(res => {
      if (res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)); }
      return res;
    }).catch(() => caches.match(req, { ignoreSearch: true }).then(hit => hit || caches.match('./index.html')))
  );
});
