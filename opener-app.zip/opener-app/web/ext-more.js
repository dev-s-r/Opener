/* Opener - more file types: epub, eml, ipynb, vcf, ics, Apple Pages/Numbers/Keynote previews. */
(function () {
  'use strict';
  var O = window.__opener;
  if (!O) return;
  var L = O.extraLoaders = O.extraLoaders || {};
  var esc = function (s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); };
  var dec = function (u8, cs) { try { return new TextDecoder(cs || 'utf-8').decode(u8); } catch (e) { return new TextDecoder('utf-8').decode(u8); } };
  var extOf = function (n) { var i = n.lastIndexOf('.'); return i < 0 ? '' : n.slice(i + 1).toLowerCase(); };
  function mapZip(list) { var m = {}; list.forEach(function (x) { if (!x.dir) m[x.name.replace(/^\/+/, '')] = x; }); return m; }
  function resolve(base, target) {
    target = String(target).split('#')[0].split('?')[0];
    try { target = decodeURIComponent(target); } catch (e) { /* keep */ }
    if (/^\//.test(target)) return target.slice(1);
    var parts = base.split('/'); parts.pop();
    target.split('/').forEach(function (p) { if (p === '..') parts.pop(); else if (p && p !== '.') parts.push(p); });
    return parts.join('/');
  }
  var MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml' };
  async function dataUrl(Z, path) {
    var e = Z[path]; if (!e) return '';
    var mime = MIME[extOf(path)]; if (!mime || e.size > 8e6) return '';
    var u8 = await e.bytes(), s = '';
    for (var i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    return 'data:' + mime + ';base64,' + btoa(s);
  }

  /* ---------- EPUB ---------- */
  L.epub = async function (e) {
    var Z = mapZip(O.readZip(await e.file.arrayBuffer()));
    var cont = Z['META-INF/container.xml'];
    if (!cont) throw new Error('Not a valid EPUB');
    var cdoc = new DOMParser().parseFromString(dec(await cont.bytes()), 'application/xml');
    var rootfile = cdoc.getElementsByTagNameNS('*', 'rootfile')[0];
    var opfPath = rootfile && rootfile.getAttribute('full-path');
    if (!opfPath || !Z[opfPath]) throw new Error('Book contents not found');
    var opf = new DOMParser().parseFromString(dec(await Z[opfPath].bytes()), 'application/xml');
    var manifest = {};
    Array.prototype.forEach.call(opf.getElementsByTagNameNS('*', 'item'), function (it) { manifest[it.getAttribute('id')] = it.getAttribute('href'); });
    var spine = Array.prototype.map.call(opf.getElementsByTagNameNS('*', 'itemref'), function (r) { return manifest[r.getAttribute('idref')]; }).filter(Boolean);
    var title = (opf.getElementsByTagNameNS('*', 'title')[0] || {}).textContent || e.name;
    var author = (opf.getElementsByTagNameNS('*', 'creator')[0] || {}).textContent || '';
    var toc = '', body = '', n = 0;
    for (var i = 0; i < spine.length && i < 300; i++) {
      var p = resolve(opfPath, spine[i]), ent = Z[p];
      if (!ent) continue;
      var txt = dec(await ent.bytes()), doc;
      doc = new DOMParser().parseFromString(txt, 'application/xhtml+xml');
      if (doc.getElementsByTagName('parsererror').length) doc = new DOMParser().parseFromString(txt, 'text/html');
      var b = doc.body || doc.getElementsByTagNameNS('*', 'body')[0];
      if (!b) continue;
      Array.prototype.slice.call(b.querySelectorAll('script,style,link,iframe,object,embed,form')).forEach(function (x) { x.remove(); });
      var imgs = Array.prototype.slice.call(b.querySelectorAll('img,image'));
      for (var k = 0; k < imgs.length && k < 40; k++) {
        var im = imgs[k], attrName = im.hasAttribute('src') ? 'src' : (im.hasAttribute('href') ? 'href' : 'xlink:href');
        var ref = im.getAttribute(attrName) || im.getAttribute('xlink:href');
        var du = ref ? await dataUrl(Z, resolve(p, ref)) : '';
        if (du) { if (im.localName === 'image') { im.setAttribute('href', du); } else im.setAttribute('src', du); } else im.removeAttribute(attrName);
      }
      Array.prototype.slice.call(b.querySelectorAll('[style],[class]')).forEach(function (x) { x.removeAttribute('style'); });
      Array.prototype.slice.call(b.querySelectorAll('a')).forEach(function (a) {
        var h = a.getAttribute('href') || '';
        if (/^https?:/i.test(h)) { a.setAttribute('target', '_blank'); a.setAttribute('rel', 'noopener'); } else a.removeAttribute('href');
      });
      n++;
      var h1 = b.querySelector('h1,h2,h3'), name = h1 ? h1.textContent.trim().slice(0, 80) : 'Section ' + n;
      toc += '<li><a href="#ch' + n + '">' + esc(name) + '</a></li>';
      body += '<hr id="ch' + n + '" style="margin:2em 0"><div>' + (b.innerHTML || '') + '</div>';
    }
    var head = '<h1 style="margin-bottom:.2em">' + esc(title) + '</h1>' + (author ? '<p style="color:#555">' + esc(author) + '</p>' : '') + '<details><summary><b>Chapters (' + n + ')</b></summary><ol>' + toc + '</ol></details>';
    return { html: '<div class="doc" style="max-width:720px;margin:auto;font-family:Georgia,serif;font-size:1.05em;line-height:1.7">' + head + body + '</div>' };
  };

  /* ---------- EML (email) ---------- */
  function unfold(h) { return h.replace(/\r?\n[ \t]+/g, ' '); }
  function parseHead(raw) {
    var h = {}, lines = unfold(raw).split(/\r?\n/);
    lines.forEach(function (l) { var i = l.indexOf(':'); if (i > 0) { var k = l.slice(0, i).toLowerCase(); if (!(k in h)) h[k] = l.slice(i + 1).trim(); } });
    return h;
  }
  function mimeWords(s) {
    return String(s || '').replace(/=\?([^?]+)\?([bBqQ])\?([^?]*)\?=/g, function (m, cs, enc, t) {
      try {
        if (enc.toLowerCase() === 'b') { var bin = atob(t), u = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return dec(u, cs); }
        var q = t.replace(/_/g, ' ').replace(/=([0-9A-F]{2})/gi, function (x, hx) { return String.fromCharCode(parseInt(hx, 16)); });
        var u2 = new Uint8Array(q.length); for (var j = 0; j < q.length; j++) u2[j] = q.charCodeAt(j); return dec(u2, cs);
      } catch (e) { return m; }
    });
  }
  function bodyBytes(raw, enc, cs) {
    enc = (enc || '').toLowerCase(); var u;
    if (enc === 'base64') { var bin = atob(raw.replace(/[^A-Za-z0-9+/=]/g, '')); u = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); }
    else if (enc === 'quoted-printable') {
      var q = raw.replace(/=\r?\n/g, ''), out = [];
      for (var k = 0; k < q.length; k++) { if (q[k] === '=' && /^[0-9A-Fa-f]{2}$/.test(q.substr(k + 1, 2))) { out.push(parseInt(q.substr(k + 1, 2), 16)); k += 2; } else out.push(q.charCodeAt(k) & 255); }
      u = new Uint8Array(out);
    } else { u = new Uint8Array(raw.length); for (var m = 0; m < raw.length; m++) u[m] = raw.charCodeAt(m) & 255; }
    return dec(u, cs);
  }
  function parts(raw, out) {
    var i = raw.search(/\r?\n\r?\n/), head = parseHead(i < 0 ? raw : raw.slice(0, i)), body = i < 0 ? '' : raw.slice(i).replace(/^\r?\n\r?\n/, '');
    var ct = head['content-type'] || 'text/plain', cs = (/charset="?([\w-]+)/i.exec(ct) || [])[1];
    var bm = /boundary="?([^";]+)"?/i.exec(ct);
    if (/^multipart\//i.test(ct) && bm) {
      var segs = body.split('--' + bm[1]);
      segs.slice(1).forEach(function (sg) { if (/^--/.test(sg)) return; parts(sg.replace(/^\r?\n/, ''), out); });
      return head;
    }
    var disp = head['content-disposition'] || '', fn = /filename\*?="?([^";]+)"?/i.exec(disp) || /name="?([^";]+)"?/i.exec(ct);
    if (/attachment/i.test(disp) || (fn && !/^text\/(plain|html)/i.test(ct))) { out.files.push(mimeWords(fn ? fn[1] : 'attachment')); return head; }
    if (/^text\/html/i.test(ct)) out.html = out.html || bodyBytes(body, head['content-transfer-encoding'], cs);
    else if (/^text\/plain/i.test(ct)) out.text = out.text || bodyBytes(body, head['content-transfer-encoding'], cs);
    return head;
  }
  L.eml = async function (e) {
    var raw = new TextDecoder('latin1').decode(new Uint8Array(await e.file.arrayBuffer()));
    var out = { files: [], html: '', text: '' }, head = parts(raw, out);
    var rows = ['from', 'to', 'cc', 'date', 'subject'].filter(function (k) { return head[k]; }).map(function (k) {
      return '<tr><td style="color:#666;padding-right:12px"><b>' + k.charAt(0).toUpperCase() + k.slice(1) + '</b></td><td>' + esc(mimeWords(head[k])) + '</td></tr>';
    }).join('');
    var bodyHtml = out.html ? out.html.replace(/<(script|style|iframe|object|embed|link|meta)[\s\S]*?(<\/\1>|>)/gi, '').replace(/\son\w+="[^"]*"/gi, '').replace(/src="(?!data:)[^"]*"/gi, 'src=""') : '<pre>' + esc(out.text) + '</pre>';
    var att = out.files.length ? '<p><b>Attachments:</b> ' + out.files.map(esc).join(', ') + '</p>' : '';
    return { html: '<div class="doc"><table style="margin-bottom:12px">' + rows + '</table>' + att + '<hr>' + bodyHtml + '</div>' };
  };

  /* ---------- Jupyter notebook ---------- */
  L.ipynb = async function (e) {
    var nb = JSON.parse(await e.file.text()), cells = nb.cells || [], h = '';
    var src = function (c) { return Array.isArray(c.source) ? c.source.join('') : String(c.source || ''); };
    cells.forEach(function (c) {
      if (c.cell_type === 'markdown') {
        h += '<div class="doc" style="margin:0 0 12px">' + src(c).split(/\n/).map(function (l) {
          var m = /^(#{1,6})\s+(.*)$/.exec(l);
          return m ? '<h' + m[1].length + '>' + esc(m[2]) + '</h' + m[1].length + '>' : '<p>' + esc(l) + '</p>';
        }).join('') + '</div>';
      } else if (c.cell_type === 'code') {
        h += '<pre style="background:#f4f5f9;padding:10px;border-radius:8px;overflow:auto">' + esc(src(c)) + '</pre>';
        (c.outputs || []).forEach(function (o) {
          var d = o.data || {};
          if (d['image/png']) h += '<img src="data:image/png;base64,' + String(d['image/png']).replace(/\s/g, '') + '">';
          else if (d['text/html']) h += '<div style="overflow:auto">' + (Array.isArray(d['text/html']) ? d['text/html'].join('') : d['text/html']).replace(/<script[\s\S]*?<\/script>/gi, '') + '</div>';
          else if (d['text/plain'] || o.text) h += '<pre style="color:#444;margin:0 0 12px">' + esc(Array.isArray(d['text/plain'] || o.text) ? (d['text/plain'] || o.text).join('') : (d['text/plain'] || o.text)) + '</pre>';
          else if (o.traceback) h += '<pre style="color:#b3261e">' + esc(o.traceback.join('\n').replace(/\u001b\[[0-9;]*m/g, '')) + '</pre>';
        });
      }
    });
    return { html: h || '<p>Empty notebook.</p>' };
  };

  /* ---------- VCF (contacts) ---------- */
  L.vcf = async function (e) {
    var txt = unfold(await e.file.text()), cards = txt.split(/BEGIN:VCARD/i).slice(1), h = '';
    cards.forEach(function (c) {
      var g = function (k) { var out = []; c.split(/\r?\n/).forEach(function (l) { var m = new RegExp('^' + k + '[^:]*:(.*)$', 'i').exec(l); if (m && m[1].trim()) out.push(m[1].trim().replace(/;+/g, ' ').trim()); }); return out; };
      var name = g('FN')[0] || g('N')[0] || '(no name)';
      var rows = [['Phone', g('TEL')], ['Email', g('EMAIL')], ['Company', g('ORG')], ['Address', g('ADR')], ['Note', g('NOTE')]].filter(function (r) { return r[1].length; })
        .map(function (r) { return '<div><span style="color:#666">' + r[0] + ':</span> ' + r[1].map(esc).join(', ') + '</div>'; }).join('');
      h += '<div style="border:1px solid #d6d8e0;border-radius:12px;padding:12px;margin:0 0 10px"><b style="font-size:1.1em">' + esc(name) + '</b>' + rows + '</div>';
    });
    return { html: '<p style="color:#666">' + cards.length + ' contact(s)</p>' + h };
  };

  /* ---------- ICS (calendar) ---------- */
  function icsDate(v) {
    var m = /^(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2}))?/.exec(v || ''); if (!m) return { s: v || '', t: 0 };
    var d = new Date(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0));
    return { s: d.toLocaleDateString() + (m[4] ? ' ' + ('0' + m[4]).slice(-2) + ':' + m[5] : ''), t: d.getTime() };
  }
  L.ics = async function (e) {
    var txt = unfold(await e.file.text()), evs = txt.split(/BEGIN:VEVENT/i).slice(1).map(function (c) {
      var g = function (k) { var m = new RegExp('^' + k + '[^:\\r\\n]*:(.*)$', 'im').exec(c); return m ? m[1].trim().replace(/\\n/gi, '\n').replace(/\\,/g, ',') : ''; };
      var st = icsDate(g('DTSTART')), en = icsDate(g('DTEND'));
      return { t: st.t, h: '<div style="border-left:4px solid #1a73e8;padding:6px 12px;margin:0 0 10px"><b>' + esc(g('SUMMARY') || '(no title)') + '</b><br><span style="color:#555">' + esc(st.s) + (en.s ? ' to ' + esc(en.s) : '') + '</span>' + (g('LOCATION') ? '<br>' + esc(g('LOCATION')) : '') + (g('DESCRIPTION') ? '<div style="color:#555;white-space:pre-wrap">' + esc(g('DESCRIPTION')) + '</div>' : '') + '</div>' };
    });
    evs.sort(function (a, b) { return a.t - b.t; });
    return { html: '<p style="color:#666">' + evs.length + ' event(s)</p>' + evs.map(function (x) { return x.h; }).join('') };
  };

  /* ---------- Apple iWork previews ---------- */
  function iwork(label) {
    return async function (e) {
      var Z = mapZip(O.readZip(await e.file.arrayBuffer())), key = Object.keys(Z).filter(function (k) { return /(thumbnail|preview).*\.(jpe?g|png)$/i.test(k); })[0];
      var img = key ? await dataUrl(Z, key) : '';
      return { html: '<p><b>' + label + ' file.</b> Only the preview picture can be shown. Export it from the original app as PDF or Word for the full content.</p>' + (img ? '<img src="' + img + '" style="max-width:100%;border:1px solid #ddd">' : '<p>No preview is stored in this file.</p>') };
    };
  }
  L.pages = iwork('Pages'); L.numbers = iwork('Numbers'); L.key = iwork('Keynote');
})();
