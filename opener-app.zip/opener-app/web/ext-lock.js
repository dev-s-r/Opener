/* Opener - password protected files: encrypted zip (ZipCrypto + WinZip AES) and encrypted Word/Excel/PowerPoint (Office 2010+ "agile" encryption). */
(function () {
  'use strict';
  var O = window.__opener;
  if (!O) return;
  var subtle = window.crypto && window.crypto.subtle;
  var te = new TextEncoder();

  /* ---------- password dialog ---------- */
  O.askPassword = function (name, error) {
    return new Promise(function (resolve) {
      var old = document.getElementById('zvScrim'); if (old) old.remove();
      var scrim = document.createElement('div'); scrim.className = 'dscrim'; scrim.id = 'zvScrim';
      scrim.innerHTML = '<div class="dialog" role="dialog"><h3>Password needed</h3><p style="margin:0 0 12px"></p>' +
        '<input type="password" id="pwIn" autocomplete="off" autocapitalize="off" placeholder="Password" style="width:100%;height:48px;border-radius:12px;border:1px solid var(--outline-v);background:var(--surface);color:var(--on-surface);padding:0 14px;font:inherit;font-size:16px;box-sizing:border-box">' +
        '<p id="pwErr" style="margin:8px 0 0;color:var(--error);min-height:20px;font-size:14px"></p>' +
        '<div class="actions"><button class="btn text sl" id="pwNo">Cancel</button><button class="btn text sl" id="pwOk">Open</button></div></div>';
      scrim.querySelector('p').textContent = name + ' is locked. Enter its password.';
      scrim.querySelector('#pwErr').textContent = error || '';
      scrim.id = 'zvScrim';
      document.body.append(scrim);
      var inp = scrim.querySelector('#pwIn'); setTimeout(function () { inp.focus(); }, 80);
      function done(v) { scrim.remove(); resolve(v); }
      scrim.querySelector('#pwNo').onclick = function () { done(null); };
      scrim.querySelector('#pwOk').onclick = function () { done(inp.value); };
      inp.onkeydown = function (ev) { if (ev.key === 'Enter') done(inp.value); };
    });
  };

  /* ---------- AES block encrypt (only needed for the WinZip AES counter mode) ---------- */
  var SBOX = null, MUL2 = null, MUL3 = null;
  function initAes() {
    if (SBOX) return;
    SBOX = new Uint8Array(256); MUL2 = new Uint8Array(256); MUL3 = new Uint8Array(256);
    var p = 1, q = 1, rot = function (x, n) { return ((x << n) | (x >> (8 - n))) & 255; };
    do {
      p = (p ^ (p << 1) ^ (p & 0x80 ? 0x1b : 0)) & 255;
      q = (q ^ (q << 1)) & 255; q = (q ^ (q << 2)) & 255; q = (q ^ (q << 4)) & 255; if (q & 0x80) q ^= 0x09;
      SBOX[p] = (q ^ rot(q, 1) ^ rot(q, 2) ^ rot(q, 3) ^ rot(q, 4) ^ 0x63) & 255;
    } while (p !== 1);
    SBOX[0] = 0x63;
    for (var i = 0; i < 256; i++) { var x = (i << 1) ^ (i & 0x80 ? 0x1b : 0); MUL2[i] = x & 255; MUL3[i] = (x ^ i) & 255; }
  }
  function expandKey(key) {
    initAes();
    var nk = key.length / 4, nr = nk + 6, w = new Uint8Array(16 * (nr + 1)), rc = 1, t = new Uint8Array(4), i, j;
    w.set(key);
    for (i = nk; i < 4 * (nr + 1); i++) {
      for (j = 0; j < 4; j++) t[j] = w[4 * (i - 1) + j];
      if (i % nk === 0) {
        var tmp = t[0]; t[0] = SBOX[t[1]] ^ rc; t[1] = SBOX[t[2]]; t[2] = SBOX[t[3]]; t[3] = SBOX[tmp];
        rc = MUL2[rc];
      } else if (nk > 6 && i % nk === 4) { for (j = 0; j < 4; j++) t[j] = SBOX[t[j]]; }
      for (j = 0; j < 4; j++) w[4 * i + j] = w[4 * (i - nk) + j] ^ t[j];
    }
    return { w: w, nr: nr };
  }
  function encBlock(ks, inp, out) {
    var s = new Uint8Array(16), t = new Uint8Array(16), r, i, w = ks.w;
    for (i = 0; i < 16; i++) s[i] = inp[i] ^ w[i];
    for (r = 1; r <= ks.nr; r++) {
      for (i = 0; i < 16; i++) s[i] = SBOX[s[i]];
      // shift rows
      t[0] = s[0]; t[1] = s[5]; t[2] = s[10]; t[3] = s[15]; t[4] = s[4]; t[5] = s[9]; t[6] = s[14]; t[7] = s[3];
      t[8] = s[8]; t[9] = s[13]; t[10] = s[2]; t[11] = s[7]; t[12] = s[12]; t[13] = s[1]; t[14] = s[6]; t[15] = s[11];
      if (r < ks.nr) {
        for (var c = 0; c < 4; c++) {
          var a0 = t[4 * c], a1 = t[4 * c + 1], a2 = t[4 * c + 2], a3 = t[4 * c + 3];
          s[4 * c] = MUL2[a0] ^ MUL3[a1] ^ a2 ^ a3; s[4 * c + 1] = a0 ^ MUL2[a1] ^ MUL3[a2] ^ a3;
          s[4 * c + 2] = a0 ^ a1 ^ MUL2[a2] ^ MUL3[a3]; s[4 * c + 3] = MUL3[a0] ^ a1 ^ a2 ^ MUL2[a3];
        }
      } else s.set(t);
      for (i = 0; i < 16; i++) s[i] ^= w[16 * r + i];
    }
    out.set(s);
  }
  O._aesEncBlock = function (key, block) { var o = new Uint8Array(16); encBlock(expandKey(key), block, o); return o; };
  // WinZip AES-CTR: 128-bit little-endian counter starting at 1
  function ctrLE(key, data) {
    var ks = expandKey(key), ctr = new Uint8Array(16), blk = new Uint8Array(16), out = new Uint8Array(data.length), i, j;
    ctr[0] = 1;
    for (i = 0; i < data.length; i += 16) {
      encBlock(ks, ctr, blk);
      var n = Math.min(16, data.length - i);
      for (j = 0; j < n; j++) out[i + j] = data[i + j] ^ blk[j];
      for (j = 0; j < 16; j++) { ctr[j] = (ctr[j] + 1) & 255; if (ctr[j] !== 0) break; }
    }
    return out;
  }

  /* ---------- ZIP decryption ---------- */
  var CRC = null;
  function crcTable() { if (CRC) return CRC; CRC = new Uint32Array(256); for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; CRC[n] = c >>> 0; } return CRC; }
  function badPass() { var e = new Error('Wrong password'); e.code = 'BADPASS'; return e; }
  O.zipDecrypt = async function (raw, m, pw) {
    var method = m.method, plain;
    if (method === 99) {
      var ex = m.lextra, p = 0, strength = 0, actual = 0;
      var dv = new DataView(ex.buffer, ex.byteOffset, ex.byteLength);
      while (p + 4 <= ex.length) {
        var id = dv.getUint16(p, true), sz = dv.getUint16(p + 2, true);
        if (id === 0x9901) { strength = ex[p + 8]; actual = dv.getUint16(p + 9, true); }
        p += 4 + sz;
      }
      if (!strength) throw new Error('Unsupported encryption');
      var kl = [16, 24, 32][strength - 1], sl = kl / 2;
      var salt = raw.subarray(0, sl), pv = raw.subarray(sl, sl + 2), data = raw.subarray(sl + 2, raw.length - 10), mac = raw.subarray(raw.length - 10);
      var base = await subtle.importKey('raw', te.encode(pw), 'PBKDF2', false, ['deriveBits']);
      var bits = new Uint8Array(await subtle.deriveBits({ name: 'PBKDF2', salt: salt, iterations: 1000, hash: 'SHA-1' }, base, (2 * kl + 2) * 8));
      if (bits[2 * kl] !== pv[0] || bits[2 * kl + 1] !== pv[1]) throw badPass();
      var hk = await subtle.importKey('raw', bits.subarray(kl, 2 * kl), { name: 'HMAC', hash: 'SHA-1' }, false, ['sign']);
      var sig = new Uint8Array(await subtle.sign('HMAC', hk, data));
      for (var i = 0; i < 10; i++) if (sig[i] !== mac[i]) throw new Error('The file is damaged or the password is wrong');
      plain = ctrLE(bits.subarray(0, kl), data); method = actual;
    } else {
      var keys = [0x12345678, 0x23456789, 0x34567890], T = crcTable();
      var crcb = function (c, b) { return (T[(c ^ b) & 255] ^ (c >>> 8)) >>> 0; };
      var upd = function (b) {
        keys[0] = crcb(keys[0], b);
        keys[1] = (keys[1] + (keys[0] & 255)) >>> 0; keys[1] = (Math.imul(keys[1], 134775813) + 1) >>> 0;
        keys[2] = crcb(keys[2], keys[1] >>> 24);
      };
      var pb = te.encode(pw); for (var a = 0; a < pb.length; a++) upd(pb[a]);
      var dc = function (c) { var t = (keys[2] & 0xffff) | 2, pbyte = (c ^ (Math.imul(t, t ^ 1) >>> 8)) & 255; upd(pbyte); return pbyte; };
      var hdr = new Uint8Array(12); for (var h = 0; h < 12; h++) hdr[h] = dc(raw[h]);
      var check = (m.flags & 8) ? (m.dostime >>> 8) & 255 : (m.crc >>> 24) & 255;
      if (hdr[11] !== check) throw badPass();
      plain = new Uint8Array(raw.length - 12); for (var d = 0; d < plain.length; d++) plain[d] = dc(raw[12 + d]);
    }
    if (method === 0) return plain;
    if (method === 8) return O.inflate(plain, 'deflate-raw');
    throw new Error('Unsupported compression (method ' + method + ')');
  };

  /* ---------- Office (CFB + agile encryption) ---------- */
  function u16(b, o) { return b[o] | (b[o + 1] << 8); }
  function u32(b, o) { return (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0; }
  O.isCfb = function (buf) { var b = new Uint8Array(buf, 0, Math.min(8, buf.byteLength)); return b.length === 8 && b[0] === 0xD0 && b[1] === 0xCF && b[2] === 0x11 && b[3] === 0xE0 && b[4] === 0xA1 && b[5] === 0xB1 && b[6] === 0x1A && b[7] === 0xE1; };
  function cfbRead(u8) {
    var ss = 1 << u16(u8, 30), mss = 1 << u16(u8, 32), END = 0xFFFFFFFE;
    var nFat = u32(u8, 44), dirStart = u32(u8, 48), cutoff = u32(u8, 56), mfStart = u32(u8, 60), difat = u32(u8, 68), nDifat = u32(u8, 72);
    var sec = function (id) { var o = (id + 1) * ss; return u8.subarray(o, o + ss); };
    var fatIds = [], i;
    for (i = 0; i < 109 && fatIds.length < nFat; i++) fatIds.push(u32(u8, 76 + 4 * i));
    for (var d = 0; d < nDifat && difat < END; d++) {
      var ds = sec(difat);
      for (i = 0; i < ss / 4 - 1 && fatIds.length < nFat; i++) fatIds.push(u32(ds, 4 * i));
      difat = u32(ds, ss - 4);
    }
    var fat = [];
    fatIds.forEach(function (id) { var s = sec(id); for (var k = 0; k < ss / 4; k++) fat.push(u32(s, 4 * k)); });
    function chain(start, table, size, get) {
      var parts = [], id = start, guard = 0;
      while (id < 0xFFFFFFFA && guard++ < 5e6) { parts.push(get(id)); id = table[id]; }
      var out = new Uint8Array(parts.length * size); parts.forEach(function (p, n) { out.set(p, n * size); }); return out;
    }
    var dir = chain(dirStart, fat, ss, sec), entries = [];
    for (i = 0; i + 128 <= dir.length; i += 128) {
      var nl = u16(dir, i + 64), name = '';
      for (var c = 0; c + 2 <= nl - 2 && c < 64; c += 2) name += String.fromCharCode(u16(dir, i + c));
      entries.push({ name: name, type: dir[i + 66], start: u32(dir, i + 116), size: u32(dir, i + 120) });
    }
    var root = entries[0], mini = root ? chain(root.start, fat, ss, sec).subarray(0, root.size) : new Uint8Array(0);
    var mfBytes = mfStart < END ? chain(mfStart, fat, ss, sec) : new Uint8Array(0), miniFat = [];
    for (i = 0; i + 4 <= mfBytes.length; i += 4) miniFat.push(u32(mfBytes, i));
    var out = {};
    entries.forEach(function (en) {
      if (en.type !== 2) return;
      out[en.name] = en.size < cutoff
        ? chain(en.start, miniFat, mss, function (id) { return mini.subarray(id * mss, id * mss + mss); }).subarray(0, en.size)
        : chain(en.start, fat, ss, sec).subarray(0, en.size);
    });
    return out;
  }
  function b64(s) { var bin = atob(s), u = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
  function cat() { var n = 0, a = arguments, i; for (i = 0; i < a.length; i++) n += a[i].length; var o = new Uint8Array(n), p = 0; for (i = 0; i < a.length; i++) { o.set(a[i], p); p += a[i].length; } return o; }
  function le32(n) { return new Uint8Array([n & 255, (n >>> 8) & 255, (n >>> 16) & 255, (n >>> 24) & 255]); }
  var HASHES = { SHA1: 'SHA-1', SHA256: 'SHA-256', SHA384: 'SHA-384', SHA512: 'SHA-512' };

  async function decNoPad(keyBytes, iv, data) {
    var key = await subtle.importKey('raw', keyBytes, 'AES-CBC', false, ['encrypt', 'decrypt']);
    var last = data.subarray(data.length - 16);
    var padBlk = new Uint8Array(await subtle.encrypt({ name: 'AES-CBC', iv: last }, key, new Uint8Array(16).fill(16))).subarray(0, 16);
    return new Uint8Array(await subtle.decrypt({ name: 'AES-CBC', iv: iv }, key, cat(data, padBlk)));
  }
  async function officeDecrypt(buf, pw) {
    var cf = cfbRead(new Uint8Array(buf)), info = cf.EncryptionInfo, pkg = cf.EncryptedPackage;
    if (!info || !pkg) throw new Error('This is not a protected Office file');
    if (u16(info, 0) !== 4 || u16(info, 2) !== 4) throw new Error('This file uses an older kind of Office protection that Opener cannot open yet.');
    var doc = new DOMParser().parseFromString(new TextDecoder().decode(info.subarray(8)), 'application/xml');
    var kd = doc.getElementsByTagNameNS('*', 'keyData')[0], ek = doc.getElementsByTagNameNS('*', 'encryptedKey')[0];
    if (!kd || !ek) throw new Error('Unsupported protection type');
    var alg = HASHES[ek.getAttribute('hashAlgorithm')], kdAlg = HASHES[kd.getAttribute('hashAlgorithm')];
    if (!alg || !kdAlg) throw new Error('Unsupported protection type');
    var spin = +ek.getAttribute('spinCount'), keyBits = +ek.getAttribute('keyBits'), hashSize = +ek.getAttribute('hashSize');
    var salt = b64(ek.getAttribute('saltValue')), kdSalt = b64(kd.getAttribute('saltValue'));
    var H = async function () { return new Uint8Array(await subtle.digest(alg, cat.apply(null, arguments))); };
    var pwb = new Uint8Array(pw.length * 2); for (var i = 0; i < pw.length; i++) { pwb[2 * i] = pw.charCodeAt(i) & 255; pwb[2 * i + 1] = pw.charCodeAt(i) >> 8; }
    var h = await H(salt, pwb);
    for (i = 0; i < spin; i++) h = await H(le32(i), h);
    var fit = function (b, n) { var o = new Uint8Array(n).fill(0x36); o.set(b.subarray(0, Math.min(n, b.length))); return o; };
    var keyFor = async function (blk) { return fit(await H(h, new Uint8Array(blk)), keyBits / 8); };
    var vIn = await decNoPad(await keyFor([0xfe, 0xa7, 0xd2, 0x76, 0x3b, 0x4b, 0x9e, 0x79]), salt, b64(ek.getAttribute('encryptedVerifierHashInput')));
    var want = await H(vIn.subarray(0, salt.length));
    var vVal = await decNoPad(await keyFor([0xd7, 0xaa, 0x0f, 0x6d, 0x30, 0x61, 0x34, 0x4e]), salt, b64(ek.getAttribute('encryptedVerifierHashValue')));
    for (i = 0; i < hashSize; i++) if (want[i] !== vVal[i]) throw badPass();
    var secret = (await decNoPad(await keyFor([0x14, 0x6e, 0x0b, 0xe7, 0xab, 0xac, 0xd0, 0xd6]), salt, b64(ek.getAttribute('encryptedKeyValue')))).subarray(0, keyBits / 8);
    var size = Number(new DataView(pkg.buffer, pkg.byteOffset, 8).getBigUint64(0, true)), data = pkg.subarray(8), outParts = [];
    for (var seg = 0, off = 0; off < data.length; seg++, off += 4096) {
      var chunk = data.subarray(off, Math.min(off + 4096, data.length)); if (chunk.length % 16) chunk = cat(chunk, new Uint8Array(16 - chunk.length % 16));
      var iv = new Uint8Array(await subtle.digest(kdAlg, cat(kdSalt, le32(seg)))).subarray(0, 16);
      outParts.push(await decNoPad(secret, iv, chunk));
    }
    return cat.apply(null, outParts).subarray(0, size);
  }
  // Ask for the password until it works (or the person cancels). Returns the plain file bytes.
  O.unlockOffice = async function (buf, name) {
    var err = '';
    for (;;) {
      var pw = await O.askPassword(name, err);
      if (pw === null) throw new Error('Password needed to open this file');
      try { return (await officeDecrypt(buf, pw)).slice().buffer; }
      catch (e) { if (e && e.code === 'BADPASS') err = 'That password is not right. Try again.'; else throw e; }
    }
  };
  O._officeDecrypt = officeDecrypt;
  O._ctrLE = ctrLE;
})();
