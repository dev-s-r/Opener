package __PACKAGE__;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.BridgeActivity;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends BridgeActivity {

  private static class Item {
    String name;
    String type;
    Uri uri;
    byte[] bytes;
  }

  private final List<Item> pending = new ArrayList<>();

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    // Edge-to-edge on every Android version; we pad the content by the system bars ourselves.
    WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
    final View root = findViewById(android.R.id.content);
    ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
      Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
      Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
      v.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
      return WindowInsetsCompat.CONSUMED;
    });
    ViewCompat.requestApplyInsets(root);
    getWindow().getDecorView().setBackgroundColor(Color.parseColor("#F9F9FF"));

    getBridge().getWebView().addJavascriptInterface(new NativeBridge(), "AndroidBridge");

    // Back gesture: let the web app close dialogs/menus/drawer first, otherwise leave the app.
    getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
      @Override
      public void handleOnBackPressed() {
        getBridge().getWebView().evaluateJavascript(
            "window.__nativeBack ? window.__nativeBack() : false",
            value -> { if (!"true".equals(value)) finish(); });
      }
    });

    if (savedInstanceState == null) collect(getIntent());
  }

  @Override
  protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    setIntent(intent);
    collect(intent);
    runOnUiThread(() -> getBridge().getWebView().evaluateJavascript(
        "window.__nativeFilesReady && window.__nativeFilesReady()", null));
  }

  /* ---------- incoming files (Open with / Share) ---------- */

  @SuppressWarnings({"deprecation", "unchecked"})
  private void collect(Intent intent) {
    if (intent == null || intent.getAction() == null) return;
    String action = intent.getAction();
    List<Uri> uris = new ArrayList<>();

    if (Intent.ACTION_VIEW.equals(action)) {
      if (intent.getData() != null) uris.add(intent.getData());
    } else if (Intent.ACTION_SEND.equals(action)) {
      Uri u = (Uri) intent.getParcelableExtra(Intent.EXTRA_STREAM);
      if (u != null) {
        uris.add(u);
      } else {
        String text = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (text != null) {
          Item it = new Item();
          it.name = "shared-text.txt";
          it.type = "text/plain";
          it.bytes = text.getBytes(StandardCharsets.UTF_8);
          synchronized (pending) { pending.add(it); }
        }
      }
    } else if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
      ArrayList<Uri> list = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
      if (list != null) uris.addAll(list);
    }

    for (Uri u : uris) {
      Item it = new Item();
      it.uri = u;
      it.name = displayName(u);
      String t = getContentResolver().getType(u);
      if (t == null || t.equals("application/octet-stream")) t = intent.getType();
      it.type = t == null ? "" : t;
      synchronized (pending) { pending.add(it); }
    }
    intent.setAction(null); // don't import the same file twice
  }

  private String displayName(Uri uri) {
    try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
      if (c != null && c.moveToFirst()) {
        String n = c.getString(0);
        if (n != null && !n.isEmpty()) return n;
      }
    } catch (Exception ignored) { }
    String last = uri.getLastPathSegment();
    if (last == null) return "file";
    int slash = last.lastIndexOf('/');
    return slash >= 0 ? last.substring(slash + 1) : last;
  }

  private byte[] readAll(Uri uri) throws Exception {
    try (InputStream in = getContentResolver().openInputStream(uri)) {
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      byte[] buf = new byte[64 * 1024];
      int n;
      while (in != null && (n = in.read(buf)) > 0) out.write(buf, 0, n);
      return out.toByteArray();
    }
  }

  private void toast(final String msg) {
    runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
  }

  /* ---------- bridge exposed to JavaScript ---------- */

  private class NativeBridge {

    @JavascriptInterface
    public int pendingCount() {
      synchronized (pending) { return pending.size(); }
    }

    @JavascriptInterface
    public String pendingInfo(int i) {
      try {
        Item it;
        synchronized (pending) { it = pending.get(i); }
        JSONObject o = new JSONObject();
        o.put("name", it.name);
        o.put("type", it.type);
        return o.toString();
      } catch (Exception e) {
        return "{}";
      }
    }

    @JavascriptInterface
    public String pendingData(int i) {
      try {
        Item it;
        synchronized (pending) { it = pending.get(i); }
        byte[] data = it.bytes != null ? it.bytes : readAll(it.uri);
        return Base64.encodeToString(data, Base64.NO_WRAP);
      } catch (Exception e) {
        toast("Couldn't read the file");
        return "";
      }
    }

    @JavascriptInterface
    public void clearPending(int n) {
      synchronized (pending) {
        for (int i = 0; i < n && !pending.isEmpty(); i++) pending.remove(0);
      }
    }

    @JavascriptInterface
    public boolean saveFile(String name, String mime, String base64) {
      boolean ok = write(name, mime, base64);
      toast(ok ? "Saved to Downloads: " + name : "Couldn't save the file");
      return ok;
    }

    @JavascriptInterface
    public boolean saveFileQuiet(String name, String mime, String base64) {
      return write(name, mime, base64);
    }

    // name may contain folders ("archive/sub/file.txt"); they are created inside Downloads.
    private boolean write(String name, String mime, String base64) {
      try {
        StringBuilder clean = new StringBuilder();
        for (String part : name.replace('\\', '/').split("/")) {
          if (part.isEmpty() || part.equals(".") || part.equals("..")) continue;
          if (clean.length() > 0) clean.append('/');
          clean.append(part);
        }
        String path = clean.toString();
        if (path.isEmpty()) path = "file";
        int slash = path.lastIndexOf('/');
        String dir = slash < 0 ? "" : path.substring(0, slash);
        String base = slash < 0 ? path : path.substring(slash + 1);
        byte[] data = Base64.decode(base64, Base64.DEFAULT);
        String type = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
        if (Build.VERSION.SDK_INT >= 29) {
          ContentValues v = new ContentValues();
          v.put(MediaStore.Downloads.DISPLAY_NAME, base);
          v.put(MediaStore.Downloads.MIME_TYPE, type);
          v.put(MediaStore.Downloads.RELATIVE_PATH, dir.isEmpty() ? Environment.DIRECTORY_DOWNLOADS : Environment.DIRECTORY_DOWNLOADS + "/" + dir);
          Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
          if (uri == null) throw new Exception("insert failed");
          try (OutputStream os = getContentResolver().openOutputStream(uri)) {
            os.write(data);
          }
        } else {
          File target = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), path);
          File parent = target.getParentFile();
          if (parent != null) parent.mkdirs();
          try (FileOutputStream os = new FileOutputStream(target)) {
            os.write(data);
          }
        }
        return true;
      } catch (Exception e) {
        return false;
      }
    }

    @JavascriptInterface
    public void setChrome(final String hex, final boolean dark) {
      runOnUiThread(() -> {
        try {
          getWindow().getDecorView().setBackgroundColor(Color.parseColor(hex));
          WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
          c.setAppearanceLightStatusBars(!dark);
          c.setAppearanceLightNavigationBars(!dark);
        } catch (Exception ignored) { }
      });
    }
  }
}
