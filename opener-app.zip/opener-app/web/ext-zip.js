/* Opener - archive viewer / extractor (.zip, .jar, .apk, .docx ..., .tar, .tar.gz, .tgz, .gz). No libraries needed. */
(function () {
  'use strict';
  var O = window.__opener;
  if (!O) return;

  /* ---------- styles ---------- */
  var css = document.createElement('style');
  css.textContent = [
    '#zipView{flex:1;overflow:auto;background:var(--surface);display:flex;flex-direction:column;min-height:0}',
    '.zv-head{padding:12px 16px 8px;display:flex;flex-direction:column;gap:8px;border-bottom:1px solid var(--outline-v);background:var(--surface-low);position:sticky;top:0;z-index:2}',
    '.zv-top{display:flex;align-items:center;gap:8px}',
    '.zv-title{flex:1;min-width:0;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.zv-sub{font-size:13px;color:var(--on-surface-v);line-height:18px}',
    '.zv-btn{height:36px;padding:0 14px;border-radius:18px;background:var(--primary);color:var(--on-primary);font-weight:500;font-size:14px;white-space:nowrap}',
    '.zv-btn.tonal{background:var(--secondary-c);color:var(--on-secondary-c)}',
    '.zv-search{height:40px;border-radius:20px;border:1px solid var(--outline-v);background:var(--surface);color:var(--on-surface);padding:0 16px;font:inherit;font-size:15px;width:100%}',
    '.zv-crumb{display:flex;gap:4px;flex-wrap:wrap;font-size:13px;color:var(--on-surface-v)}',
    '.zv-crumb button{color:var(--primary);padding:2px 4px;border-radius:6px}',
    '.zv-list{flex:1;padding:4px 0 24px}',
    '.zv-row{display:flex;align-items:center;gap:12px;padding:6px 8px 6px 16px;min-height:52px;cursor:pointer}',
    '.zv-row:hover,.zv-row:active{background:var(--surface-mid)}',
    '.zv-row .ico{color:var(--on-surface-v)}',
    '.zv-row.dir .ico{color:var(--primary)}',
    '.zv-name{flex:1;min-width:0}',
    '.zv-name b{display:block;font-weight:400;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.zv-name small{display:block;font-size:12px;line-height:16px;color:var(--on-surface-v);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.zv-more{width:40px;height:40px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;color:var(--on-surface-v);flex:none}',
    '.zv-more:hover{background:var(--surface-high)}',
    '.zv-msg{padding:32px 24px;text-align:center;color:var(--on-surface-v)}',
    '.zv-pv{max-height:60vh;overflow:auto;margin:0 0 12px;border-radius:12px;background:var(--surface-low);padding:12px}',
    '.zv-pv pre{margin:0;font:12.5px/1.5 var(--mono);white-space:pre-wrap;word-break:break-word;color:var(--on-surface)}',
    '.zv-pv img{max-width:100%;display:block;margin:0 auto}',
    '.zv-pv iframe{width:100%;height:55vh;border:0;background:#fff}'
  ].join('\n');
  document.head.append(css);

  /* ---------- helpers ---------- */
  var MIME = {
    html: 'text/html', htm: 'text/html', css: 'text/css', js: 'text/javascript', json: 'application/json', md: 'text/markdown',
    txt: 'text/plain', xml: 'text/xml', svg: 'image/svg+xml', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif',
    webp: 'image/webp', bmp: 'image/bmp', ico: 'image/x-icon', pdf: 'application/pdf', zip: 'application/zip', csv: 'text/csv'
  };
  var extOf = function (n) { var i = n.lastIndexOf('.'); return i < 0 ? '' : n.slice(i + 1).toLowerCase(); };
  var baseOf = function (p) { return p.slice(p.lastIndexOf('/') + 1); };
  var mimeOf = function (n) { return MIME[extOf(n)] || ''; };
  var TEXT_EXT = /^(txt|md|markdown|html?|css|js|mjs|json|xml|csv|tsv|svg|yml|yaml|ini|cfg|conf|log|py|java|kt|c|h|cpp|cs|go|rs|rb|php|sh|bat|sql|ts|tsx|jsx|vue|toml|gradle|properties|rels|mf|gitignore|env|rtf)$/i;
  var safePath = function (p) {
    return p.replace(/\\/g, '/').split('/').filter(function (s) { return s && s !== '.' && s !== '..'; }).join('/');
  };
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  async function inflate(u8, format) {
    var ds = new DecompressionStream(format);
    var out = new Blob([u8]).stream().pipeThrough(ds);
    return new Uint8Array(await new Response(out).arrayBuffer());
  }

  function decodeName(bytes, utf8) {
    try { return new TextDecoder('utf-8', { fatal: true }).decode(bytes); } catch (e) { /* fall through */ }
    return new TextDecoder(utf8 ? 'utf-8' : 'windows-1252').decode(bytes);
  }

  /* ---------- ZIP reader ---------- */
  function readZip(buf, holder) {
    var u8 = new Uint8Array(buf), dv = new DataView(buf);
    var eocd = -1;
    for (var i = u8.length - 22; i >= Math.max(0, u8.length - 65557); i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('Not a valid ZIP file');
    var total = dv.getUint16(eocd + 10, true), cdSize = dv.getUint32(eocd + 12, true), cdOff = dv.getUint32(eocd + 16, true);
    if (total === 0xffff || cdOff === 0xffffffff) {
      var loc = eocd - 20;
      if (loc >= 0 && dv.getUint32(loc, true) === 0x07064b50) {
        var z64 = Number(dv.getBigUint64(loc + 8, true));
        if (dv.getUint32(z64, true) === 0x06064b50) {
          total = Number(dv.getBigUint64(z64 + 32, true));
          cdSize = Number(dv.getBigUint64(z64 + 40, true));
          cdOff = Number(dv.getBigUint64(z64 + 48, true));
        }
      }
    }
    var entries = [], p = cdOff;
    for (var n = 0; n < total && p + 46 <= u8.length; n++) {
      if (dv.getUint32(p, true) !== 0x02014b50) break;
      var flags = dv.getUint16(p + 8, true), method = dv.getUint16(p + 10, true);
      var time = dv.getUint16(p + 12, true), date = dv.getUint16(p + 14, true);
      var crc = dv.getUint32(p + 16, true), csize = dv.getUint32(p + 20, true), usize = dv.getUint32(p + 24, true);
      var nlen = dv.getUint16(p + 28, true), elen = dv.getUint16(p + 30, true), clen = dv.getUint16(p + 32, true);
      var lho = dv.getUint32(p + 42, true);
      var name = decodeName(u8.subarray(p + 46, p + 46 + nlen), !!(flags & 0x800));
      // zip64 extra field
      var ep = p + 46 + nlen, eend = ep + elen;
      while (ep + 4 <= eend) {
        var id = dv.getUint16(ep, true), sz = dv.getUint16(ep + 2, true), q = ep + 4;
        if (id === 1) {
          if (usize === 0xffffffff) { usize = Number(dv.getBigUint64(q, true)); q += 8; }
          if (csize === 0xffffffff) { csize = Number(dv.getBigUint64(q, true)); q += 8; }
          if (lho === 0xffffffff) { lho = Number(dv.getBigUint64(q, true)); q += 8; }
        }
        ep += 4 + sz;
      }
      var d = new Date(((date >> 9) & 127) + 1980, ((date >> 5) & 15) - 1, date & 31, (time >> 11) & 31, (time >> 5) & 63, (time & 31) * 2);
      entries.push(mk(name, usize, csize, d, flags & 1, method, lho, flags, crc, time));
      p += 46 + nlen + elen + clen;
    }
    function mk(name, usize, csize, date, enc, method, lho, flags, crc, dostime) {
      return {
        name: name, dir: /\/$/.test(name), size: usize, csize: csize, date: date, enc: !!enc,
        bytes: async function () {
          if (dv.getUint32(lho, true) !== 0x04034b50) throw new Error('Damaged entry');
          var lxl = dv.getUint16(lho + 28, true), start = lho + 30 + dv.getUint16(lho + 26, true) + lxl;
          var raw = u8.subarray(start, start + csize);
          if (enc) {
            if (!holder || !holder.pw || !O.zipDecrypt) throw new Error('This file is password protected');
            return O.zipDecrypt(raw, { method: method, flags: flags, crc: crc, dostime: dostime, lextra: u8.subarray(start - lxl, start) }, holder.pw);
          }
          if (method === 0) return raw.slice();
          if (method === 8) return inflate(raw, 'deflate-raw');
          throw new Error('Unsupported compression (method ' + method + ')');
        }
      };
    }
    return entries;
  }

  /* ---------- TAR reader ---------- */
  function readTar(u8) {
    var entries = [], p = 0, longName = null, dec = new TextDecoder();
    var str = function (a, b) { var s = dec.decode(u8.subarray(a, b)); var z = s.indexOf('\u0000'); return z < 0 ? s : s.slice(0, z); };
    while (p + 512 <= u8.length) {
      if (u8[p] === 0) break;
      var name = str(p, p + 100), size = parseInt(str(p + 124, p + 136).trim() || '0', 8) || 0;
      var type = String.fromCharCode(u8[p + 156] || 48), prefix = str(p + 345, p + 500);
      var mtime = (parseInt(str(p + 136, p + 148).trim() || '0', 8) || 0) * 1000;
      if (prefix) name = prefix + '/' + name;
      name = name.replace(/^(\.\/)+/, '');
      var dataStart = p + 512;
      if (type === 'L') { longName = str(dataStart, dataStart + size); }
      else if (type === 'x' || type === 'g') { /* pax header: ignore */ }
      else {
        if (longName) { name = longName; longName = null; }
        var isDir = type === '5';
        if (name && (isDir || type === '0' || type === '\u0000' || type === '7')) {
          (function (nm, st, sz, dir, mt) {
            entries.push({
              name: dir && !/\/$/.test(nm) ? nm + '/' : nm, dir: dir, size: sz, csize: sz, date: new Date(mt), enc: false,
              bytes: async function () { return u8.slice(st, st + sz); }
            });
          })(name, dataStart, size, isDir, mtime);
        }
      }
      p = dataStart + Math.ceil(size / 512) * 512;
    }
    return entries;
  }

  async function openArchive(e) {
    var name = e.name.toLowerCase();
    var buf = await e.file.arrayBuffer();
    if (/\.(tar\.gz|tgz)$/.test(name)) return readTar(await inflate(new Uint8Array(buf), 'gzip'));
    if (/\.tar$/.test(name)) return readTar(new Uint8Array(buf));
    if (/\.gz$/.test(name)) {
      var inner = e.name.replace(/\.gz$/i, '') || 'file';
      var u8 = await inflate(new Uint8Array(buf), 'gzip');
      return [{ name: inner, dir: false, size: u8.length, csize: buf.byteLength, date: null, enc: false, bytes: async function () { return u8; } }];
    }
    var holder = { pw: '' }, list = readZip(buf, holder);
    var locked = list.filter(function (x) { return x.enc && !x.dir && x.size > 0; })[0];
    if (locked && O.askPassword) {
      var err = '';
      for (;;) {
        var pw = await O.askPassword(e.name, err);
        if (pw === null) break;
        holder.pw = pw;
        try { await locked.bytes(); break; }
        catch (x) { holder.pw = ''; if (x && x.code === 'BADPASS') err = 'That password is not right. Try again.'; else { err = (x && x.message) || 'Could not unlock'; } }
      }
    }
    return list;
  }

  /* ---------- UI ---------- */
  var states = new Map();

  function folderOf(path) { var i = path.lastIndexOf('/'); return i < 0 ? '' : path.slice(0, i + 1); }

  async function render(e, token) {
    var box = O.$('#zipView');
    box.innerHTML = '<div class="zv-msg">Reading archive…</div>';
    var S = states.get(e.id);
    if (!S || S.file !== e.file) {
      try {
        S = { file: e.file, entries: null, cwd: '', q: '', limit: 300 };
        S.entries = (await openArchive(e)).filter(function (x) { return x.name; });
      } catch (err) {
        if (token !== O.token) return;
        box.innerHTML = '';
        var m = document.createElement('div'); m.className = 'zv-msg';
        m.textContent = 'Could not read this archive: ' + (err && err.message ? err.message : err);
        box.append(m);
        return;
      }
      states.set(e.id, S);
    }
    if (token !== O.token) return;
    draw(e, S);
  }

  function totals(S) {
    var files = 0, size = 0, csize = 0;
    S.entries.forEach(function (x) { if (!x.dir) { files++; size += x.size; csize += x.csize; } });
    return { files: files, size: size, csize: csize };
  }

  function listFor(S) {
    var q = S.q.trim().toLowerCase(), rows = [];
    if (q) {
      S.entries.forEach(function (x) { if (!x.dir && x.name.toLowerCase().indexOf(q) >= 0) rows.push({ dir: false, path: x.name, entry: x }); });
      return rows;
    }
    var dirs = new Map(), cwd = S.cwd;
    S.entries.forEach(function (x) {
      if (x.name.indexOf(cwd) !== 0 || x.name === cwd) return;
      var rest = x.name.slice(cwd.length), slash = rest.indexOf('/');
      if (slash >= 0) {
        var d = cwd + rest.slice(0, slash + 1);
        if (!dirs.has(d)) dirs.set(d, 0);
        if (!x.dir) dirs.set(d, dirs.get(d) + 1);
      } else if (!x.dir) rows.push({ dir: false, path: x.name, entry: x });
    });
    var out = [];
    Array.from(dirs.keys()).sort().forEach(function (d) { out.push({ dir: true, path: d, count: dirs.get(d) }); });
    rows.sort(function (a, b) { return a.path.localeCompare(b.path); });
    return out.concat(rows);
  }

  function draw(e, S) {
    var box = O.$('#zipView'), t = totals(S);
    box.innerHTML = '';
    var head = document.createElement('div'); head.className = 'zv-head';
    var top = document.createElement('div'); top.className = 'zv-top';
    var title = document.createElement('div'); title.className = 'zv-title'; title.textContent = e.name;
    var ex = document.createElement('button'); ex.className = 'zv-btn sl'; ex.textContent = 'Extract';
    ex.setAttribute('data-menu', '1');
    ex.onclick = function () { extractMenu(ex, e, S); };
    top.append(title, ex);
    var sub = document.createElement('div'); sub.className = 'zv-sub';
    var ratio = t.size ? ' · ' + Math.max(0, Math.round((1 - t.csize / t.size) * 100)) + '% smaller' : '';
    sub.textContent = t.files + ' file' + (t.files === 1 ? '' : 's') + ' · ' + O.fmtSize(t.size) + ratio;
    var search = document.createElement('input'); search.className = 'zv-search'; search.type = 'search';
    search.placeholder = 'Search in archive'; search.value = S.q; search.autocomplete = 'off';
    head.append(top, sub, search);

    var crumb = document.createElement('div'); crumb.className = 'zv-crumb';
    function crumbs() {
      crumb.innerHTML = '';
      var root = document.createElement('button'); root.textContent = '/'; root.onclick = function () { S.cwd = ''; S.limit = 300; redraw(); };
      crumb.append(root);
      var acc = '';
      S.cwd.split('/').filter(Boolean).forEach(function (part) {
        acc += part + '/';
        var b = document.createElement('button'), target = acc; b.textContent = part + ' /';
        b.onclick = function () { S.cwd = target; S.limit = 300; redraw(); };
        crumb.append(b);
      });
      crumb.hidden = !!S.q.trim();
    }
    head.append(crumb);
    box.append(head);

    var list = document.createElement('div'); list.className = 'zv-list';
    box.append(list);

    function redraw() {
      crumbs(); list.innerHTML = '';
      var rows = listFor(S);
      if (!rows.length) { var m = document.createElement('div'); m.className = 'zv-msg'; m.textContent = S.q ? 'No matches' : 'Empty'; list.append(m); return; }
      rows.slice(0, S.limit).forEach(function (r) { list.append(row(r)); });
      if (rows.length > S.limit) {
        var more = document.createElement('button'); more.className = 'zv-btn tonal sl'; more.style.margin = '12px 16px';
        more.textContent = 'Show more (' + (rows.length - S.limit) + ')';
        more.onclick = function () { S.limit += 500; redraw(); };
        list.append(more);
      }
    }
    function row(r) {
      var d = document.createElement('div'); d.className = 'zv-row sl' + (r.dir ? ' dir' : '');
      var icon = document.createElement('span'); icon.innerHTML = O.ic(r.dir ? 'folder' : (O.kindOf(r.path) === 'img' ? 'image' : 'file'));
      var nm = document.createElement('div'); nm.className = 'zv-name';
      var b = document.createElement('b'); b.textContent = r.dir ? r.path.slice(S.cwd.length).replace(/\/$/, '') : (S.q ? baseOf(r.path) : r.path.slice(S.cwd.length));
      var sm = document.createElement('small');
      if (r.dir) sm.textContent = r.count + ' file' + (r.count === 1 ? '' : 's');
      else sm.textContent = O.fmtSize(r.entry.size) + (S.q ? ' · ' + folderOf(r.path) : '') + (r.entry.enc ? ' · password protected' : '');
      nm.append(b, sm);
      d.append(icon, nm);
      if (!r.dir) {
        var more = document.createElement('button'); more.className = 'zv-more sl'; more.setAttribute('aria-label', 'More');
        more.innerHTML = O.ic('more'); more.setAttribute('data-menu', '1');
        more.onclick = function (ev) { ev.stopPropagation(); entryMenu(more, e, r.entry); };
        d.append(more);
      }
      d.onclick = function () {
        if (r.dir) { S.cwd = r.path; S.limit = 300; redraw(); box.scrollTop = 0; } else preview(e, r.entry);
      };
      return d;
    }
    var timer;
    search.oninput = function () { clearTimeout(timer); timer = setTimeout(function () { S.q = search.value; S.limit = 300; redraw(); }, 150); };
    redraw();
  }

  /* ---------- per-entry actions ---------- */
  function entryMenu(anchor, e, en) {
    O.showMenu(anchor, [
      { icon: 'search', label: 'Preview', run: function () { preview(e, en); } },
      { icon: 'file', label: 'Open in Opener', run: function () { addToWorkspace(e, [en], true); } },
      { icon: 'download', label: 'Save to device', run: function () { saveOne(en); } }
    ]);
  }

  async function toFile(en) {
    var b = await en.bytes();
    return new File([b], baseOf(en.name), { type: mimeOf(en.name) });
  }

  async function saveOne(en) {
    try {
      var f = await toFile(en);
      O.downloadBlob(f, baseOf(en.name));
    } catch (err) { O.toast(String(err && err.message || err)); }
  }

  async function addToWorkspace(e, list, openIt) {
    var root = e.name.replace(/\.(tar\.gz|tgz|[^.]+)$/i, '');
    var added = [], failed = 0;
    O.toast('Adding ' + list.length + ' file' + (list.length === 1 ? '' : 's') + '…');
    for (var i = 0; i < list.length; i++) {
      var en = list[i];
      if (en.dir) continue;
      try {
        var path = safePath(root + '/' + en.name);
        var f = await toFile(en);
        added.push(O.addFile(f, path, null));
      } catch (err) { failed++; }
      if (i % 25 === 24) await sleep(0);
    }
    if (!added.length) { O.toast('Nothing could be added'); return; }
    if (openIt && added.length === 1) { O.persistMany(added); await O.openEntry(added[0].id); }
    else await O.finish(added);
    O.toast('Added ' + added.length + ' file' + (added.length === 1 ? '' : 's') + (failed ? ' (' + failed + ' skipped)' : ''));
  }

  function b64(u8) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(',')[1] || ''); };
      r.onerror = rej;
      r.readAsDataURL(new Blob([u8]));
    });
  }

  async function saveAllToDownloads(e, S) {
    var B = window.AndroidBridge;
    var root = safePath(e.name.replace(/\.(tar\.gz|tgz|[^.]+)$/i, '')) || 'archive';
    var list = S.entries.filter(function (x) { return !x.dir; });
    var ok = 0, bad = 0;
    for (var i = 0; i < list.length; i++) {
      O.toast('Saving ' + (i + 1) + ' / ' + list.length + '…');
      try {
        var bytes = await list[i].bytes();
        var good = B.saveFileQuiet(root + '/' + safePath(list[i].name), mimeOf(list[i].name) || 'application/octet-stream', await b64(bytes));
        if (good) ok++; else bad++;
      } catch (err) { bad++; }
      if (i % 10 === 9) await sleep(0);
    }
    O.toast('Saved ' + ok + ' file' + (ok === 1 ? '' : 's') + ' to Downloads/' + root + (bad ? ' (' + bad + ' failed)' : ''));
  }

  function extractMenu(anchor, e, S) {
    var list = S.entries.filter(function (x) { return !x.dir; });
    var items = [
      { icon: 'add', label: 'Open all in Opener', run: function () { addToWorkspace(e, list, false); } }
    ];
    if (window.AndroidBridge) items.push({ icon: 'download', label: 'Save all to Downloads', run: function () { saveAllToDownloads(e, S); } });
    O.showMenu(anchor, items);
  }

  /* ---------- preview dialog (no extraction needed) ---------- */
  async function preview(e, en) {
    var old = O.$('#zvScrim'); if (old) old.remove();
    var scrim = document.createElement('div'); scrim.id = 'zvScrim'; scrim.className = 'dscrim';
    var dlg = document.createElement('div'); dlg.className = 'dialog wide'; dlg.setAttribute('role', 'dialog');
    var h = document.createElement('h3'); h.textContent = baseOf(en.name); dlg.append(h);
    var note = document.createElement('p'); note.className = 'dnote'; note.textContent = en.name + ' · ' + O.fmtSize(en.size); dlg.append(note);
    var body = document.createElement('div'); body.className = 'zv-pv'; body.textContent = 'Loading…'; dlg.append(body);
    var urls = [];
    var close = function () { urls.forEach(function (u) { URL.revokeObjectURL(u); }); scrim.remove(); };
    var act = document.createElement('div'); act.className = 'actions';
    function btn(label, fn) { var b = document.createElement('button'); b.className = 'btn text sl'; b.textContent = label; b.onclick = fn; act.append(b); return b; }
    btn('Close', close);
    btn('Save', function () { saveOne(en); });
    btn('Open', function () { close(); addToWorkspace(e, [en], true); });
    dlg.append(act); scrim.append(dlg);
    scrim.addEventListener('click', function (ev) { if (ev.target === scrim) close(); });
    document.body.append(scrim);

    try {
      var bytes = await en.bytes(), ext = extOf(en.name), mime = mimeOf(en.name);
      body.textContent = '';
      if (/^image\//.test(mime) && ext !== 'svg') {
        var img = document.createElement('img'), u = URL.createObjectURL(new Blob([bytes], { type: mime })); urls.push(u); img.src = u; body.append(img);
      } else if (ext === 'pdf') {
        var fr = document.createElement('iframe'), u2 = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' })); urls.push(u2); fr.src = u2; body.append(fr);
      } else {
        var sample = bytes.subarray(0, 4000), binary = false;
        for (var i = 0; i < sample.length; i++) if (sample[i] === 0) { binary = true; break; }
        if (binary && !TEXT_EXT.test(ext)) {
          body.textContent = 'No preview for this file type. Use Open or Save.';
        } else {
          var limit = 300000, pre = document.createElement('pre');
          pre.textContent = new TextDecoder().decode(bytes.subarray(0, limit)) + (bytes.length > limit ? '\n\n… (preview truncated)' : '');
          body.append(pre);
        }
      }
    } catch (err) {
      body.textContent = String(err && err.message || err);
    }
  }

  O.zipRender = render;
  O.readZip = readZip;
  O.inflate = inflate;
  O.zipLib = { readZip: readZip, readTar: readTar, openArchive: openArchive };
  var cur = O.cur(); if (cur && cur.kind === 'zip') O.renderAll();
})();
