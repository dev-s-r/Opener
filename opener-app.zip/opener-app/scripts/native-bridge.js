/* Connects the web app to Android: opened/shared files, saving to Downloads, system bar colours. */
(function () {
  'use strict';
  var busy = false;
  function native() { return window.AndroidBridge; }

  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  /* ---- files opened with / shared to the app (streamed from disk, so big files are fine) ---- */
  async function pull() {
    var B = native();
    if (!B || busy) return;
    var n = B.pendingCount();
    if (!n) return;
    busy = true;
    try {
      var files = [];
      for (var i = 0; i < n; i++) {
        var waited = 0;
        while (B.pendingReady && !B.pendingReady(i) && waited < 600000) { await sleep(150); waited += 150; }
        var info = JSON.parse(B.pendingInfo(i));
        var type = info.type || 'application/octet-stream';
        var blob = null;
        if (info.path && window.Capacitor && window.Capacitor.convertFileSrc) {
          try {
            var r = await fetch(window.Capacitor.convertFileSrc('file://' + encodeURI(info.path)));
            if (r.ok) blob = await r.blob();
          } catch (e) { /* fall back below */ }
        }
        if (!blob && B.pendingChunk && info.size) {
          var parts = [], CH = 3 * 1024 * 1024; // multiple of 3, so every piece is valid base64 on its own
          for (var off = 0; off < info.size; off += CH) {
            var piece = B.pendingChunk(i, off, CH);
            if (!piece) { parts = []; break; }
            parts.push(await (await fetch('data:application/octet-stream;base64,' + piece)).blob());
          }
          if (parts.length) blob = new Blob(parts, { type: type });
        }
        if (!blob) {
          var b64 = B.pendingData(i);
          blob = await (await fetch('data:' + type + ';base64,' + b64)).blob();
        }
        files.push(new File([blob], info.name, { type: info.type || blob.type }));
      }
      B.clearPending(n);
      var input = document.getElementById('fileInput');
      if (!input) return;
      var dt = new DataTransfer();
      files.forEach(function (f) { dt.items.add(f); });
      input.files = dt.files;
      input.dispatchEvent(new Event('change', { bubbles: true }));
    } catch (e) {
      console.warn('native file import failed', e);
    } finally {
      busy = false;
    }
  }
  window.__nativeFilesReady = pull;
  window.addEventListener('load', function () { setTimeout(pull, 700); });

  /* ---- saving: small files in one go, big files in pieces ---- */
  function toB64(blob) {
    return new Promise(function (res, rej) {
      var rd = new FileReader();
      rd.onload = function () { res(String(rd.result).split(',')[1] || ''); };
      rd.onerror = function () { rej(rd.error); };
      rd.readAsDataURL(blob);
    });
  }
  async function saveBlob(name, blob, quiet) {
    var B = native();
    var type = blob.type || 'application/octet-stream';
    if (blob.size <= 3 * 1024 * 1024 || !B.saveBegin) {
      var data = await toB64(blob);
      return quiet ? B.saveFileQuiet(name, type, data) : B.saveFile(name, type, data);
    }
    var id = B.saveBegin(name, type);
    if (!id) { if (!quiet) B.saveFile(name, type, ''); return false; }
    var CH = 1536 * 1024; // multiple of 3, so every piece is valid base64 on its own
    for (var off = 0; off < blob.size; off += CH) {
      var ok = B.saveChunk(id, await toB64(blob.slice(off, off + CH)));
      if (!ok) { B.saveEnd(id, false); return false; }
    }
    return B.saveEnd(id, !quiet);
  }
  window.__nativeSaveBlob = saveBlob;

  /* ---- downloads: blob links -> Downloads folder ---- */
  document.addEventListener('click', function (ev) {
    var a = ev.target && ev.target.closest && ev.target.closest('a[download]');
    if (!a || !/^blob:/.test(a.href) || !native()) return;
    ev.preventDefault();
    ev.stopPropagation();
    var name = a.getAttribute('download') || 'file';
    fetch(a.href).then(function (r) { return r.blob(); }).then(function (blob) {
      return saveBlob(name, blob, false);
    });
  }, true);

  /* ---- back gesture: close the top-most overlay, report whether something was closed ---- */
  window.__nativeBack = function () {
    function visible(sel) { var e = document.querySelector(sel); return !!e && !e.hidden; }
    var closed = false;
    var dlg = document.getElementById('zvScrim') || document.getElementById('peForm');
    if (dlg) { dlg.remove(); return true; }
    if (visible('#dlgScrim') || document.getElementById('formScrim') || visible('#menu') || visible('#pv') ||
        visible('#findBar') || document.body.classList.contains('fs')) {
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      closed = true;
    } else if (document.body.classList.contains('drawer-open')) {
      var sc = document.getElementById('scrim');
      if (sc) { sc.click(); closed = true; }
    }
    return closed;
  };

  /* ---- status / navigation bar colours follow the app theme ---- */
  function syncChrome() {
    var B = native();
    if (!B || !document.body) return;
    var m = getComputedStyle(document.body).backgroundColor.match(/\d+/g);
    if (!m || m.length < 3) return;
    var hex = '#' + m.slice(0, 3).map(function (x) { return ('0' + (+x).toString(16)).slice(-2); }).join('');
    B.setChrome(hex, (0.299 * m[0] + 0.587 * m[1] + 0.114 * m[2]) < 128);
  }
  document.addEventListener('DOMContentLoaded', function () {
    syncChrome();
    var mo = new MutationObserver(syncChrome);
    mo.observe(document.documentElement, { attributes: true });
    mo.observe(document.body, { attributes: true });
    if (window.matchMedia) window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function () { setTimeout(syncChrome, 50); });
  });
  window.addEventListener('load', function () { setTimeout(syncChrome, 300); });
  document.addEventListener('visibilitychange', function () { if (!document.hidden) syncChrome(); });
})();
