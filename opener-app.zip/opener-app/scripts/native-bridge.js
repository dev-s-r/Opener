/* Connects the web app to Android: opened/shared files, saving to Downloads, system bar colours. */
(function () {
  'use strict';
  var busy = false;
  function native() { return window.AndroidBridge; }

  /* ---- files opened with / shared to the app ---- */
  async function pull() {
    var B = native();
    if (!B || busy) return;
    var n = B.pendingCount();
    if (!n) return;
    busy = true;
    try {
      var files = [];
      for (var i = 0; i < n; i++) {
        var info = JSON.parse(B.pendingInfo(i));
        var type = info.type || 'application/octet-stream';
        var b64 = B.pendingData(i);
        var blob = await (await fetch('data:' + type + ';base64,' + b64)).blob();
        files.push(new File([blob], info.name, { type: info.type || blob.type }));
      }
      B.clearPending(n);
      var input = document.getElementById('fileInput');
      if (!input) return;
      var dt = new DataTransfer();
      files.forEach(function (f) { dt.items.add(f); });
      input.files = dt.files;
      input.dispatchEvent(new Event('change', { bubbles: true }));
    } catch (e) {
      console.warn('native file import failed', e);
    } finally {
      busy = false;
    }
  }
  window.__nativeFilesReady = pull;
  window.addEventListener('load', function () { setTimeout(pull, 700); });

  /* ---- downloads: blob links -> Downloads folder ---- */
  document.addEventListener('click', function (ev) {
    var a = ev.target && ev.target.closest && ev.target.closest('a[download]');
    if (!a || !/^blob:/.test(a.href) || !native()) return;
    ev.preventDefault();
    ev.stopPropagation();
    var name = a.getAttribute('download') || 'file';
    fetch(a.href).then(function (r) { return r.blob(); }).then(function (blob) {
      var rd = new FileReader();
      rd.onload = function () {
        native().saveFile(name, blob.type || 'application/octet-stream', String(rd.result).split(',')[1] || '');
      };
      rd.readAsDataURL(blob);
    });
  }, true);

  /* ---- back gesture: close the top-most overlay, report whether something was closed ---- */
  window.__nativeBack = function () {
    function visible(sel) { var e = document.querySelector(sel); return !!e && !e.hidden; }
    var closed = false;
    var dlg = document.getElementById('zvScrim') || document.getElementById('peForm');
    if (dlg) { dlg.remove(); return true; }
    if (visible('#dlgScrim') || document.getElementById('formScrim') || visible('#menu') || visible('#pv') ||
        visible('#findBar') || document.body.classList.contains('fs')) {
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      closed = true;
    } else if (document.body.classList.contains('drawer-open')) {
      var sc = document.getElementById('scrim');
      if (sc) { sc.click(); closed = true; }
    }
    return closed;
  };

  /* ---- status / navigation bar colours follow the app theme ---- */
  function syncChrome() {
    var B = native();
    if (!B || !document.body) return;
    var m = getComputedStyle(document.body).backgroundColor.match(/\d+/g);
    if (!m || m.length < 3) return;
    var hex = '#' + m.slice(0, 3).map(function (x) { return ('0' + (+x).toString(16)).slice(-2); }).join('');
    B.setChrome(hex, (0.299 * m[0] + 0.587 * m[1] + 0.114 * m[2]) < 128);
  }
  document.addEventListener('DOMContentLoaded', function () {
    syncChrome();
    var mo = new MutationObserver(syncChrome);
    mo.observe(document.documentElement, { attributes: true });
    mo.observe(document.body, { attributes: true });
    if (window.matchMedia) window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function () { setTimeout(syncChrome, 50); });
  });
  window.addEventListener('load', function () { setTimeout(syncChrome, 300); });
  document.addEventListener('visibilitychange', function () { if (!document.hidden) syncChrome(); });
})();
